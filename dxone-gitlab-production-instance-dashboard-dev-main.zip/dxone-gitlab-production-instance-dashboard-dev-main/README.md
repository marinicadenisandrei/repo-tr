# dxone-instance-monitoring

A GitLab Pages dashboard that monitors the **DX1 GitLab instance** using the
**Service Ping payload** — the JSON that GitLab regenerates every week via its
built-in cron (`gitlab_service_ping_worker`), the same payload shown under
*Admin Area > Settings > Metrics and profiling > Usage statistics > Preview
payload*.

Sibling project of `dxone-runners-compliance` — same pipeline shape
(vault-service auth, weekly schedule, static fallback, append-only history,
Pages deploy) and the same Phoenix-based dashboard styling.

## How it works

```
fetch-service-ping ──▶ build-history ──▶ pages
  service_ping.json      history/           public/data/service_ping.json
  (weekly payload)       history.json       public/data/history.json
```

1. **`fetch-service-ping`** (`scripts/fetch_service_ping.py`) downloads the
   payload with

   ```
   GET ${TARGET_GITLAB_URL}/api/v4/usage_data/service_ping
   PRIVATE-TOKEN: <admin GITLAB_TOKEN from Vault>
   ```

   wraps it in a small envelope (fetch metadata, curated `summary`, flattened
   `metrics_flat` index, untouched `payload`) and publishes
   `output/service_ping.json` + `output/service_ping.xlsx` as artifacts.

2. **`build-history`** (`scripts/build_history.py`) folds every run into an
   append-only dataset — one entry per pipeline with the instance identity and
   **every numeric metric** of the payload — restored from: last build-history
   artifact → live Pages `data/history.json` → committed
   `static/history_seed.json` → empty. Runs are deduplicated by pipeline id
   *and* payload fingerprint, so a week where GitLab's cron produced no new
   payload (or a static re-deploy) never distorts the trends.

3. **`pages`** ships the dashboard to GitLab Pages:
   * **Overview** — active users, projects, groups, pipelines, builds,
     runners; instance identity (version, edition, DB, Gitaly…), license &
     seat usage, payload health, feature toggles, object storage;
   * **Latest Analytics** — largest counters per category, runner fleet
     split, DevOps-stage activity (all time vs 28 days), weekly-vs-monthly
     unique users, security scan jobs, deployments & delivery, issues &
     collaboration, platform adoption (clusters / Auto DevOps /
     integrations), instance topology, and a per-category chart of every
     `redis_hll_counters` feature-activity group;
   * **Historical Analytics** — 12 KPI trend cards with sparklines and
     week-over-week deltas, an any-metric trend plotter with a Δ-per-run
     mode, a category **trend grid** (the 12 largest metrics of any payload
     category, each charted across every recorded run), biggest movers
     between the last two runs, the full run log;
   * **Code & Repositories** — repository/branch/MR coverage: projects with
     repositories, protected branches, merge requests (created/merged),
     snippets, LFS objects, pool repositories, deploy keys, remote mirrors;
     source-code and code-review unique-user activity; Git/Gitaly platform
     details; a per-DevOps-stage drilldown (all-time vs monthly for every
     stage metric); and a filterable **totals vs last-28-days** table of
     every counter in the payload;
   * **Metrics Explorer** — every flattened metric with search, category
     filter, failed-metric (`-1`) filter, sorting and CSV export;
   * **Payload Browser** — a searchable collapsible tree of the *entire*
     raw payload, including strings, booleans and nested structures the
     numeric explorer doesn't cover — nothing GitLab reports is hidden.

## Token

The pipeline reuses the existing **admin** `GITLAB_TOKEN` from Vault
(`GITLAB_TOKEN@gitlab/app-01680/kv/tokens@GITLAB_API_TOKEN`) — the same KV field
the runner-compliance project uses. An admin token with the `api` scope
covers the service_ping endpoint; no additional token is needed.

## Behaviour flags

| Variable | Default | Effect |
|---|---|---|
| `SKIP_FETCH` | `false` | `true` skips the fetch job and publishes the committed `static/service_ping.json` |
| `DASHBOARD_ENV` | `dev` | environment badge override (`dev` / `production`) |
| `HISTORY_RECORD` | `auto` | `auto` records only real pipeline data; `always` also records static re-deploys; `never` only carries the history forward |
| `HISTORY_FILE` | `history/history.json` | artifact path of the dataset |
| `HISTORY_SEED_FILE` | `static/history_seed.json` | committed backfill used before any artifact exists |
| `FETCH_SCRIPT_FLAGS` | – | extra flags, e.g. `--no-verify-ssl` |
| `EMAIL_NOTIFY` | `true` | `false` silences the run-summary email entirely |
| `PING_ALERT_TO` | built-in list | comma-separated recipients of the run summary |
| `PING_ALERT_FROM` | `dxone_instance_monitor@lseg.com` | sender address |
| `SMTP_HOST` / `SMTP_PORT` | `smtp.prod.stockex.local` / `25` | mail relay |

## Notifications

The `notify-run-summary` job (last stage) emails a digest **after every
run** — this pipeline is scheduled, so unlike the runners-compliance alert
(problems only) the email doubles as the weekly "the run happened" receipt:

* subject and badge carry the environment — `[DEV]` / `[PRODUCTION]` from
  `DASHBOARD_ENV` (falling back to `dashboard/config.json`), so the dev and
  prod schedules each produce a clearly labelled email;
* headline KPI cells (users/seats, projects, CI pipelines, runners online,
  failed metrics);
* a **Trends** table with run-over-run deltas computed from the history
  dataset produced by `build-history` in the same pipeline;
* health flags that flip the badge from `RUN OK` to `ATTENTION`: failed
  metrics, pending batched migrations, schema/index inconsistencies,
  license expiring within 90 days, seat usage ≥ 95 %, and an unchanged
  Service Ping payload (weekly cron likely didn't fire);
* `Open Dashboard` / `View Pipeline` buttons — the job runs after `pages`
  so the dashboard link already shows the fresh data.

The HTML is built for Outlook's rendering engine (nested tables, inlined
styles) — same construction as the runners-compliance email. SMTP failures
are logged but never fail the pipeline. Preview locally without SMTP:

```bash
DASHBOARD_ENV=dev python3 scripts/send_notification.py \
    --snapshot static/service_ping.json \
    --history  static/history_seed.json \
    --dry-run  /tmp/run_summary.html
```

## Scheduling

The payload only changes once per week, so a **weekly schedule** (CI/CD >
Schedules) is the right cadence — pick a slot a few hours after your
instance's Service Ping cron so each run picks up the fresh payload. The
history job's fingerprint dedup makes more frequent runs harmless (they are
recorded once).

For dev and prod, create one schedule per environment and set
`DASHBOARD_ENV` (`dev` / `production`) — and, if the two instances differ,
`TARGET_GITLAB_URL` — as schedule variables. Each schedule then produces
its own correctly-badged dashboard deploy *and* its own `[DEV]` /
`[PRODUCTION]` run-summary email.

## Backfilling from old pipeline artifacts

Download `service-ping-<PIPELINE_ID>.zip` artifacts of earlier runs into a
folder and rebuild the seed:

```bash
python3 scripts/build_history.py \
    --output static/history_seed.json \
    --from-artifacts ./downloaded_artifacts/
```

Commit the regenerated `static/history_seed.json`.

## Local development

```bash
# fake pages deploy from the committed static sample
mkdir -p public/data
cp dashboard/index.html dashboard/config.json public/
cp -r dashboard/assets public/assets
cp dashboard/*.ico dashboard/*.png public/
cp static/service_ping.json public/data/
cp static/history_seed.json public/data/history.json
python3 -m http.server -d public 8000    # open http://localhost:8000
```

The committed `static/service_ping.json` / `static/history_seed.json` are built
from the **real 2026‑07‑29 payload** of `gitlab.dx1.qa.lseg.com` (GitLab
19.0.4‑ee, 4,540 numeric metrics). The seed contains that one run; every
scheduled pipeline appends the new weekly payload, so trends, sparklines,
deltas and the biggest-movers table fill in automatically week after week. To
refresh the static fallback from a newer downloaded payload:

```bash
python3 scripts/fetch_service_ping.py --gitlab-url https://gitlab.dx1.qa.lseg.com \
    --from-file <payload.json> -o static/service_ping.json
```

Note on GitLab ≥ 19 payloads: some classic counters were removed
(`counts.ci_pipelines`, `counts.ci_builds`, runner type splits). The fetch
script and dashboard fall back to the closest equivalents
(`ci_pipeline_config_*` for pipelines, `count_total_create_ci_build` for
builds, online/offline for the runner donut) so the headline KPIs and history
trends stay populated.
