#!/usr/bin/env python3
"""
send_notification.py — email a run summary after every pipeline run.

Same conventions as the dxone-runners-compliance alert email (Outlook-safe
nested-table HTML, env badge from DASHBOARD_ENV / dashboard/config.json,
SMTP settings from env vars) but sent after EVERY run, not only on
problems: this pipeline is scheduled, and the email is the weekly
"the run happened, here is what changed" digest for dev and prod.

Inputs (all optional — the email degrades gracefully):

    output/service_ping.json     fresh snapshot from fetch_service_ping.py
    static/service_ping.json     fallback when SKIP_FETCH=true
    history/history.json         append-only dataset from build-history —
                                 used to compute run-over-run deltas
    static/history_seed.json     fallback history

Environment:

    DASHBOARD_ENV       "dev" / "production" — env badge + subject prefix
                        (falls back to dashboard/config.json "environment")
    CI_PIPELINE_URL     "View Pipeline" button
    CI_PAGES_URL        "Open Dashboard" button
    SMTP_HOST           default smtp.prod.stockex.local
    SMTP_PORT           default 25
    PING_ALERT_FROM     default dxone_instance_monitor@lseg.com
    PING_ALERT_TO       comma-separated recipients (overrides the built-in
                        DEFAULT_ALERT_RECIPIENTS list)

Usage (CI):

    python3 scripts/send_notification.py \
        --snapshot output/service_ping.json \
        --history  history/history.json

Usage (local test — writes the HTML body next to the terminal output
instead of talking to SMTP):

    python3 scripts/send_notification.py \
        --snapshot static/service_ping.json \
        --history  static/history_seed.json \
        --dry-run  /tmp/run_summary.html

Exit codes: always 0 unless the snapshot cannot be read at all — a broken
mail relay must never fail the pipeline (the send error is only logged).
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import os
import smtplib
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any

DEFAULT_ALERT_RECIPIENTS = [
    "Kanaganathan.Arulselvan@lseg.com",
    "Akash.Gupta2@lseg.com",
    "denis.marinica@lseg.com",
]

# headline metrics shown as delta rows in the email: (summary key, label,
# higher_is_bad — flips the delta colour, e.g. failed metrics going up is red)
TREND_METRICS = [
    ("active_user_count",       "Active users",        False),
    ("projects",                "Projects",            False),
    ("groups",                  "Groups",              False),
    ("merge_requests",          "Merge requests",      False),
    ("ci_pipelines",            "CI pipelines",        False),
    ("ci_builds",               "CI builds",           False),
    ("ci_runners",              "CI runners",          False),
    ("ci_runners_online",       "Runners online",      False),
    ("ci_build_minutes_monthly","CI minutes (month)",  False),
    ("license_billable_users",  "Billable users",      False),
    ("metrics_failed",          "Failed metrics",      True),
    ("pending_migrations",      "Pending migrations",  True),
]


def log(msg: str) -> None:
    print(f"[send_notification] {msg}", flush=True)


def _num(v: Any) -> int | float | None:
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _fmt(v: Any) -> str:
    n = _num(v)
    if n is None:
        return "—"
    if isinstance(n, float):
        return f"{n:,.1f}" if abs(n) < 10000 else f"{n:,.0f}"
    return f"{n:,}"


def _load_json(path: str | None) -> dict | None:
    if not path:
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            doc = json.load(fh)
        return doc if isinstance(doc, dict) else None
    except Exception as exc:
        log(f"could not read {path}: {exc}")
        return None


# ---------------------------------------------------------------------------
# environment resolution — identical convention to the compliance script:
# DASHBOARD_ENV wins, then dashboard/config.json, then "production"
# ---------------------------------------------------------------------------
def get_environment() -> tuple[str, str]:
    env = (os.getenv("DASHBOARD_ENV") or "").strip().lower()
    cfg: dict[str, Any] = {}
    try:
        cfg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "dashboard", "config.json")
        with open(cfg_path, encoding="utf-8") as fh:
            cfg = json.load(fh)
    except Exception:
        pass
    if not env:
        env = str(cfg.get("environment", "production")).strip().lower()
    label = str(((cfg.get("environments") or {}).get(env) or {})
                .get("label") or env.upper())
    return env, label


# ---------------------------------------------------------------------------
# health flags — these flip the badge from "RUN OK" to "ATTENTION"
# ---------------------------------------------------------------------------
def collect_flags(s: dict, prev: dict | None,
                  payload_unchanged: bool) -> list[str]:
    flags: list[str] = []
    mf = _num(s.get("metrics_failed"))
    if mf:
        flags.append(f"{_fmt(mf)} metric(s) failed to compute (value -1) in the payload")
    pm = _num(s.get("pending_migrations"))
    if pm:
        flags.append(f"{_fmt(pm)} batched background migration(s) still pending")
    si = _num(s.get("schema_inconsistencies"))
    if si:
        flags.append(f"{_fmt(si)} database schema inconsistencies reported")
    ii = _num(s.get("index_inconsistencies"))
    if ii:
        flags.append(f"{_fmt(ii)} database index inconsistencies reported")
    exp = s.get("license_expires_at")
    if isinstance(exp, str) and exp:
        try:
            days = (dt.date.fromisoformat(exp[:10]) - dt.date.today()).days
            if days < 0:
                flags.append(f"license EXPIRED on {exp[:10]}")
            elif days <= 90:
                flags.append(f"license expires in {days} days ({exp[:10]})")
        except ValueError:
            pass
    active = _num(s.get("active_user_count"))
    seats = _num(s.get("license_user_count"))
    if active is not None and seats:
        pct = active / seats * 100
        if pct >= 95:
            flags.append(f"seat usage at {pct:.0f}% "
                         f"({_fmt(active)} of {_fmt(seats)} licensed users)")
    if payload_unchanged:
        flags.append("Service Ping payload is UNCHANGED since the previous run "
                     "— the weekly cron may not have produced a fresh payload")
    return flags


# ---------------------------------------------------------------------------
# run-over-run deltas from the history dataset
# ---------------------------------------------------------------------------
def previous_run(history: dict | None, current_run_id: str) -> dict | None:
    """Last recorded run that is not this pipeline's own entry."""
    runs = (history or {}).get("runs") or []
    for run in reversed(runs):
        if str(run.get("run_id")) != str(current_run_id):
            return run
    return None


def build_deltas(s: dict, prev: dict | None) -> list[tuple[str, Any, Any, float | None, bool]]:
    """[(label, now, before, delta, higher_is_bad)] for metrics present in both."""
    out: list[tuple[str, Any, Any, float | None, bool]] = []
    ps = (prev or {}).get("summary") or {}
    for key, label, bad_up in TREND_METRICS:
        now, before = _num(s.get(key)), _num(ps.get(key))
        if now is None:
            continue
        delta = (now - before) if before is not None else None
        out.append((label, now, before, delta, bad_up))
    return out


# ---------------------------------------------------------------------------
# Outlook-safe HTML body (same construction rules as the compliance email:
# nested tables, width/bgcolor/align attributes, fully inlined styles,
# table-based buttons, no divs for layout, no border-radius/flexbox)
# ---------------------------------------------------------------------------
def build_email_html(s: dict, deltas: list, flags: list[str],
                     prev: dict | None, pipeline_url: str,
                     pages_url: str | None, env_key: str, env_label: str,
                     source_label: str) -> str:
    esc = html.escape
    fnt = "font-family:Segoe UI,Arial,sans-serif;"
    generated = dt.datetime.now(dt.timezone.utc).strftime("%d %b %Y, %H:%M UTC")
    if "prod" in env_key:
        env_bg, env_border, env_fg = "#0F2E1F", "#2FBF71", "#8FE7BC"
    else:
        env_bg, env_border, env_fg = "#332406", "#F5B84C", "#FFD98A"
    if flags:
        st_bg, st_border, st_fg, st_txt = "#332406", "#F5B84C", "#FFD98A", "ATTENTION"
    else:
        st_bg, st_border, st_fg, st_txt = "#0F2E1F", "#2FBF71", "#8FE7BC", "RUN OK"

    version = s.get("version") or "?"
    edition = s.get("edition") or ""
    recorded = (s.get("recorded_at") or "")[:16].replace("T", " ")

    # --- summary stat cells --------------------------------------------------
    def stat_cell(value: Any, label: str, color: str) -> str:
        return (
            '<td width="20%" align="center" valign="top" bgcolor="#FFFFFF" '
            'style="border:1px solid #D9E0EB;padding:16px 4px;">'
            f'<span style="{fnt}font-size:26px;font-weight:bold;color:{color};">'
            f'{esc(str(value))}</span><br>'
            f'<span style="{fnt}font-size:11px;color:#5A6B85;'
            f'text-transform:uppercase;letter-spacing:1px;">{esc(label)}</span>'
            '</td>')

    runners_txt = f"{_fmt(s.get('ci_runners_online'))} / {_fmt(s.get('ci_runners'))}"
    seats_txt = f"{_fmt(s.get('active_user_count'))} / {_fmt(s.get('license_user_count'))}"
    stats = ('<table role="presentation" width="100%" cellpadding="0" '
             'cellspacing="0" border="0"><tr>'
             + stat_cell(seats_txt, "Users / seats", "#1F2A3D")
             + stat_cell(_fmt(s.get("projects")), "Projects", "#1F2A3D")
             + stat_cell(_fmt(s.get("ci_pipelines")), "CI pipelines", "#1F2A3D")
             + stat_cell(runners_txt, "Runners online", "#1E7A4C")
             + stat_cell(_fmt(s.get("metrics_failed")), "Failed metrics",
                         "#C5221F" if _num(s.get("metrics_failed")) else "#1E7A4C")
             + "</tr></table>")

    # --- trend table ---------------------------------------------------------
    prev_when = ""
    if prev:
        prev_when = (prev.get("generated_at") or prev.get("recorded_at") or "")[:10]
    trend_rows = ""
    for label, now, before, delta, bad_up in deltas:
        if delta is None or delta == 0:
            d_html = ('<span style="color:#5A6B85;">'
                      + ("&ndash;" if delta == 0 else "n/a") + "</span>")
        else:
            up = delta > 0
            good = up != bad_up
            color = "#1E7A4C" if good else "#C5221F"
            arrow = "&#9650;" if up else "&#9660;"
            d_html = (f'<span style="color:{color};font-weight:bold;">'
                      f'{arrow} {esc(_fmt(abs(delta)))}</span>')
        trend_rows += (
            '<tr>'
            f'<td style="{fnt}font-size:12px;color:#1F2A3D;padding:6px 10px;'
            f'border-bottom:1px solid #EEF1F6;">{esc(label)}</td>'
            f'<td align="right" style="{fnt}font-size:12px;color:#5A6B85;'
            f'padding:6px 10px;border-bottom:1px solid #EEF1F6;">{esc(_fmt(before))}</td>'
            f'<td align="right" style="{fnt}font-size:12px;color:#1F2A3D;font-weight:bold;'
            f'padding:6px 10px;border-bottom:1px solid #EEF1F6;">{esc(_fmt(now))}</td>'
            f'<td align="right" style="{fnt}font-size:12px;'
            f'padding:6px 10px;border-bottom:1px solid #EEF1F6;">{d_html}</td>'
            '</tr>')
    trend_block = ""
    if trend_rows:
        head = ("since previous run" + (f" ({esc(prev_when)})" if prev_when else "")
                if prev else "no previous run recorded yet")
        trend_block = (
            '<tr><td style="padding:22px 30px 0 30px;">'
            f'<span style="{fnt}font-size:12px;font-weight:bold;color:#1F2A3D;'
            'text-transform:uppercase;letter-spacing:1px;">Trends</span> '
            f'<span style="{fnt}font-size:11px;color:#5A6B85;">&mdash; {head}</span>'
            '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
            'border="0" style="margin-top:8px;border:1px solid #D9E0EB;" bgcolor="#FFFFFF">'
            '<tr bgcolor="#F6F8FB">'
            f'<td style="{fnt}font-size:10px;color:#5A6B85;text-transform:uppercase;'
            'letter-spacing:1px;padding:7px 10px;">Metric</td>'
            f'<td align="right" style="{fnt}font-size:10px;color:#5A6B85;'
            'text-transform:uppercase;letter-spacing:1px;padding:7px 10px;">Previous</td>'
            f'<td align="right" style="{fnt}font-size:10px;color:#5A6B85;'
            'text-transform:uppercase;letter-spacing:1px;padding:7px 10px;">Current</td>'
            f'<td align="right" style="{fnt}font-size:10px;color:#5A6B85;'
            'text-transform:uppercase;letter-spacing:1px;padding:7px 10px;">&Delta;</td>'
            f'</tr>{trend_rows}</table></td></tr>')

    # --- health callout ------------------------------------------------------
    if flags:
        items = "".join(f'<li style="padding:2px 0;">{esc(f)}</li>' for f in flags)
        callout = (
            '<tr><td style="padding:18px 30px 0 30px;">'
            '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">'
            '<tr><td width="4" bgcolor="#F5B84C"></td>'
            f'<td bgcolor="#FFF8EC" style="{fnt}font-size:12px;color:#1F2A3D;'
            'padding:12px 16px;line-height:19px;">'
            f'<b>Needs a look</b><ul style="margin:6px 0 0 18px;padding:0;">{items}</ul>'
            '</td></tr></table></td></tr>')
    else:
        callout = (
            '<tr><td style="padding:18px 30px 0 30px;">'
            '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">'
            '<tr><td width="4" bgcolor="#2FBF71"></td>'
            f'<td bgcolor="#EEF9F2" style="{fnt}font-size:12px;color:#1F2A3D;'
            'padding:12px 16px;line-height:19px;">'
            '<b>All checks passed</b> &mdash; no failed metrics, no pending '
            'migrations, no database inconsistencies, license healthy.'
            '</td></tr></table></td></tr>')

    # --- table-based buttons -------------------------------------------------
    def button(url: str, label: str, bg: str, fg: str, border: str) -> str:
        return (
            '<table role="presentation" cellpadding="0" cellspacing="0" '
            'border="0" align="center" style="display:inline-table;"><tr>'
            f'<td bgcolor="{bg}" style="border:1px solid {border};padding:11px 26px;">'
            f'<a href="{esc(url)}" style="{fnt}font-size:13px;font-weight:bold;'
            f'color:{fg};text-decoration:none;display:inline-block;">'
            f'{esc(label)}</a></td></tr></table>')

    buttons_cells = ""
    if pages_url:
        buttons_cells += ('<td align="center" style="padding:0 8px;">'
                          + button(pages_url, "Open Dashboard",
                                   "#2F6FE4", "#FFFFFF", "#2F6FE4") + "</td>")
    buttons_cells += ('<td align="center" style="padding:0 8px;">'
                      + button(pipeline_url, "View Pipeline",
                               "#FFFFFF", "#2F6FE4", "#2F6FE4") + "</td>")
    buttons = ('<table role="presentation" cellpadding="0" cellspacing="0" '
               f'border="0" align="center"><tr>{buttons_cells}</tr></table>')

    dashboard_link = ""
    if pages_url:
        dashboard_link = (f' &nbsp;|&nbsp; <a href="{esc(pages_url)}" '
                          f'style="color:#2F6FE4;">Dashboard</a>')

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="color-scheme" content="light" />
<!--[if mso]>
<style type="text/css">
  table {{border-collapse:collapse;}}
  td, a, span {{font-family:Segoe UI,Arial,sans-serif !important;}}
</style>
<![endif]-->
<title>DXOne GitLab instance monitor</title>
</head>
<body style="margin:0;padding:0;" bgcolor="#F2F4F8">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#F2F4F8">
<tr><td align="center" style="padding:26px 10px;">

  <table role="presentation" width="640" cellpadding="0" cellspacing="0" border="0" bgcolor="#FFFFFF" style="border:1px solid #D9E0EB;">

    <!-- header -->
    <tr><td bgcolor="#0D131E" style="padding:22px 30px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
        <td>
          <span style="{fnt}font-size:11px;font-weight:bold;color:#4C8DFF;
                       text-transform:uppercase;letter-spacing:2px;">
            DXOne &middot; GitLab Instance Monitor</span><br>
          <span style="{fnt}font-size:22px;font-weight:bold;color:#FFFFFF;
                       line-height:34px;">
            Weekly run summary &mdash; GitLab {esc(str(version))} {esc(str(edition))}</span><br>
          <span style="{fnt}font-size:12px;color:#8DA0BC;">{generated}
            &nbsp;&middot;&nbsp; payload recorded {esc(recorded or "?")} UTC
            &nbsp;&middot;&nbsp; source: {esc(source_label)}</span>
        </td>
        <td align="right" valign="top" width="160">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0" align="right" width="160">
            <tr>
              <td align="right">
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" align="right"><tr>
                  <td bgcolor="{env_bg}" align="center" style="border:1px solid {env_border};padding:6px 14px;">
                    <span style="{fnt}font-size:11px;font-weight:bold;color:{env_fg};
                                 letter-spacing:1px;white-space:nowrap;">{esc(env_label)}</span>
                  </td>
                </tr></table>
              </td>
            </tr>
            <tr>
              <td align="right" style="padding-top:8px;">
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" align="right"><tr>
                  <td bgcolor="{st_bg}" align="center" style="border:1px solid {st_border};padding:6px 14px;">
                    <span style="{fnt}font-size:11px;font-weight:bold;color:{st_fg};
                                 letter-spacing:1px;white-space:nowrap;">{st_txt}</span>
                  </td>
                </tr></table>
              </td>
            </tr>
          </table>
        </td>
      </tr></table>
    </td></tr>

    <!-- stats -->
    <tr><td style="padding:26px 30px 0 30px;">{stats}</td></tr>

    <!-- health callout -->
    {callout}

    <!-- trends -->
    {trend_block}

    <!-- buttons -->
    <tr><td align="center" style="padding:26px 30px;">{buttons}</td></tr>

    <!-- footer -->
    <tr><td style="padding:0 30px 24px 30px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td style="border-top:1px solid #E8ECF3;padding-top:14px;
                       {fnt}font-size:11px;color:#5A6B85;line-height:19px;">
          <b style="color:#1F2A3D;">Instance snapshot</b> &mdash;
          license plan {esc(str(s.get("license_plan") or "?"))} &middot;
          expires {esc(str(s.get("license_expires_at") or "?"))} &middot;
          billable users {_fmt(s.get("license_billable_users"))} &middot;
          groups {_fmt(s.get("groups"))} &middot;
          MRs {_fmt(s.get("merge_requests"))} &middot;
          CI minutes (month) {_fmt(s.get("ci_build_minutes_monthly"))} &middot;
          metrics collected {_fmt(s.get("metrics_total"))}<br>
          Automated notification from the DXOne GitLab instance monitor
          &nbsp;|&nbsp; <a href="{esc(pipeline_url)}"
          style="color:#2F6FE4;">Pipeline</a>{dashboard_link}
        </td></tr>
      </table>
    </td></tr>

  </table>

</td></tr>
</table>
</body>
</html>"""


# ---------------------------------------------------------------------------
# plain-text fallback part
# ---------------------------------------------------------------------------
def build_email_text(s: dict, deltas: list, flags: list[str],
                     pipeline_url: str, pages_url: str | None,
                     env_label: str, source_label: str) -> str:
    lines: list[str] = []
    lines.append("DXOne GitLab instance monitor - weekly run summary")
    lines.append("")
    lines.append(f"Environment : {env_label}")
    lines.append(f"GitLab      : {s.get('version') or '?'} {s.get('edition') or ''}")
    lines.append(f"Recorded at : {s.get('recorded_at') or '?'}")
    lines.append(f"Data source : {source_label}")
    lines.append(f"Pipeline    : {pipeline_url}")
    if pages_url:
        lines.append(f"Dashboard   : {pages_url}")
    lines.append("")
    if flags:
        lines.append("NEEDS A LOOK:")
        for f in flags:
            lines.append(f"  * {f}")
    else:
        lines.append("All checks passed - no failed metrics, no pending "
                     "migrations, no database inconsistencies, license healthy.")
    lines.append("")
    lines.append("=" * 60)
    lines.append("HEADLINE METRICS (current / previous / delta)")
    lines.append("=" * 60)
    for label, now, before, delta, _bad in deltas:
        d = "n/a" if delta is None else f"{delta:+,.0f}" if delta else "0"
        lines.append(f"  {label:<22} {_fmt(now):>12} / {_fmt(before):>12} / {d:>8}")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    p.add_argument("--snapshot", default="output/service_ping.json",
                   help="run snapshot (falls back to --static-snapshot)")
    p.add_argument("--static-snapshot", default="static/service_ping.json",
                   help="fallback snapshot when the fetch job was skipped")
    p.add_argument("--history", default="history/history.json",
                   help="history dataset for run-over-run deltas")
    p.add_argument("--history-seed", default="static/history_seed.json",
                   help="fallback history")
    p.add_argument("--subject-prefix", default="DXOne GitLab instance monitor")
    p.add_argument("--dry-run", metavar="HTML_FILE", default=None,
                   help="write the HTML body to a file instead of sending")
    args = p.parse_args()

    # ---- snapshot (required) -----------------------------------------------
    source_label = "pipeline"
    doc = _load_json(args.snapshot)
    if doc is None:
        doc = _load_json(args.static_snapshot)
        source_label = "static"
    if doc is None:
        log("ERROR: no snapshot available - nothing to summarise")
        return 1
    s = doc.get("summary") or {}
    if not s:
        log("ERROR: snapshot has no 'summary' block")
        return 1

    # ---- history (optional) ------------------------------------------------
    history = _load_json(args.history) or _load_json(args.history_seed)
    run_id = os.getenv("CI_PIPELINE_ID", "")
    prev = previous_run(history, run_id)
    deltas = build_deltas(s, prev)

    payload_unchanged = False
    if prev and s.get("recorded_at") and prev.get("recorded_at"):
        payload_unchanged = s["recorded_at"] == prev["recorded_at"]

    flags = collect_flags(s, prev, payload_unchanged)

    pipeline_url = os.getenv("CI_PIPELINE_URL", "(unknown pipeline URL)")
    pages_url = os.getenv("CI_PAGES_URL")
    env_key, env_label = get_environment()

    body_html = build_email_html(s, deltas, flags, prev, pipeline_url,
                                 pages_url, env_key, env_label, source_label)
    body_text = build_email_text(s, deltas, flags, pipeline_url, pages_url,
                                 env_label, source_label)

    status = "ATTENTION" if flags else "OK"
    subject = (f"[{env_label}] {args.subject_prefix}: run {status} — "
               f"GitLab {s.get('version') or '?'}, "
               f"{_fmt(s.get('active_user_count'))} active users")

    if args.dry_run:
        with open(args.dry_run, "w", encoding="utf-8") as fh:
            fh.write(body_html)
        log(f"dry run - HTML body written to {args.dry_run}")
        log(f"subject: {subject}")
        print(body_text)
        return 0

    smtp_host = os.getenv("SMTP_HOST", "smtp.prod.stockex.local")
    smtp_port = int(os.getenv("SMTP_PORT", "25"))
    from_addr = os.getenv("PING_ALERT_FROM", "dxone_instance_monitor@lseg.com")
    to_env = os.getenv("PING_ALERT_TO", "")
    if to_env.strip():
        to_addrs = [a.strip() for a in to_env.split(",") if a.strip()]
    else:
        to_addrs = list(DEFAULT_ALERT_RECIPIENTS)

    log(f"sending run summary to {to_addrs} via {smtp_host}:{smtp_port}")
    msg = MIMEMultipart("alternative")
    msg["From"] = from_addr
    msg["To"] = ", ".join(to_addrs)
    msg["Subject"] = subject
    # order matters: last part is preferred by capable clients -> HTML last
    msg.attach(MIMEText(body_text, "plain"))
    msg.attach(MIMEText(body_html, "html"))

    try:
        smtp = smtplib.SMTP(smtp_host, smtp_port)
        smtp.sendmail(from_addr, to_addrs, msg.as_string())
        smtp.quit()
        log("run summary sent successfully")
    except Exception as exc:
        # a broken relay must never fail the pipeline
        log(f"ERROR: failed to send the run summary: {exc}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
