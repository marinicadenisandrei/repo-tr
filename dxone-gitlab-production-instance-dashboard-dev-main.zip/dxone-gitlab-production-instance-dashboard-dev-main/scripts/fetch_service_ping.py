#!/usr/bin/env python3
"""
fetch_service_ping.py — pull the weekly GitLab instance monitoring payload.

GitLab regenerates the Service Ping payload on a weekly cron
(gitlab_service_ping_worker) even when sending it to GitLab Inc. is
disabled; it is the same JSON shown in
Admin Area > Settings > Metrics and profiling > Usage statistics >
"Preview payload".

This script downloads that payload through the REST API

    GET /api/v4/usage_data/service_ping

authenticated with a personal access token that has the
``read_service_ping`` scope (admin-created; the ``api`` scope of an admin
token also works).  The token is read from the ``GITLAB_TOKEN``
environment variable — never from the command line — so it can be
supplied by Vault in CI exactly like the runner-compliance pipeline.

The payload is wrapped in a small envelope with fetch metadata plus a
pre-computed flat metric index, and written to one or more output files
(JSON always; ``.xlsx`` outputs get a flattened metric sheet):

    {
      "fetched_at":  "2026-08-03T04:00:00Z",
      "gitlab_url":  "https://gitlab.dx1.lseg.com",
      "summary":     { ...headline metrics used by the dashboard KPIs... },
      "metrics_flat": { "counts.ci_builds": 12345, ... },
      "payload":     { ...the untouched Service Ping JSON... }
    }

Usage:

    GITLAB_TOKEN=xxxx python3 scripts/fetch_service_ping.py \
        --gitlab-url https://gitlab.dx1.lseg.com \
        -o output/service_ping.json output/service_ping.xlsx

Exit codes: 0 ok, 1 fatal error (bad token, empty payload, network).
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import time
from typing import Any

import requests

DEFAULT_TIMEOUT = 120          # seconds per HTTP attempt
DEFAULT_RETRIES = 4            # attempts before giving up
RETRY_BACKOFF = (5, 15, 30, 60)

# top-level payload keys that are *not* metric containers (identity /
# environment blocks shown on the Overview page instead)
IDENTITY_KEYS = (
    "recorded_at", "uuid", "hostname", "version", "edition",
    "installation_type", "active_user_count", "license_md5",
    "license_sha256", "license_id", "license_subscription_id",
    "historical_max_users", "licensee", "license_user_count",
    "license_billable_users", "license_starts_at", "license_expires_at",
    "license_plan", "license_add_ons", "license_trial", "license",
    "recording_ce_finished_at", "recording_ee_finished_at",
)


def log(msg: str) -> None:
    print(f"[fetch_service_ping] {msg}", flush=True)


def die(msg: str) -> None:
    print(f"[fetch_service_ping] ERROR: {msg}", file=sys.stderr, flush=True)
    sys.exit(1)


# --------------------------------------------------------------------------
# fetch
# --------------------------------------------------------------------------
def fetch_payload(gitlab_url: str, token: str, verify_ssl: bool,
                  timeout: int, retries: int) -> dict:
    url = gitlab_url.rstrip("/") + "/api/v4/usage_data/service_ping"
    headers = {"PRIVATE-TOKEN": token}
    last_err = "unknown"
    for attempt in range(1, retries + 1):
        try:
            log(f"GET {url} (attempt {attempt}/{retries})")
            r = requests.get(url, headers=headers, timeout=timeout,
                             verify=verify_ssl)
            if r.status_code == 401:
                die("HTTP 401 — token rejected. The PAT must be created by an "
                    "instance admin with the 'read_service_ping' (or 'api') scope.")
            if r.status_code == 403:
                die("HTTP 403 — token accepted but not allowed to read the "
                    "Service Ping payload (needs read_service_ping scope / admin).")
            if r.status_code == 404:
                die("HTTP 404 — endpoint not found. /usage_data/service_ping "
                    "requires a recent GitLab version; on older instances the "
                    "payload is only available from the admin UI.")
            r.raise_for_status()
            data = r.json()
            if not isinstance(data, dict) or not data:
                die("The API returned an empty payload. The weekly Service Ping "
                    "cron has not produced data yet — check that Service Ping "
                    "generation is enabled (Admin Area > Settings > Metrics and "
                    "profiling) or trigger it manually from the Rails console.")
            return data
        except requests.RequestException as exc:            # network / 5xx
            last_err = str(exc)
            if attempt < retries:
                wait = RETRY_BACKOFF[min(attempt - 1, len(RETRY_BACKOFF) - 1)]
                log(f"attempt failed ({last_err}) — retrying in {wait}s")
                time.sleep(wait)
    die(f"could not fetch the Service Ping payload after {retries} attempts: {last_err}")
    raise AssertionError  # unreachable


# --------------------------------------------------------------------------
# flatten + summarise
# --------------------------------------------------------------------------
def flatten(obj: Any, prefix: str = "", out: dict[str, Any] | None = None,
            max_depth: int = 12) -> dict[str, Any]:
    """Flatten nested dicts to dotted keys; keep scalars and small lists."""
    if out is None:
        out = {}
    if max_depth < 0:
        return out
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            flatten(v, key, out, max_depth - 1)
    elif isinstance(obj, list):
        # short scalar lists (e.g. installed languages) kept as joined text
        if len(obj) <= 25 and all(isinstance(x, (str, int, float, bool)) for x in obj):
            out[prefix] = ", ".join(str(x) for x in obj)
        else:
            out[prefix] = f"<list of {len(obj)} items>"
    else:
        out[prefix] = obj
    return out


def _num(v: Any) -> int | float | None:
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def build_summary(payload: dict, flat: dict[str, Any]) -> dict:
    counts = payload.get("counts") or {}
    lic = payload.get("license") or {}
    sums = payload.get("sums") or {}
    duo = payload.get("duo_seats") or {}
    numeric = {k: v for k, v in flat.items()
               if isinstance(v, (int, float)) and not isinstance(v, bool)}

    def _first(*vals):
        for v in vals:
            n = _num(v)
            if n is not None and n != -1:
                return n
        return None

    # GitLab >= 19 dropped several classic counters; fall back to the closest
    # equivalents so headline KPIs and history trends stay populated.
    ci_pipelines = _first(
        counts.get("ci_pipelines"),
        (_num(counts.get("ci_internal_pipelines")) or 0)
        + (_num(counts.get("ci_external_pipelines")) or 0)
        if (counts.get("ci_internal_pipelines") is not None
            or counts.get("ci_external_pipelines") is not None) else None,
        (_num(counts.get("ci_pipeline_config_repository")) or 0)
        + (_num(counts.get("ci_pipeline_config_auto_devops")) or 0)
        if (counts.get("ci_pipeline_config_repository") is not None
            or counts.get("ci_pipeline_config_auto_devops") is not None) else None,
    )
    ci_builds = _first(counts.get("ci_builds"),
                       counts.get("count_total_create_ci_build"))
    return {
        "recorded_at": payload.get("recorded_at"),
        "version": payload.get("version"),
        "edition": payload.get("edition"),
        "installation_type": payload.get("installation_type"),
        "hostname": payload.get("hostname"),
        "uuid": payload.get("uuid"),
        "active_user_count": _num(payload.get("active_user_count")),
        "historical_max_users": _num(payload.get("historical_max_users")),
        "license_user_count": _num(payload.get("license_user_count")),
        "license_billable_users": _num(payload.get("license_billable_users")),
        "license_plan": payload.get("license_plan") or lic.get("plan"),
        "license_expires_at": payload.get("license_expires_at")
                              or lic.get("expires_at"),
        "licensee": (payload.get("licensee") or lic.get("licensee") or {}),
        # headline counters (missing keys stay None so the dashboard can hide them)
        "projects": _num(counts.get("projects")),
        "groups": _num(counts.get("groups")),
        "users": _num(counts.get("users")),
        "issues": _num(counts.get("issues")),
        "merge_requests": _num(counts.get("merge_requests")),
        "ci_pipelines": ci_pipelines,
        "ci_builds": ci_builds,
        "ci_runners": _num(counts.get("ci_runners")),
        "ci_runners_online": _num(counts.get("ci_runners_online")),
        "ci_pipeline_schedules": _num(counts.get("ci_pipeline_schedules")),
        "environments": _num(counts.get("environments")),
        "deployments": _num(counts.get("deployments")),
        "packages": _num(counts.get("packages")),
        "pages_domains": _num(counts.get("pages_domains")),
        "todos": _num(counts.get("todos")),
        "notes": _num(counts.get("notes")),
        "snippets": _num(counts.get("snippets")),
        # CI compute + Duo seats + database health (weekly trend material)
        "ci_build_minutes_monthly": _num(sums.get("sum_total_ci_build_minutes_monthly")),
        "duo_enterprise_purchased": _num(duo.get("enterprise_purchased")),
        "duo_enterprise_assigned": _num(duo.get("enterprise_assigned")),
        "duo_pro_purchased": _num(duo.get("pro_purchased")),
        "duo_pro_assigned": _num(duo.get("pro_assigned")),
        "schema_inconsistencies": len(payload.get("schema_inconsistencies_metric") or [])
                                  if isinstance(payload.get("schema_inconsistencies_metric"), list) else None,
        "index_inconsistencies": len(payload.get("index_inconsistencies") or [])
                                 if isinstance(payload.get("index_inconsistencies"), list) else None,
        "pending_migrations": len(payload.get("batched_background_migrations_metric") or [])
                              if isinstance(payload.get("batched_background_migrations_metric"), list) else None,
        "metrics_total": len(numeric),
        "metrics_failed": sum(1 for v in numeric.values() if v == -1),
    }


# --------------------------------------------------------------------------
# outputs
# --------------------------------------------------------------------------
def write_json(path: str, doc: dict) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2, ensure_ascii=False)
    log(f"wrote {path} ({os.path.getsize(path)/1024:.0f} KB)")


def write_xlsx(path: str, doc: dict) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        log(f"openpyxl not installed — skipping {path}")
        return
    wb = Workbook()
    ws = wb.active
    ws.title = "summary"
    ws.append(["field", "value"])
    for k, v in doc["summary"].items():
        ws.append([k, json.dumps(v) if isinstance(v, (dict, list)) else v])
    ws2 = wb.create_sheet("metrics")
    ws2.append(["metric", "value"])
    for k in sorted(doc["metrics_flat"]):
        ws2.append([k, doc["metrics_flat"][k]])
    for sheet in (ws, ws2):
        for cell in sheet[1]:
            cell.font = Font(bold=True)
        sheet.freeze_panes = "A2"
        sheet.column_dimensions["A"].width = 70
        sheet.column_dimensions["B"].width = 30
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    wb.save(path)
    log(f"wrote {path}")


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gitlab-url", required=True,
                    help="Base URL of the GitLab instance, e.g. https://gitlab.dx1.lseg.com")
    ap.add_argument("-o", "--output", nargs="+", required=True,
                    help="Output file(s): *.json and/or *.xlsx")
    ap.add_argument("--no-verify-ssl", action="store_true",
                    help="Disable TLS certificate verification")
    ap.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    ap.add_argument("--retries", type=int, default=DEFAULT_RETRIES)
    ap.add_argument("--from-file", metavar="PATH",
                    help="Skip the API call and read a raw payload from a local "
                         "JSON file (testing / re-packaging a UI download)")
    args = ap.parse_args()

    if args.no_verify_ssl:
        requests.packages.urllib3.disable_warnings()        # type: ignore[attr-defined]

    if args.from_file:
        log(f"reading raw payload from {args.from_file}")
        with open(args.from_file, encoding="utf-8") as fh:
            payload = json.load(fh)
    else:
        token = os.environ.get("GITLAB_TOKEN", "").strip()
        if not token:
            die("GITLAB_TOKEN environment variable is not set")
        payload = fetch_payload(args.gitlab_url, token,
                                verify_ssl=not args.no_verify_ssl,
                                timeout=args.timeout, retries=args.retries)

    # strip identity keys so metrics_flat contains only metric containers
    metric_part = {k: v for k, v in payload.items() if k not in IDENTITY_KEYS}
    flat = flatten(metric_part)
    doc = {
        "fetched_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "gitlab_url": args.gitlab_url.rstrip("/"),
        "summary": build_summary(payload, flat),
        "metrics_flat": flat,
        "payload": payload,
    }
    log(f"payload recorded_at={doc['summary']['recorded_at']} "
        f"version={doc['summary']['version']} "
        f"metrics={doc['summary']['metrics_total']} "
        f"(failed={doc['summary']['metrics_failed']})")

    for out in args.output:
        if out.lower().endswith(".xlsx"):
            write_xlsx(out, doc)
        else:
            write_json(out, doc)


if __name__ == "__main__":
    main()