#!/usr/bin/env python3
"""
build_history.py — maintain the historical instance-monitoring dataset.

Each scheduled pipeline downloads one Service Ping payload
(output/service_ping.json, produced by scripts/fetch_service_ping.py).
This script folds every snapshot into a compact, append-only history file
(history.json) that powers the dashboard's "Historical Analytics" section:

  * one entry per pipeline run: instance identity (version / edition /
    users / license) plus every numeric metric from the flattened payload;
  * the dashboard computes run-over-run deltas, trends and "biggest
    movers" client-side from those per-run metric maps.

Usage — incremental (one new pipeline run):

    python3 scripts/build_history.py \
        --history prev_history.json \
        --output  history/history.json \
        --snapshot output/service_ping.json \
        --run-id "$CI_PIPELINE_ID" \
        --generated-at "2026-08-03T04:00:00Z" \
        --source pipeline

Usage — backfill from downloaded pipeline artifacts
(service-ping-<PIPELINE_ID>.zip files, or already-extracted *.json files;
timestamps come from the archive members / file mtimes):

    python3 scripts/build_history.py \
        --output static/history_seed.json \
        --from-artifacts ./downloaded_artifacts/

Usage — carry-forward (no new data to record, e.g. SKIP_FETCH=true):

    python3 scripts/build_history.py \
        --history prev_history.json \
        --output  history/history.json \
        --allow-empty

Notes:
  * runs are deduplicated by run_id AND by the payload's recorded_at +
    content fingerprint, so re-deploying an unchanged static file (or a
    week where the cron produced no new payload) never distorts trends;
  * runs are always stored in chronological order of recorded_at.
"""

from __future__ import annotations

import argparse
import datetime as dt
import glob
import hashlib
import io
import json
import os
import sys
import zipfile

SCHEMA_VERSION = 2
SNAPSHOT_MEMBER = "output/service_ping.json"
MAX_METRICS_PER_RUN = 6000       # hard cap to keep the file bounded


def log(msg: str) -> None:
    print(f"[build_history] {msg}", flush=True)


def die(msg: str) -> None:
    print(f"[build_history] ERROR: {msg}", file=sys.stderr, flush=True)
    sys.exit(1)


def iso_utc(d: dt.datetime) -> str:
    return d.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_when(s: str) -> dt.datetime:
    s = s.strip().replace(" UTC", "").replace("Z", "+00:00")
    for fmt in (None, "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            d = dt.datetime.fromisoformat(s) if fmt is None else dt.datetime.strptime(s, fmt)
            if d.tzinfo is None:
                d = d.replace(tzinfo=dt.timezone.utc)
            return d
        except ValueError:
            continue
    raise ValueError(f"unrecognised timestamp: {s!r}")


# --------------------------------------------------------------------------
# snapshot -> run entry
# --------------------------------------------------------------------------
def numeric_metrics(flat: dict) -> dict:
    out = {}
    for k, v in flat.items():
        if isinstance(v, bool):
            out[k] = 1 if v else 0
        elif isinstance(v, (int, float)):
            out[k] = v
    if len(out) > MAX_METRICS_PER_RUN:
        log(f"warning: {len(out)} numeric metrics, keeping first "
            f"{MAX_METRICS_PER_RUN} (sorted)")
        out = dict(sorted(out.items())[:MAX_METRICS_PER_RUN])
    return out


def fingerprint(metrics: dict, summary: dict) -> str:
    blob = json.dumps({"m": metrics, "r": summary.get("recorded_at")},
                      sort_keys=True).encode()
    return hashlib.sha256(blob).hexdigest()[:16]


def make_run(snapshot: dict, run_id: str, generated_at: str, source: str) -> dict:
    summary = snapshot.get("summary") or {}
    flat = snapshot.get("metrics_flat") or {}
    if not flat and "payload" in snapshot:
        die("snapshot has no metrics_flat — was it produced by fetch_service_ping.py?")
    metrics = numeric_metrics(flat)
    return {
        "run_id": str(run_id),
        "generated_at": generated_at,
        "source": source,
        "recorded_at": summary.get("recorded_at"),
        "version": summary.get("version"),
        "edition": summary.get("edition"),
        "summary": {k: summary.get(k) for k in (
            "active_user_count", "historical_max_users", "license_user_count",
            "license_billable_users", "license_plan", "license_expires_at",
            "projects", "groups", "users", "issues", "merge_requests",
            "ci_pipelines", "ci_builds", "ci_runners", "ci_runners_online",
            "ci_build_minutes_monthly",
            "duo_enterprise_purchased", "duo_enterprise_assigned",
            "duo_pro_purchased", "duo_pro_assigned",
            "schema_inconsistencies", "index_inconsistencies",
            "pending_migrations", "metrics_total",
            "metrics_failed")},
        "fingerprint": fingerprint(metrics, summary),
        "metrics": metrics,
    }


# --------------------------------------------------------------------------
# history file handling
# --------------------------------------------------------------------------
def empty_history() -> dict:
    return {"schema_version": SCHEMA_VERSION, "updated_at": None, "runs": []}


def load_history(path: str | None) -> dict:
    if not path:
        return empty_history()
    try:
        with open(path, encoding="utf-8") as fh:
            h = json.load(fh)
    except FileNotFoundError:
        log(f"history file {path} not found — starting empty")
        return empty_history()
    except json.JSONDecodeError as exc:
        die(f"history file {path} is not valid JSON: {exc}")
    if h.get("schema_version", 1) < SCHEMA_VERSION:
        log(f"history schema v{h.get('schema_version', 1)} < v{SCHEMA_VERSION} "
            "— starting a fresh history")
        return empty_history()
    h.setdefault("runs", [])
    return h


def append_run(history: dict, run: dict) -> bool:
    runs = history["runs"]
    if any(r["run_id"] == run["run_id"] for r in runs):
        log(f"run_id {run['run_id']} already recorded — skipping")
        return False
    if runs and runs[-1].get("fingerprint") == run["fingerprint"]:
        log("content fingerprint matches the latest recorded run "
            "(same weekly payload) — skipping")
        return False
    if runs and run.get("recorded_at") and runs[-1].get("recorded_at") \
            and run["recorded_at"] < runs[-1]["recorded_at"]:
        log(f"snapshot recorded_at {run['recorded_at']} is older than the last "
            f"recorded run ({runs[-1]['recorded_at']}) — skipping (rebuild with "
            "--from-artifacts for out-of-order backfills)")
        return False
    runs.append(run)
    return True


def save_history(path: str, history: dict) -> None:
    history["updated_at"] = iso_utc(dt.datetime.now(dt.timezone.utc))
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(history, fh, separators=(",", ":"))
    log(f"wrote {path} — {len(history['runs'])} runs, "
        f"{os.path.getsize(path)/1024:.0f} KB")


# --------------------------------------------------------------------------
# backfill from artifacts
# --------------------------------------------------------------------------
def iter_artifacts(folder: str):
    """Yield (snapshot_dict, run_id, timestamp) from zips / json files."""
    entries = []
    for path in sorted(glob.glob(os.path.join(folder, "*"))):
        base = os.path.basename(path)
        if path.lower().endswith(".zip"):
            try:
                with zipfile.ZipFile(path) as zf:
                    member = next((m for m in zf.namelist()
                                   if m.endswith("service_ping.json")), None)
                    if not member:
                        log(f"{base}: no service_ping.json inside — skipped")
                        continue
                    info = zf.getinfo(member)
                    ts = dt.datetime(*info.date_time, tzinfo=dt.timezone.utc)
                    snap = json.load(io.TextIOWrapper(zf.open(member),
                                                      encoding="utf-8"))
            except (zipfile.BadZipFile, json.JSONDecodeError) as exc:
                log(f"{base}: unreadable ({exc}) — skipped")
                continue
            run_id = "".join(c for c in base if c.isdigit()) or base
            entries.append((snap, run_id, ts))
        elif path.lower().endswith(".json"):
            try:
                with open(path, encoding="utf-8") as fh:
                    snap = json.load(fh)
            except json.JSONDecodeError as exc:
                log(f"{base}: unreadable ({exc}) — skipped")
                continue
            ts = dt.datetime.fromtimestamp(os.path.getmtime(path),
                                           dt.timezone.utc)
            rec = (snap.get("summary") or {}).get("recorded_at")
            if rec:
                try:
                    ts = parse_when(rec)
                except ValueError:
                    pass
            run_id = os.path.splitext(base)[0]
            entries.append((snap, run_id, ts))
    entries.sort(key=lambda e: e[2])
    yield from entries


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--history", help="previous history.json to extend")
    ap.add_argument("--output", required=True, help="history.json to write")
    ap.add_argument("--snapshot", help="service_ping.json snapshot to append")
    ap.add_argument("--run-id", default="manual")
    ap.add_argument("--generated-at",
                    default=iso_utc(dt.datetime.now(dt.timezone.utc)))
    ap.add_argument("--source", default="pipeline",
                    choices=["pipeline", "static", "backfill"])
    ap.add_argument("--from-artifacts", metavar="DIR",
                    help="rebuild the history from downloaded artifact "
                         "zips / json files in DIR (chronological order)")
    ap.add_argument("--allow-empty", action="store_true",
                    help="permit writing the history without appending a run")
    args = ap.parse_args()

    history = load_history(args.history)

    if args.from_artifacts:
        added = 0
        for snap, run_id, ts in iter_artifacts(args.from_artifacts):
            run = make_run(snap, run_id, iso_utc(ts), "backfill")
            if append_run(history, run):
                added += 1
        log(f"backfill complete — {added} runs appended")
        if not history["runs"] and not args.allow_empty:
            die("backfill produced an empty history (no readable artifacts)")
    elif args.snapshot:
        try:
            with open(args.snapshot, encoding="utf-8") as fh:
                snap = json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError) as exc:
            die(f"cannot read snapshot {args.snapshot}: {exc}")
        run = make_run(snap, args.run_id, args.generated_at, args.source)
        if append_run(history, run):
            log(f"appended run {run['run_id']} "
                f"(recorded_at={run['recorded_at']}, "
                f"{len(run['metrics'])} metrics)")
    elif not args.allow_empty:
        die("nothing to do: provide --snapshot, --from-artifacts or --allow-empty")
    else:
        log("carry-forward — history unchanged")

    save_history(args.output, history)


if __name__ == "__main__":
    main()