"""DXOne Onboarding Pipeline Analytics collector.

Sibling of the Migration Dashboard (``dxone-migration-dashboard``), built on
the same implementation pattern: Vault-backed pipeline, incremental state,
Phoenix-theme dashboard on GitLab Pages.

Collects the FULL pipeline history of one GitLab project (pipelines, jobs,
retries, failure reasons, error messages, triggered downstream pipelines)
and aggregates it into a dashboard dataset + an append-only run history.
"""
__version__ = "1.0.0"
