"""Tunables of the pipeline-analytics collector.

Everything here can be overridden from the CLI / CI variables; the values
below are the safe defaults used when nothing else is specified.
"""
from __future__ import annotations

# First-run (backfill) window: the full pipeline history of the last
# 6 months. Subsequent runs are incremental (only pipelines updated since
# the previous run) using the restored state file.
DEFAULT_BACKFILL_DAYS = 183

# Overlap subtracted from last_run_at on incremental runs so pipelines that
# finished while the previous collection was running are never missed.
# Records are de-duplicated by pipeline id, so the overlap is free.
INCREMENTAL_OVERLAP_HOURS = 2

# Pipeline statuses that are NOT final: pipelines last seen in one of these
# states are re-fetched on every run until they settle, however old they are.
NON_FINAL_STATUSES = frozenset(
    {"created", "waiting_for_resource", "preparing", "pending",
     "running", "scheduled", "manual"})

# First N KB of a FAILED job's log downloaded for error extraction
# (reads from the END of the trace - that is where the error lives).
DEFAULT_TRACE_TAIL_KB = 64

# How deep triggered downstream pipelines are followed
# (parent -> child -> grandchild ...). Cycles are always detected.
MAX_DOWNSTREAM_DEPTH = 3

# The onboarding pipeline triggers OTHER projects' pipelines from Python
# scripts calling the GitLab trigger API (curl-style), NOT via `trigger:`
# bridge jobs - so /bridges is empty for them. Downstream pipelines are
# therefore ALSO discovered by scanning the logs of jobs whose name matches
# this regex (case-insensitive substring search): the trigger scripts print
# `Pipeline ID: <id>` / `Pipeline URL: .../pipelines/<id>` /
# `/api/v4/projects/<id>/pipelines/<id>` lines that identify the pipeline
# they created (trigger_sonarqube_onboarding, trigger_datadog_onboarding,
# prepare_trigger_artifactory_onboarding, ...).
DEFAULT_TRIGGER_JOB_PATTERN = "trigger"

# Concurrency defaults (I/O bound: pipeline details / job lists / traces)
DEFAULT_WORKERS = 12
DEFAULT_TRACE_WORKERS = 12

# Hard ceiling of error-signature groups kept in the dataset (top-N by count)
MAX_ERROR_GROUPS = 400
# Sample error lines kept per signature group
SAMPLES_PER_ERROR = 3
# Max normalised length of an error signature
MAX_SIGNATURE_LEN = 260

# Max failed-job error entries embedded per pipeline row in the dataset
MAX_ERRORS_PER_PIPELINE = 20

# State retention: records older than N days are pruned at save time so the
# state (and the dashboard dataset) stays a stable size forever.
DEFAULT_KEEP_DAYS = 190
