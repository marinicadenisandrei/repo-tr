"""Incremental fetch state.

The state file is what turns every run after the first into an *append-only
incremental* collection:

* ``pipelines``    - every pipeline record collected so far (full record:
                     detail + jobs + bridges + errors + downstream), keyed
                     by pipeline id.  The dashboard dataset is rebuilt from
                     this merged map on every run, so aggregates always stay
                     correct.
* ``last_run_at``  - upper edge of the previous collection; the next run
                     fetches pipelines updated after
                     ``last_run_at - overlap``.
* ``runs``         - a bookkeeping entry per collection run (id, timestamps,
                     window, counters).  ``build_history.py`` folds these
                     into the published run history.

Storage: gzip-compressed JSON when the filename ends in ``.gz`` (a project's
6-month history is a few thousand pipelines - small enough for a plain
``json.load``; no streaming needed here, unlike the multi-GB migration
dashboard state).
"""
from __future__ import annotations

import gzip
import json
import os
import tempfile
from datetime import datetime, timedelta, timezone

from .constants import DEFAULT_KEEP_DAYS
from .gitlab_client import parse_ts

SCHEMA_VERSION = 1


def empty_state(project_id: int | None = None) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "project_id": project_id,
        "last_run_at": None,
        "pipelines": {},     # str(pipeline_id) -> record
        "runs": [],          # collection-run bookkeeping
    }


def _open(path: str, mode: str):
    if path.endswith(".gz"):
        return gzip.open(path, mode + "t", encoding="utf-8")
    return open(path, mode, encoding="utf-8")


def load_state(path: str, project_id: int | None = None) -> dict:
    """Restore the state; falls back to an empty one on any problem
    (missing file, corrupt JSON, wrong schema, other project)."""
    if not path or not os.path.isfile(path):
        return empty_state(project_id)
    try:
        with _open(path, "r") as f:
            state = json.load(f)
    except (OSError, ValueError, EOFError):
        return empty_state(project_id)
    if not isinstance(state, dict) \
            or state.get("schema_version") != SCHEMA_VERSION:
        return empty_state(project_id)
    if project_id is not None and state.get("project_id") not in (None,
                                                                  project_id):
        # state of a different project must never be merged in
        return empty_state(project_id)
    state.setdefault("pipelines", {})
    state.setdefault("runs", [])
    if project_id is not None:
        state["project_id"] = project_id
    return state


def save_state(state: dict, path: str) -> None:
    """Atomic write (tmp file + rename) so a killed pod never leaves a
    truncated state behind for the next run to trip over."""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=directory,
                               suffix=".gz" if path.endswith(".gz") else "")
    os.close(fd)
    try:
        with _open(tmp, "w") as f:
            json.dump(state, f, separators=(",", ":"))
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def prune_state(state: dict, keep_days: int = DEFAULT_KEEP_DAYS,
                now: datetime | None = None) -> int:
    """Drop pipeline records last updated more than ``keep_days`` ago so the
    state (and everything built from it) stays a stable size forever.
    Returns the number of records dropped.  ``keep_days=0`` keeps all."""
    if not keep_days:
        return 0
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(days=keep_days)
    doomed = []
    for pid, rec in state.get("pipelines", {}).items():
        ts = parse_ts(rec.get("updated_at") or rec.get("created_at"))
        if ts is not None and ts < cutoff:
            doomed.append(pid)
    for pid in doomed:
        del state["pipelines"][pid]
    return len(doomed)


def non_final_pipeline_ids(state: dict,
                           non_final: frozenset) -> list[int]:
    """Pipelines last seen in a non-final status - re-fetched every run
    until they settle, however old the record."""
    out = []
    for pid, rec in state.get("pipelines", {}).items():
        if rec.get("status") in non_final:
            try:
                out.append(int(pid))
            except (TypeError, ValueError):
                continue
    return out


def record_run(state: dict, run_entry: dict, max_runs: int = 1000) -> None:
    state.setdefault("runs", []).append(run_entry)
    if max_runs and len(state["runs"]) > max_runs:
        state["runs"] = state["runs"][-max_runs:]
