"""Command-line entry point.

    python3 -m pipescan --project-id 12811 \
        --gitlab-url https://gitlab.dx1.lseg.com \
        --state-file output/state.json.gz \
        -o output/pipeline_analytics.json output/pipelines.csv

First run: full 6-month backfill.  Later runs: incremental (only pipelines
updated since the previous run, plus every pipeline previously seen in a
non-final state).  The dataset is always rebuilt from the merged records.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from datetime import datetime, timezone

from .collector import Collector
from .constants import (DEFAULT_BACKFILL_DAYS, DEFAULT_KEEP_DAYS,
                        DEFAULT_TRACE_TAIL_KB, DEFAULT_TRACE_WORKERS,
                        DEFAULT_WORKERS, MAX_DOWNSTREAM_DEPTH)
from .dataset import build_dataset
from .gitlab_client import GitLabClient, normalize_gitlab_url
from .http import RateLimiter
from .logging_utils import log
from .state import load_state, prune_state, record_run, save_state


def _env(name: str, default: str) -> str:
    return os.environ.get(name, "").strip() or default


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pipescan",
        description="GitLab pipeline analytics collector "
                    "(DXOne Onboarding Dashboard)")
    p.add_argument("--gitlab-url", default=_env("TARGET_GITLAB_URL",
                                                "https://gitlab.dx1.lseg.com"))
    p.add_argument("--project-id", type=int, required=True,
                   help="numeric GitLab project id (onboarding-master: 12811)")
    p.add_argument("--token", default=os.environ.get("GITLAB_TOKEN", ""),
                   help="defaults to $GITLAB_TOKEN")
    p.add_argument("--auth-mode", choices=["private-token", "bearer"],
                   default="private-token")
    p.add_argument("--no-verify-ssl", action="store_true")
    p.add_argument("--backfill-days", type=int,
                   default=int(_env("BACKFILL_DAYS",
                                    str(DEFAULT_BACKFILL_DAYS))),
                   help="first-run window (default: %(default)s = 6 months)")
    p.add_argument("--keep-days", type=int,
                   default=int(_env("DATA_KEEP_DAYS",
                                    str(DEFAULT_KEEP_DAYS))),
                   help="prune records older than N days (0 = keep forever)")
    p.add_argument("--force-full", action="store_true",
                   help="ignore any previous state; full backfill")
    p.add_argument("--state-file", default="output/state.json.gz")
    p.add_argument("-o", "--output", nargs="+",
                   default=["output/pipeline_analytics.json"],
                   help=".json dataset and optional .csv pipeline export")
    p.add_argument("--workers", type=int,
                   default=int(_env("PIPE_WORKERS", str(DEFAULT_WORKERS))))
    p.add_argument("--trace-workers", type=int,
                   default=int(_env("PIPE_TRACE_WORKERS",
                                    str(DEFAULT_TRACE_WORKERS))))
    p.add_argument("--trace-tail-kb", type=int,
                   default=int(_env("PIPE_TRACE_TAIL_KB",
                                    str(DEFAULT_TRACE_TAIL_KB))))
    p.add_argument("--max-downstream-depth", type=int,
                   default=int(_env("PIPE_DOWNSTREAM_DEPTH",
                                    str(MAX_DOWNSTREAM_DEPTH))))
    p.add_argument("--skip-traces", action="store_true",
                   help="no failed-job log downloads (no error analytics)")
    p.add_argument("--rps", type=float, default=float(_env("PIPE_RPS", "0")),
                   help="optional hard requests/second ceiling (0 = off)")
    return p


def write_csv(dataset: dict, path: str) -> None:
    cols = ["id", "status", "source", "trigger_source", "env", "asset_id",
            "ref", "user", "created_at", "finished_at", "duration",
            "queued_duration", "jobs_total", "jobs_failed", "retries",
            "downstream_total", "downstream_failed", "failed_jobs",
            "web_url"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for row in dataset.get("pipelines", []):
            w.writerow([";".join(row.get(c) or [])
                        if c == "failed_jobs" else row.get(c, "")
                        for c in cols])


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not args.token:
        print("No token: set $GITLAB_TOKEN or pass --token", file=sys.stderr)
        return 2

    gitlab_url = normalize_gitlab_url(args.gitlab_url)
    limiter = RateLimiter(args.rps)
    pool = args.workers + args.trace_workers + 2
    client = GitLabClient(gitlab_url, args.token,
                          verify_ssl=not args.no_verify_ssl,
                          auth_mode=args.auth_mode, pool_size=pool,
                          limiter=limiter)

    ping = client.ping()
    if not ping.get("ok"):
        print(f"GitLab API check failed: {ping.get('error')}",
              file=sys.stderr)
        return 2
    log(f"Connected to {gitlab_url} (GitLab {ping.get('version', '?')})")

    project = client.get_project(args.project_id)
    if project is None:
        print(f"Project {args.project_id} not found / not accessible",
              file=sys.stderr)
        return 2
    log(f"Target project: {project.get('path_with_namespace')} "
        f"(id {args.project_id})")

    state = load_state(args.state_file, project_id=args.project_id)
    prev_pipelines = len(state.get("pipelines", {}))
    log(f"State: {prev_pipelines} accumulated pipeline record(s), "
        f"last_run_at={state.get('last_run_at') or 'never'}")

    collector = Collector(client, args.project_id,
                          workers=args.workers,
                          trace_workers=args.trace_workers,
                          trace_tail_kb=args.trace_tail_kb,
                          max_downstream_depth=args.max_downstream_depth,
                          fetch_traces=not args.skip_traces)

    run_started = datetime.now(timezone.utc)
    updated_after, mode = collector.plan_window(state, args.backfill_days,
                                                force_full=args.force_full)
    if args.force_full:
        state["pipelines"] = {}
    result = collector.collect(state, updated_after, mode)
    pruned = prune_state(state, args.keep_days)
    run_finished = datetime.now(timezone.utc)

    state["last_run_at"] = run_finished.isoformat(timespec="seconds")
    record_run(state, {
        "run_at": run_started.isoformat(timespec="seconds"),
        "finished_at": run_finished.isoformat(timespec="seconds"),
        "elapsed_s": round((run_finished - run_started).total_seconds(), 1),
        "mode": mode,
        "updated_after": result["updated_after"],
        "collected": result["collected"],
        "new_pipelines": result["new"],
        "refreshed_pipelines": result["updated"],
        "pruned": pruned,
        "jobs_seen": collector.stats["jobs"],
        "traces_fetched": collector.stats["traces"],
        "downstream_collected": collector.stats["downstream"],
        "pipeline_total_after": len(state["pipelines"]),
        "ci_pipeline_id": os.environ.get("CI_PIPELINE_ID"),
        "ci_pipeline_url": (f"{os.environ['CI_PROJECT_URL']}/-/pipelines/"
                            f"{os.environ['CI_PIPELINE_ID']}"
                            if os.environ.get("CI_PROJECT_URL")
                            and os.environ.get("CI_PIPELINE_ID") else None),
    })
    save_state(state, args.state_file)
    log(f"State saved: {len(state['pipelines'])} pipeline record(s) "
        f"({pruned} pruned) -> next run is INCREMENTAL")

    window = {
        "mode": mode,
        "from": updated_after.isoformat(timespec="seconds"),
        "to": run_finished.isoformat(timespec="seconds"),
        "backfill_days": args.backfill_days,
    }
    dataset = build_dataset(state, project, gitlab_url, window)

    json_out = csv_out = None
    for path in args.output:
        if path.endswith(".csv"):
            csv_out = path
        else:
            json_out = path
    for path in filter(None, (json_out, csv_out)):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    if json_out:
        with open(json_out, "w", encoding="utf-8") as f:
            json.dump(dataset, f, separators=(",", ":"))
        log(f"Dataset written: {json_out} "
            f"({os.path.getsize(json_out) // 1024} KB)")
    if csv_out:
        write_csv(dataset, csv_out)
        log(f"CSV written: {csv_out}")

    # tiny sidecar consumed by the CI job-log summary (never json.load the
    # big files in the pipeline just to print totals)
    if json_out:
        s = dataset["summary"]
        sidecar = {
            "window": window,
            "state": {"pipelines": len(state["pipelines"]),
                      "last_run_at": state["last_run_at"]},
            "summary": {"pipelines": s["pipelines"],
                        "success": s["success"], "failed": s["failed"],
                        "success_rate": s["success_rate"],
                        "jobs": s["jobs"],
                        "job_failures": s["job_failures"],
                        "retries": s["retries"],
                        "downstream": s["downstream_pipelines"],
                        "error_groups": s["error_groups"]},
        }
        with open(os.path.join(os.path.dirname(json_out) or ".",
                               "summary.json"), "w", encoding="utf-8") as f:
            json.dump(sidecar, f, indent=2)

    log(f"Done: mode={mode} collected={result['collected']} "
        f"(new={result['new']}, refreshed={result['updated']}) "
        f"jobs={collector.stats['jobs']} traces={collector.stats['traces']} "
        f"downstream={collector.stats['downstream']}")
    return 0
