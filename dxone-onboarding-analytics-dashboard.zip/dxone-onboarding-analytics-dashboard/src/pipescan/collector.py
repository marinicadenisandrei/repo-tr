"""Concurrent collection of the full pipeline history of one project.

Per pipeline the collector gathers:

* the **detail** record (duration, queued_duration, source, ref, user,
  workflow name - which for the onboarding pipeline encodes the asset id,
  trigger source and environment: ``Onboarding asset [APP-…] Triggered from
  [SNOW prod]``);
* every **job** including retried attempts (status, stage, duration,
  queued_duration, failure_reason, runner, allow_failure);
* every **bridge** (trigger job) and, recursively, the **downstream
  pipelines** it created - detail + jobs, up to ``MAX_DOWNSTREAM_DEPTH``
  levels, cycle-safe;
* for every failed job the **tail of the log**, distilled into error lines
  and stable error **signatures** (see ``errors.py``).

Concurrency: pipelines are processed by a thread pool; inside one pipeline
the trace downloads of its failed jobs run on a second pool.  Every request
goes through the shared rate limiter.
"""
from __future__ import annotations

import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone

from .constants import (DEFAULT_TRACE_TAIL_KB, DEFAULT_WORKERS,
                        DEFAULT_TRACE_WORKERS, INCREMENTAL_OVERLAP_HOURS,
                        MAX_DOWNSTREAM_DEPTH, MAX_ERRORS_PER_PIPELINE,
                        NON_FINAL_STATUSES)
from .errors import extract_error_lines, normalize_signature
from .gitlab_client import GitLabClient, parse_ts
from .logging_utils import log
from .state import non_final_pipeline_ids

# "Onboarding asset [APP-01680] Triggered from [SNOW prod]" /
# "... Triggered from [LMP dev], Orchestrator ID: 123"
_NAME_RE = re.compile(
    r"asset\s*\[(?P<asset>[^\]]+)\].*?from\s*\[(?P<src>[A-Za-z0-9_-]+)"
    r"(?:\s+(?P<env>[A-Za-z0-9_-]+))?\]", re.I)


def parse_workflow_name(name: str | None) -> dict:
    """asset id / trigger source / environment out of the workflow name."""
    out = {"asset_id": None, "trigger_source": None, "env": None}
    if not name:
        return out
    m = _NAME_RE.search(name)
    if m:
        out["asset_id"] = (m.group("asset") or "").strip() or None
        out["trigger_source"] = (m.group("src") or "").strip().upper() or None
        out["env"] = (m.group("env") or "").strip().lower() or None
    return out


def _slim_user(user: dict | None) -> dict | None:
    if not isinstance(user, dict):
        return None
    return {"username": user.get("username"), "name": user.get("name")}


def _slim_runner(runner: dict | None) -> dict | None:
    if not isinstance(runner, dict):
        return None
    return {"id": runner.get("id"),
            "description": runner.get("description"),
            "runner_type": runner.get("runner_type")}


def _slim_job(job: dict) -> dict:
    return {
        "id": job.get("id"),
        "name": job.get("name"),
        "stage": job.get("stage"),
        "status": job.get("status"),
        "created_at": job.get("created_at"),
        "started_at": job.get("started_at"),
        "finished_at": job.get("finished_at"),
        "duration": job.get("duration"),
        "queued_duration": job.get("queued_duration"),
        "failure_reason": job.get("failure_reason"),
        "allow_failure": bool(job.get("allow_failure")),
        "retried": bool(job.get("retried")),
        "web_url": job.get("web_url"),
        "runner": _slim_runner(job.get("runner")),
    }


class Collector:
    def __init__(self, client: GitLabClient, project_id: int,
                 workers: int = DEFAULT_WORKERS,
                 trace_workers: int = DEFAULT_TRACE_WORKERS,
                 trace_tail_kb: int = DEFAULT_TRACE_TAIL_KB,
                 max_downstream_depth: int = MAX_DOWNSTREAM_DEPTH,
                 fetch_traces: bool = True) -> None:
        self.client = client
        self.project_id = project_id
        self.workers = max(1, workers)
        self.trace_workers = max(1, trace_workers)
        self.trace_tail_bytes = max(4, trace_tail_kb) * 1024
        self.max_depth = max(0, max_downstream_depth)
        self.fetch_traces = fetch_traces
        self._done = 0
        self._lock = threading.Lock()
        self.stats = {"pipelines": 0, "jobs": 0, "bridges": 0,
                      "downstream": 0, "traces": 0, "errors": 0}

    # ------------------------------------------------------------------ #
    # window planning                                                    #
    # ------------------------------------------------------------------ #
    def plan_window(self, state: dict, backfill_days: int,
                    force_full: bool = False) -> tuple[datetime, str]:
        """(updated_after, mode) of this run.

        * no restorable state / ``force_full``  -> full ``backfill_days``
          backfill (**the 6-month initial collection**);
        * otherwise                             -> incremental: pipelines
          updated after ``last_run_at - overlap``.
        """
        now = datetime.now(timezone.utc)
        last = None if force_full else parse_ts(state.get("last_run_at"))
        if last is None:
            return now - timedelta(days=backfill_days), "full"
        return last - timedelta(hours=INCREMENTAL_OVERLAP_HOURS), \
            "incremental"

    # ------------------------------------------------------------------ #
    # per-pipeline collection                                            #
    # ------------------------------------------------------------------ #
    def _collect_errors(self, project_id: int,
                        failed_jobs: list[dict]) -> list[dict]:
        """Log-tail error extraction for the failed jobs of ONE pipeline."""
        if not (self.fetch_traces and failed_jobs):
            return []
        results: list[dict] = []

        def one(job: dict) -> dict | None:
            tail = self.client.fetch_trace_tail(project_id, job["id"],
                                                self.trace_tail_bytes)
            with self._lock:
                self.stats["traces"] += 1
            lines = extract_error_lines(tail)
            if not lines:
                return None
            return {"job_id": job["id"], "job_name": job.get("name"),
                    "stage": job.get("stage"),
                    "failure_reason": job.get("failure_reason"),
                    "job_url": job.get("web_url"),
                    "message": lines[0],
                    "signature": normalize_signature(lines[0]),
                    "context": lines[1:3]}

        pool = min(self.trace_workers, max(1, len(failed_jobs)))
        with ThreadPoolExecutor(max_workers=pool) as ex:
            for fut in as_completed(ex.submit(one, j)
                                    for j in failed_jobs
                                    [:MAX_ERRORS_PER_PIPELINE]):
                try:
                    entry = fut.result()
                except Exception as e:            # noqa: BLE001
                    log(f"    [!] trace fetch failed: {e}", err=True)
                    continue
                if entry:
                    results.append(entry)
        with self._lock:
            self.stats["errors"] += len(results)
        return results

    def _collect_downstream(self, bridges: list[dict], depth: int,
                            seen: set[tuple[int, int]]) -> list[dict]:
        """Downstream pipelines created by the bridges - recursively."""
        out: list[dict] = []
        for bridge in bridges:
            dsp = bridge.get("downstream_pipeline") or {}
            ds_pid, ds_proj = dsp.get("id"), dsp.get("project_id")
            entry = {
                "bridge_name": bridge.get("name"),
                "bridge_status": bridge.get("status"),
                "pipeline_id": ds_pid,
                "project_id": ds_proj,
                "status": dsp.get("status"),
                "web_url": dsp.get("web_url"),
                "ref": dsp.get("ref"),
                "kind": "child" if ds_proj == self.project_id
                        else "multi-project",
                "detail": None,
            }
            if ds_pid and ds_proj and depth < self.max_depth \
                    and (ds_proj, ds_pid) not in seen:
                seen.add((ds_proj, ds_pid))
                entry["detail"] = self._collect_pipeline(
                    ds_proj, ds_pid, depth=depth + 1, seen=seen,
                    downstream=True)
                with self._lock:
                    self.stats["downstream"] += 1
            out.append(entry)
        return out

    def _collect_pipeline(self, project_id: int, pipeline_id: int,
                          listing: dict | None = None, depth: int = 0,
                          seen: set[tuple[int, int]] | None = None,
                          downstream: bool = False) -> dict | None:
        """One full pipeline record: detail + jobs + errors + downstream."""
        seen = seen if seen is not None else {(project_id, pipeline_id)}
        detail = self.client.get_pipeline(project_id, pipeline_id) \
            or dict(listing or {})
        if not detail:
            return None
        jobs_raw = self.client.list_pipeline_jobs(project_id, pipeline_id)
        jobs = [_slim_job(j) for j in jobs_raw]
        bridges = self.client.list_pipeline_bridges(project_id, pipeline_id)
        with self._lock:
            self.stats["jobs"] += len(jobs)
            self.stats["bridges"] += len(bridges)
        failed = [j for j in jobs
                  if j["status"] == "failed" and not j["retried"]]
        errors = self._collect_errors(project_id, failed)
        meta = parse_workflow_name(detail.get("name"))

        record = {
            "id": detail.get("id", pipeline_id),
            "iid": detail.get("iid"),
            "project_id": project_id,
            "is_downstream": downstream,
            "status": detail.get("status"),
            "source": detail.get("source"),
            "ref": detail.get("ref"),
            "sha": (detail.get("sha") or "")[:12],
            "name": detail.get("name"),
            "asset_id": meta["asset_id"],
            "trigger_source": meta["trigger_source"],
            "env": meta["env"],
            "user": _slim_user(detail.get("user")),
            "created_at": detail.get("created_at"),
            "started_at": detail.get("started_at"),
            "finished_at": detail.get("finished_at"),
            "updated_at": detail.get("updated_at"),
            "duration": detail.get("duration"),
            "queued_duration": detail.get("queued_duration"),
            "web_url": detail.get("web_url"),
            "jobs": jobs,
            "errors": errors,
            "downstream": self._collect_downstream(bridges, depth, seen),
        }
        return record

    # ------------------------------------------------------------------ #
    # main entry                                                         #
    # ------------------------------------------------------------------ #
    def collect(self, state: dict, updated_after: datetime,
                mode: str) -> dict:
        """List + collect every pipeline updated inside the window, plus
        re-collect pipelines previously seen in a non-final state; merge
        everything into ``state['pipelines']`` (newest record wins)."""
        listings = self.client.list_pipelines(self.project_id, updated_after)
        refresh = set(non_final_pipeline_ids(state, NON_FINAL_STATUSES))
        listed_ids = {p["id"] for p in listings}
        todo: list[tuple[int, dict | None]] = \
            [(p["id"], p) for p in listings] + \
            [(pid, None) for pid in sorted(refresh - listed_ids)]
        log(f"  window={mode} updated_after={updated_after:%Y-%m-%d %H:%M} "
            f"-> {len(listings)} listed pipeline(s) + "
            f"{len(todo) - len(listings)} unsettled to refresh")

        total = len(todo)

        def one(item: tuple[int, dict | None]) -> dict | None:
            pid, listing = item
            rec = self._collect_pipeline(self.project_id, pid, listing)
            with self._lock:
                self._done += 1
                if self._done % 50 == 0 or self._done == total:
                    log(f"  … {self._done}/{total} pipelines collected")
            return rec

        collected: list[dict] = []
        if todo:
            with ThreadPoolExecutor(max_workers=self.workers) as ex:
                for fut in as_completed(ex.submit(one, t) for t in todo):
                    try:
                        rec = fut.result()
                    except Exception as e:        # noqa: BLE001
                        log(f"  [!] pipeline collection failed: {e}",
                            err=True)
                        continue
                    if rec:
                        collected.append(rec)

        new_ids, updated_ids = [], []
        pipelines = state.setdefault("pipelines", {})
        for rec in collected:
            key = str(rec["id"])
            (updated_ids if key in pipelines else new_ids).append(rec["id"])
            pipelines[key] = rec
        self.stats["pipelines"] = len(collected)
        return {"collected": len(collected), "new": len(new_ids),
                "updated": len(updated_ids), "mode": mode,
                "updated_after": updated_after.isoformat()}
