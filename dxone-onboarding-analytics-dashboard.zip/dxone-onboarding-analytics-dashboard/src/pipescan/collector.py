"""Concurrent collection of the full pipeline history of one project.

Per pipeline the collector gathers:

* the **detail** record (duration, queued_duration, source, ref, user,
  workflow name - which for the onboarding pipeline encodes the asset id,
  trigger source and environment: ``Onboarding asset [APP-…] Triggered from
  [SNOW prod]``);
* every **job** including retried attempts (status, stage, duration,
  queued_duration, failure_reason, runner, allow_failure);
* every **bridge** (trigger job) and, recursively, the **downstream
  pipelines** it created - detail + jobs, up to ``MAX_DOWNSTREAM_DEPTH``
  levels, cycle-safe;
* for every failed job the **tail of the log**, distilled into error lines
  and stable error **signatures** (see ``errors.py``).

Concurrency: pipelines are processed by a thread pool; inside one pipeline
the trace downloads of its failed jobs run on a second pool.  Every request
goes through the shared rate limiter.
"""
from __future__ import annotations

import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone

from .constants import (DEFAULT_TRACE_TAIL_KB, DEFAULT_TRIGGER_JOB_PATTERN,
                        DEFAULT_WORKERS,
                        DEFAULT_TRACE_WORKERS, INCREMENTAL_OVERLAP_HOURS,
                        MAX_DOWNSTREAM_DEPTH, MAX_ERRORS_PER_PIPELINE,
                        NON_FINAL_STATUSES)
from .errors import extract_error_lines, normalize_signature
from .gitlab_client import GitLabClient, parse_ts
from .logging_utils import log
from .state import (non_final_pipeline_ids,
                    unsettled_downstream_parent_ids)

# "Onboarding asset [APP-01680] Triggered from [SNOW prod]" /
# "... Triggered from [LMP dev], Orchestrator ID: 123"
_NAME_RE = re.compile(
    r"asset\s*\[(?P<asset>[^\]]+)\].*?from\s*\[(?P<src>[A-Za-z0-9_-]+)"
    r"(?:\s+(?P<env>[A-Za-z0-9_-]+))?\]", re.I)


def parse_workflow_name(name: str | None) -> dict:
    """asset id / trigger source / environment out of the workflow name."""
    out = {"asset_id": None, "trigger_source": None, "env": None}
    if not name:
        return out
    m = _NAME_RE.search(name)
    if m:
        out["asset_id"] = (m.group("asset") or "").strip() or None
        out["trigger_source"] = (m.group("src") or "").strip().upper() or None
        out["env"] = (m.group("env") or "").strip().lower() or None
    return out


def _slim_user(user: dict | None) -> dict | None:
    if not isinstance(user, dict):
        return None
    return {"username": user.get("username"), "name": user.get("name")}


# --------------------------------------------------------------------- #
# downstream references inside trigger-job logs                          #
# --------------------------------------------------------------------- #
# The onboarding trigger scripts create downstream pipelines through the
# GitLab trigger API and then print lines like:
#   POST .../api/v4/projects/46317/trigger/pipeline
#   Pipeline ID: 123456
#   Pipeline URL: https://gitlab.../app/.../artifactory-automation/pipelines/123456
#   Datadog pipeline URL: https://gitlab.../api/v4/projects/93334/pipelines/123456
_API_PIPE_RE = re.compile(r"/api/v4/projects/(\d+)/pipelines/(\d+)")
_TRIGGER_CTX_RE = re.compile(r"/api/v4/projects/(\d+)/trigger/pipeline")
_PIPE_ID_RE = re.compile(r"\bpipeline\s*id\s*[:=]\s*(\d+)", re.I)
_WEB_PIPE_RE = re.compile(
    r"https?://[^/\s\"']+/((?:[\w][\w.-]*/)+[\w][\w.-]*?)"
    r"/(?:-/)?pipelines/(\d+)")


def extract_downstream_refs(text: str) -> list[dict]:
    """(project, pipeline_id) references to API-triggered downstream
    pipelines found in one trigger-job log.

    ``project`` is an **int id** when the log contained an API URL, or a
    **path string** when only a web URL was printed (resolved to an id
    later through the project cache). Bare ``Pipeline ID: N`` lines are
    paired with the project of the closest preceding
    ``/trigger/pipeline`` call. Order-preserving, de-duplicated.
    """
    refs: list[dict] = []
    seen: set[tuple[object, int]] = set()

    def add(project: object, pid: int) -> None:
        key = (project, pid)
        if key not in seen:
            seen.add(key)
            refs.append({"project": project, "pipeline_id": pid})

    ctx_project: int | None = None
    for line in (text or "").splitlines():
        m = _TRIGGER_CTX_RE.search(line)
        if m:
            ctx_project = int(m.group(1))
        for m in _API_PIPE_RE.finditer(line):
            add(int(m.group(1)), int(m.group(2)))
        for m in _WEB_PIPE_RE.finditer(line):
            path = m.group(1)
            if not path.startswith(("api/", "api/v4/")):
                add(path, int(m.group(2)))
        if ctx_project is not None:
            for m in _PIPE_ID_RE.finditer(line):
                add(ctx_project, int(m.group(1)))
    # an id-based ref supersedes a path-based ref to the same pipeline id
    id_pids = {r["pipeline_id"] for r in refs
               if isinstance(r["project"], int)}
    return [r for r in refs
            if isinstance(r["project"], int)
            or r["pipeline_id"] not in id_pids]


def _slim_runner(runner: dict | None) -> dict | None:
    if not isinstance(runner, dict):
        return None
    return {"id": runner.get("id"),
            "description": runner.get("description"),
            "runner_type": runner.get("runner_type")}


def _slim_job(job: dict) -> dict:
    return {
        "id": job.get("id"),
        "name": job.get("name"),
        "stage": job.get("stage"),
        "status": job.get("status"),
        "created_at": job.get("created_at"),
        "started_at": job.get("started_at"),
        "finished_at": job.get("finished_at"),
        "duration": job.get("duration"),
        "queued_duration": job.get("queued_duration"),
        "failure_reason": job.get("failure_reason"),
        "allow_failure": bool(job.get("allow_failure")),
        "retried": bool(job.get("retried")),
        "web_url": job.get("web_url"),
        "runner": _slim_runner(job.get("runner")),
    }


class Collector:
    def __init__(self, client: GitLabClient, project_id: int,
                 workers: int = DEFAULT_WORKERS,
                 trace_workers: int = DEFAULT_TRACE_WORKERS,
                 trace_tail_kb: int = DEFAULT_TRACE_TAIL_KB,
                 max_downstream_depth: int = MAX_DOWNSTREAM_DEPTH,
                 fetch_traces: bool = True,
                 trigger_job_pattern: str = DEFAULT_TRIGGER_JOB_PATTERN,
                 project_cache: dict | None = None) -> None:
        self.client = client
        self.project_id = project_id
        self.workers = max(1, workers)
        self.trace_workers = max(1, trace_workers)
        self.trace_tail_bytes = max(4, trace_tail_kb) * 1024
        self.max_depth = max(0, max_downstream_depth)
        self.fetch_traces = fetch_traces
        self.trigger_job_re = re.compile(trigger_job_pattern, re.I) \
            if trigger_job_pattern else None
        # {str(project_id): {name, path, web_url}} - shared with the state
        # so project lookups survive across runs; None values cache misses.
        self.projects = project_cache if project_cache is not None else {}
        self._path_ids: dict[str, int | None] = {}
        self._done = 0
        self._lock = threading.Lock()
        self.stats = {"pipelines": 0, "jobs": 0, "bridges": 0,
                      "downstream": 0, "traces": 0, "errors": 0}

    # ------------------------------------------------------------------ #
    # project resolution (id <-> path, display names)                    #
    # ------------------------------------------------------------------ #
    def _project_info(self, project_id: int) -> dict | None:
        key = str(project_id)
        with self._lock:
            if key in self.projects:
                return self.projects[key]
        info = None
        try:
            p = self.client.get_project(project_id)
            if p:
                info = {"id": p.get("id", project_id),
                        "name": p.get("name"),
                        "path": p.get("path_with_namespace"),
                        "web_url": p.get("web_url")}
        except Exception as e:                    # noqa: BLE001
            log(f"    [!] project {project_id} lookup failed: {e}",
                err=True)
        with self._lock:
            self.projects[key] = info
        return info

    def _resolve_project(self, ref: int | str) -> tuple[int | None,
                                                        dict | None]:
        """(project_id, info) for an int id or a full path string."""
        if isinstance(ref, int):
            return ref, self._project_info(ref)
        path = str(ref).strip("/")
        with self._lock:
            if path in self._path_ids:
                pid = self._path_ids[path]
                return pid, (self._project_info(pid)
                             if pid is not None else None)
        pid = None
        try:
            p = self.client.get_project(path)
            if p and p.get("id") is not None:
                pid = int(p["id"])
                info = {"id": pid, "name": p.get("name"),
                        "path": p.get("path_with_namespace"),
                        "web_url": p.get("web_url")}
                with self._lock:
                    self.projects[str(pid)] = info
        except Exception as e:                    # noqa: BLE001
            log(f"    [!] project path '{path}' lookup failed: {e}",
                err=True)
        with self._lock:
            self._path_ids[path] = pid
        return pid, (self._project_info(pid) if pid is not None else None)

    # ------------------------------------------------------------------ #
    # window planning                                                    #
    # ------------------------------------------------------------------ #
    def plan_window(self, state: dict, backfill_days: int,
                    force_full: bool = False) -> tuple[datetime, str]:
        """(updated_after, mode) of this run.

        * no restorable state / ``force_full``  -> full ``backfill_days``
          backfill (**the 6-month initial collection**);
        * otherwise                             -> incremental: pipelines
          updated after ``last_run_at - overlap``.
        """
        now = datetime.now(timezone.utc)
        last = None if force_full else parse_ts(state.get("last_run_at"))
        if last is None:
            return now - timedelta(days=backfill_days), "full"
        return last - timedelta(hours=INCREMENTAL_OVERLAP_HOURS), \
            "incremental"

    # ------------------------------------------------------------------ #
    # per-pipeline collection                                            #
    # ------------------------------------------------------------------ #
    def _collect_errors(self, project_id: int,
                        failed_jobs: list[dict]) -> list[dict]:
        """Log-tail error extraction for the failed jobs of ONE pipeline."""
        if not (self.fetch_traces and failed_jobs):
            return []
        results: list[dict] = []

        def one(job: dict) -> dict | None:
            tail = self.client.fetch_trace_tail(project_id, job["id"],
                                                self.trace_tail_bytes)
            with self._lock:
                self.stats["traces"] += 1
            lines = extract_error_lines(tail)
            if not lines:
                return None
            return {"job_id": job["id"], "job_name": job.get("name"),
                    "stage": job.get("stage"),
                    "failure_reason": job.get("failure_reason"),
                    "job_url": job.get("web_url"),
                    "message": lines[0],
                    "signature": normalize_signature(lines[0]),
                    "context": lines[1:3]}

        pool = min(self.trace_workers, max(1, len(failed_jobs)))
        with ThreadPoolExecutor(max_workers=pool) as ex:
            for fut in as_completed(ex.submit(one, j)
                                    for j in failed_jobs
                                    [:MAX_ERRORS_PER_PIPELINE]):
                try:
                    entry = fut.result()
                except Exception as e:            # noqa: BLE001
                    log(f"    [!] trace fetch failed: {e}", err=True)
                    continue
                if entry:
                    results.append(entry)
        with self._lock:
            self.stats["errors"] += len(results)
        return results

    def _collect_downstream(self, bridges: list[dict], depth: int,
                            seen: set[tuple[int, int]]) -> list[dict]:
        """Downstream pipelines created by the bridges - recursively."""
        out: list[dict] = []
        for bridge in bridges:
            dsp = bridge.get("downstream_pipeline") or {}
            ds_pid, ds_proj = dsp.get("id"), dsp.get("project_id")
            info = self._project_info(ds_proj) if ds_proj else None
            entry = {
                "bridge_name": bridge.get("name"),
                "bridge_status": bridge.get("status"),
                "pipeline_id": ds_pid,
                "project_id": ds_proj,
                "project_name": (info or {}).get("name"),
                "project_path": (info or {}).get("path"),
                "status": dsp.get("status"),
                "web_url": dsp.get("web_url"),
                "ref": dsp.get("ref"),
                "kind": "child" if ds_proj == self.project_id
                        else "multi-project",
                "detail": None,
            }
            if ds_pid and ds_proj and depth < self.max_depth \
                    and (ds_proj, ds_pid) not in seen:
                seen.add((ds_proj, ds_pid))
                entry["detail"] = self._collect_pipeline(
                    ds_proj, ds_pid, depth=depth + 1, seen=seen,
                    downstream=True)
                with self._lock:
                    self.stats["downstream"] += 1
            out.append(entry)
        return out

    def _collect_api_downstream(self, jobs: list[dict], depth: int,
                                seen: set[tuple[int, int]]) -> list[dict]:
        """Downstream pipelines created by TRIGGER-API calls inside jobs.

        The onboarding pipeline starts other projects' pipelines from
        Python scripts (``trigger_sonarqube_onboarding``,
        ``trigger_datadog_onboarding``,
        ``prepare_trigger_artifactory_onboarding`` ...) - those never
        appear under ``/bridges``, so the logs of every job whose name
        matches ``trigger_job_re`` are scanned for the pipeline
        references the scripts print, and each referenced pipeline is
        fetched from its own project.
        """
        if not (self.fetch_traces and self.trigger_job_re) or depth > 0:
            return []
        trigger_jobs = [j for j in jobs
                        if j.get("name")
                        and self.trigger_job_re.search(j["name"])
                        and j.get("status") not in ("created", "pending",
                                                    "skipped")]
        if not trigger_jobs:
            return []
        out: list[dict] = []
        for job in trigger_jobs:
            try:
                tail = self.client.fetch_trace_tail(
                    self.project_id, job["id"], self.trace_tail_bytes)
            except Exception as e:                # noqa: BLE001
                log(f"    [!] trigger-log fetch failed "
                    f"(job {job.get('id')}): {e}", err=True)
                continue
            with self._lock:
                self.stats["traces"] += 1
            for ref in extract_downstream_refs(tail):
                pid, info = self._resolve_project(ref["project"])
                ds_id = ref["pipeline_id"]
                if pid is None or (pid, ds_id) in seen:
                    continue
                seen.add((pid, ds_id))
                detail = None
                try:
                    detail = self.client.get_pipeline(pid, ds_id)
                except Exception as e:            # noqa: BLE001
                    log(f"    [!] downstream {pid}/{ds_id} fetch "
                        f"failed: {e}", err=True)
                web = (detail or {}).get("web_url")
                if not web and info and info.get("web_url"):
                    web = f"{info['web_url']}/-/pipelines/{ds_id}"
                out.append({
                    "bridge_name": job.get("name"),
                    "bridge_status": job.get("status"),
                    "pipeline_id": ds_id,
                    "project_id": pid,
                    "project_name": (info or {}).get("name"),
                    "project_path": (info or {}).get("path"),
                    "status": (detail or {}).get("status") or "unknown",
                    "web_url": web,
                    "ref": (detail or {}).get("ref"),
                    "created_at": (detail or {}).get("created_at"),
                    "duration": (detail or {}).get("duration"),
                    "kind": "api-triggered",
                    "detail": None,
                })
                with self._lock:
                    self.stats["downstream"] += 1
        return out

    def _collect_pipeline(self, project_id: int, pipeline_id: int,
                          listing: dict | None = None, depth: int = 0,
                          seen: set[tuple[int, int]] | None = None,
                          downstream: bool = False) -> dict | None:
        """One full pipeline record: detail + jobs + errors + downstream."""
        seen = seen if seen is not None else {(project_id, pipeline_id)}
        detail = self.client.get_pipeline(project_id, pipeline_id) \
            or dict(listing or {})
        if not detail:
            return None
        jobs_raw = self.client.list_pipeline_jobs(project_id, pipeline_id)
        jobs = [_slim_job(j) for j in jobs_raw]
        bridges = self.client.list_pipeline_bridges(project_id, pipeline_id)
        with self._lock:
            self.stats["jobs"] += len(jobs)
            self.stats["bridges"] += len(bridges)
        failed = [j for j in jobs
                  if j["status"] == "failed" and not j["retried"]]
        errors = self._collect_errors(project_id, failed)
        meta = parse_workflow_name(detail.get("name"))

        record = {
            "id": detail.get("id", pipeline_id),
            "iid": detail.get("iid"),
            "project_id": project_id,
            "is_downstream": downstream,
            "status": detail.get("status"),
            "source": detail.get("source"),
            "ref": detail.get("ref"),
            "sha": (detail.get("sha") or "")[:12],
            "name": detail.get("name"),
            "asset_id": meta["asset_id"],
            "trigger_source": meta["trigger_source"],
            "env": meta["env"],
            "user": _slim_user(detail.get("user")),
            "created_at": detail.get("created_at"),
            "started_at": detail.get("started_at"),
            "finished_at": detail.get("finished_at"),
            "updated_at": detail.get("updated_at"),
            "duration": detail.get("duration"),
            "queued_duration": detail.get("queued_duration"),
            "web_url": detail.get("web_url"),
            "jobs": jobs,
            "errors": errors,
            "downstream": (self._collect_downstream(bridges, depth, seen)
                           + self._collect_api_downstream(jobs, depth,
                                                          seen)),
        }
        return record

    # ------------------------------------------------------------------ #
    # main entry                                                         #
    # ------------------------------------------------------------------ #
    def collect(self, state: dict, updated_after: datetime,
                mode: str) -> dict:
        """List + collect every pipeline updated inside the window, plus
        re-collect pipelines previously seen in a non-final state; merge
        everything into ``state['pipelines']`` (newest record wins)."""
        listings = self.client.list_pipelines(self.project_id, updated_after)
        refresh = set(non_final_pipeline_ids(state, NON_FINAL_STATUSES))
        # parents whose DOWNSTREAM pipelines were last seen unsettled are
        # re-collected too, so downstream statuses converge to final ones
        refresh |= set(unsettled_downstream_parent_ids(
            state, NON_FINAL_STATUSES | {"unknown"}))
        listed_ids = {p["id"] for p in listings}
        todo: list[tuple[int, dict | None]] = \
            [(p["id"], p) for p in listings] + \
            [(pid, None) for pid in sorted(refresh - listed_ids)]
        log(f"  window={mode} updated_after={updated_after:%Y-%m-%d %H:%M} "
            f"-> {len(listings)} listed pipeline(s) + "
            f"{len(todo) - len(listings)} unsettled to refresh")

        total = len(todo)

        def one(item: tuple[int, dict | None]) -> dict | None:
            pid, listing = item
            rec = self._collect_pipeline(self.project_id, pid, listing)
            with self._lock:
                self._done += 1
                if self._done % 50 == 0 or self._done == total:
                    log(f"  … {self._done}/{total} pipelines collected")
            return rec

        collected: list[dict] = []
        if todo:
            with ThreadPoolExecutor(max_workers=self.workers) as ex:
                for fut in as_completed(ex.submit(one, t) for t in todo):
                    try:
                        rec = fut.result()
                    except Exception as e:        # noqa: BLE001
                        log(f"  [!] pipeline collection failed: {e}",
                            err=True)
                        continue
                    if rec:
                        collected.append(rec)

        new_ids, updated_ids = [], []
        pipelines = state.setdefault("pipelines", {})
        for rec in collected:
            key = str(rec["id"])
            (updated_ids if key in pipelines else new_ids).append(rec["id"])
            pipelines[key] = rec
        self.stats["pipelines"] = len(collected)
        return {"collected": len(collected), "new": len(new_ids),
                "updated": len(updated_ids), "mode": mode,
                "updated_after": updated_after.isoformat()}
