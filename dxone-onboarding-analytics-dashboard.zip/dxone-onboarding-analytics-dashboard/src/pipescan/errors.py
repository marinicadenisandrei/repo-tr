"""Error extraction from failed-job log tails.

Two jobs failing for the *same reason* rarely produce byte-identical log
lines (timestamps, ids, hostnames, ticket numbers differ), so raw error
lines are useless for "most frequent errors" analytics.  This module

1. picks the most error-like lines out of a log tail
   (``extract_error_lines``), and
2. collapses each line into a stable **signature** by masking every
   volatile token (``normalize_signature``) so identical failures group
   together across pipelines and days.
"""
from __future__ import annotations

import re

from .constants import MAX_SIGNATURE_LEN

# ANSI colour / cursor codes and GitLab collapsible-section markers
ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]|\x1b\][^\x07]*\x07")
SECTION_RE = re.compile(r"section_(?:start|end):\d+:[A-Za-z0-9_.-]+\r?")

# Lines that clearly carry the failure. Ordered by priority: the FIRST
# bucket a line matches decides its rank; lower rank wins when the tail
# holds more candidates than we keep. GitLab's generic terminal line
# ("ERROR: Job failed: exit code 1") is deliberately the LAST resort -
# grouping on it would collapse every failure into one meaningless bucket.
_ERROR_PATTERNS: list[tuple[int, re.Pattern]] = [
    (9, re.compile(r"^ERROR: Job failed", re.I)),
    (1, re.compile(r"\b(?:FATAL|CRITICAL)\b")),
    (1, re.compile(r"^\s*(?:E:|ERROR\b|error:)", re.I)),
    (1, re.compile(r"\bTraceback \(most recent call last\)")),
    (1, re.compile(r"^\s*raise\s+\w+|^\w+(?:\.\w+)*(?:Error|Exception):")),
    (2, re.compile(r"\bexit(?:ed)? (?:with )?(?:status|code) [1-9]", re.I)),
    (2, re.compile(r"\b(?:failed|failure)\b.*\b(?:task|step|request|"
                   r"connection|deploy|provision)", re.I)),
    (2, re.compile(r"\bHTTP(?:S)?\b.*\b(4\d\d|5\d\d)\b")),
    (2, re.compile(r"\b(?:timed? ?out|timeout)\b", re.I)),
    (2, re.compile(r"\b(?:denied|forbidden|unauthorized|not found)\b", re.I)),
    (3, re.compile(r"\bWARN(?:ING)?\b.*\bfail", re.I)),
]

# Volatile-token masks applied to build the signature. Order matters:
# urls before hex, timestamps before bare numbers.
_MASKS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"https?://[^\s\"']+"), "<url>"),
    (re.compile(r"\b\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?"
                r"(?:Z|[+-]\d{2}:?\d{2})?\b"), "<ts>"),
    (re.compile(r"\b\d{2}:\d{2}:\d{2}\b"), "<time>"),
    (re.compile(r"\b\d{4}-\d{2}-\d{2}\b"), "<date>"),
    (re.compile(r"\b[0-9a-f]{7,40}\b", re.I), "<hex>"),
    (re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-"
                r"[0-9a-f]{12}\b", re.I), "<uuid>"),
    (re.compile(r"\b(?:RITM|INC|CHG|REQ|CTASK|SCTASK)\d+\b", re.I), "<ticket>"),
    (re.compile(r"\bAPP-?\d+\b", re.I), "<app>"),
    (re.compile(r"\b\d+\.\d+\.\d+\.\d+\b"), "<ip>"),
    (re.compile(r"(/[\w.\-]+){3,}"), "<path>"),
    (re.compile(r"\b\d{4,}\b"), "<n>"),
    (re.compile(r"\s+"), " "),
]


def clean_line(line: str) -> str:
    line = ANSI_RE.sub("", line)
    line = SECTION_RE.sub("", line)
    return line.replace("\r", "").strip()


def extract_error_lines(trace_tail: str, max_lines: int = 6) -> list[str]:
    """The most error-like lines of a log tail, best first.

    Ranked by pattern priority, then by position (later lines win inside a
    rank - the terminal error is usually the last thing printed).
    """
    candidates: list[tuple[int, int, str]] = []
    seen: set[str] = set()
    for idx, raw in enumerate(trace_tail.splitlines()):
        line = clean_line(raw)
        if not line or len(line) < 4:
            continue
        for rank, pat in _ERROR_PATTERNS:
            if pat.search(line):
                key = line[:200]
                if key not in seen:
                    seen.add(key)
                    candidates.append((rank, -idx, line[:500]))
                break
    candidates.sort()
    return [line for _, _, line in candidates[:max_lines]]


def normalize_signature(line: str) -> str:
    """Stable grouping key: volatile tokens masked, length capped."""
    sig = clean_line(line)
    for pat, repl in _MASKS:
        sig = pat.sub(repl, sig)
    sig = sig.strip()
    if len(sig) > MAX_SIGNATURE_LEN:
        sig = sig[:MAX_SIGNATURE_LEN].rstrip() + "…"
    return sig
