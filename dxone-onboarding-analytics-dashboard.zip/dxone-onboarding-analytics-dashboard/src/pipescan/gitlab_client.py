"""GitLab REST client used by the concurrent pipeline collector.

Thread-safety: a single ``requests.Session`` with a connection pool sized to
the worker budget; every request goes through the shared ``RateLimiter`` so
tens of parallel calls self-throttle when GitLab pushes back (429 /
``RateLimit-Remaining``).  All public methods are safe to call from any
worker thread.

Endpoints used (all read-only, ``read_api`` scope is enough):

* ``GET /projects/:id``                          project metadata
* ``GET /projects/:id/pipelines``                pipeline list (window-aware)
* ``GET /projects/:id/pipelines/:pid``           pipeline detail (duration,
                                                 queued_duration, user, name)
* ``GET /projects/:id/pipelines/:pid/jobs``      jobs incl. retried attempts
* ``GET /projects/:id/pipelines/:pid/bridges``   trigger jobs -> downstream
                                                 pipeline ids/projects
* ``GET /projects/:id/jobs/:jid/trace``          failed-job log tail
"""
from __future__ import annotations

import sys
import urllib.parse
from datetime import datetime

import requests
from urllib3.util.retry import Retry

from .http import RateLimiter, SSLAdapter


def normalize_gitlab_url(url: str) -> str:
    url = url.strip().rstrip("/")
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if url.endswith("/app"):
        url = url[: -len("/app")]
    return url.rstrip("/")


def parse_ts(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except ValueError:
        return None


class GitLabClient:
    def __init__(self, base_url: str, token: str, verify_ssl: bool = True,
                 auth_mode: str = "private-token",
                 pool_size: int = 24,
                 limiter: RateLimiter | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_url = f"{self.base_url}/api/v4"
        self.limiter = limiter or RateLimiter(0.0)
        self.session = requests.Session()
        if auth_mode == "bearer":
            self.session.headers["Authorization"] = f"Bearer {token}"
        else:
            self.session.headers["PRIVATE-TOKEN"] = token
        retry = Retry(total=3, backoff_factor=1,
                      status_forcelist=[429, 500, 502, 503],
                      raise_on_status=False)
        adapter = SSLAdapter(verify_ssl=verify_ssl, max_retries=retry,
                             pool_connections=pool_size,
                             pool_maxsize=max(pool_size, 10))
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)
        self.timeout = 60

    # ------------------------------------------------------------------ #
    # low-level request wrapper: every call is rate-limited + observed   #
    # ------------------------------------------------------------------ #
    def request(self, path: str, params: dict | None = None,
                stream: bool = False,
                headers: dict | None = None) -> requests.Response:
        self.limiter.acquire()
        resp = self.session.get(f"{self.api_url}{path}", params=params,
                                timeout=self.timeout, stream=stream,
                                headers=headers)
        self.limiter.observe(resp.status_code, resp.headers)
        return resp

    def _get_paginated(self, path: str, params: dict | None = None,
                       stop: "callable | None" = None) -> list[dict]:
        """Paginate ``path``; ``stop(item) -> True`` ends the walk early
        (used when listing newest-first and the window edge is reached)."""
        results: list[dict] = []
        params = dict(params or {})
        params.setdefault("per_page", 100)
        page = 1
        while True:
            params["page"] = page
            resp = self.request(path, params=params)
            if resp.status_code in (401, 403, 404):
                print(f"  [!] HTTP {resp.status_code} on {path}",
                      file=sys.stderr)
                break
            resp.raise_for_status()
            data = resp.json()
            if not data:
                break
            done = False
            for item in data:
                if stop and stop(item):
                    done = True
                    break
                results.append(item)
            if done or len(data) < int(params["per_page"]):
                break
            page += 1
        return results

    def _get(self, path: str, params: dict | None = None) -> dict | None:
        resp = self.request(path, params=params)
        if resp.status_code in (401, 403, 404):
            return None
        resp.raise_for_status()
        return resp.json()

    def ping(self) -> dict:
        try:
            resp = self.request("/version")
        except requests.exceptions.SSLError as e:
            return {"ok": False, "error": f"SSL verification failed - try "
                    f"--no-verify-ssl. {e}"}
        except requests.exceptions.RequestException as e:
            return {"ok": False, "error": f"Could not reach host: {e}"}
        if resp.status_code == 200:
            info = resp.json()
            info["ok"] = True
            return info
        if resp.status_code in (401, 403):
            return {"ok": False,
                    "error": f"Auth failed - HTTP {resp.status_code}. "
                    "Check token value/expiry/'read_api' scope; for SSO "
                    "tokens try --auth-mode bearer."}
        return {"ok": False, "error": f"Unexpected HTTP {resp.status_code}."}

    # ------------------------------------------------------------------ #
    # project / pipelines                                                #
    # ------------------------------------------------------------------ #
    def get_project(self, project: int | str) -> dict | None:
        encoded = urllib.parse.quote(str(project), safe="")
        return self._get(f"/projects/{encoded}")

    def list_pipelines(self, project_id: int, updated_after: datetime,
                       updated_before: datetime | None = None) -> list[dict]:
        """All pipelines of the project updated inside the window,
        newest-first.  ``updated_after`` filtering happens server-side, so a
        6-month backfill and a 1-day incremental run cost exactly what they
        return."""
        params = {"order_by": "updated_at", "sort": "desc",
                  "updated_after": updated_after.isoformat()}
        if updated_before is not None:
            params["updated_before"] = updated_before.isoformat()
        return self._get_paginated(f"/projects/{project_id}/pipelines",
                                   params=params)

    def get_pipeline(self, project_id: int, pipeline_id: int) -> dict | None:
        return self._get(f"/projects/{project_id}/pipelines/{pipeline_id}")

    def list_pipeline_jobs(self, project_id: int,
                           pipeline_id: int) -> list[dict]:
        """Every job of the pipeline INCLUDING retried attempts - that is
        where the retry statistics come from."""
        return self._get_paginated(
            f"/projects/{project_id}/pipelines/{pipeline_id}/jobs",
            params={"include_retried": "true"})

    def list_pipeline_bridges(self, project_id: int,
                              pipeline_id: int) -> list[dict]:
        """Trigger jobs of the pipeline; each carries the
        ``downstream_pipeline`` it created (id, project_id, status)."""
        return self._get_paginated(
            f"/projects/{project_id}/pipelines/{pipeline_id}/bridges")

    def list_pipeline_variables(self, project_id: int,
                                pipeline_id: int) -> list[dict]:
        """Pipeline variables (ASSET_ID, SOURCE, ENV ...). May be 403 for
        tokens without sufficient role - treated as 'no variables'."""
        resp = self.request(
            f"/projects/{project_id}/pipelines/{pipeline_id}/variables")
        if resp.status_code != 200:
            return []
        try:
            return resp.json() or []
        except ValueError:
            return []

    # ------------------------------------------------------------------ #
    # failed-job trace tail                                              #
    # ------------------------------------------------------------------ #
    def fetch_trace_tail(self, project_id: int, job_id: int,
                         max_bytes: int) -> str:
        """The LAST ``max_bytes`` of the job log (errors live at the end).

        A ranged request is attempted first; when the server ignores the
        Range header the full body is streamed and only the tail is kept.
        """
        try:
            resp = self.request(f"/projects/{project_id}/jobs/{job_id}/trace",
                                stream=True,
                                headers={"Range": f"bytes=-{max_bytes}"})
        except requests.RequestException:
            return ""
        if resp.status_code not in (200, 206):
            resp.close()
            return ""
        tail = b""
        try:
            for chunk in resp.iter_content(chunk_size=65536,
                                           decode_unicode=False):
                if not chunk:
                    continue
                tail += chunk
                if len(tail) > max_bytes:
                    tail = tail[-max_bytes:]
        except requests.RequestException:
            pass
        finally:
            resp.close()
        return tail.decode("utf-8", errors="replace")
