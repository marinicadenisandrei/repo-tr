"""HTTP plumbing shared by all API clients.

* ``SSLAdapter``   - per-session SSL-verification override + urllib3 retries.
* ``RateLimiter``  - process-wide, thread-safe throttle used by every worker
  thread.  Two mechanisms cooperate:

  1. an optional steady-state token bucket (``--rps``), and
  2. a *global backoff*: whenever any thread sees HTTP 429 or a low
     ``RateLimit-Remaining`` header, it publishes a "resume at" timestamp
     that ALL threads honour before their next request.  This lets the
     scanner run tens of parallel downloads without stampeding the GitLab
     API when the server starts pushing back.
"""
from __future__ import annotations

import threading
import time
from typing import Any

from requests.adapters import HTTPAdapter


class SSLAdapter(HTTPAdapter):
    def __init__(self, verify_ssl: bool = True, **kwargs: Any) -> None:
        self._verify_ssl = verify_ssl
        super().__init__(**kwargs)

    def send(self, request: Any, **kwargs: Any) -> Any:
        kwargs["verify"] = self._verify_ssl
        return super().send(request, **kwargs)


class RateLimiter:
    """Thread-safe throttle: token bucket + server-driven global backoff."""

    def __init__(self, rps: float = 0.0) -> None:
        self._rps = max(rps, 0.0)
        self._lock = threading.Lock()
        self._next_slot = 0.0          # token-bucket: next allowed send time
        self._resume_at = 0.0          # global backoff: all threads wait

    # -- called by workers before every request ---------------------------
    def acquire(self) -> None:
        # 1) honour any server-driven global backoff
        while True:
            wait = self._resume_at - time.monotonic()
            if wait <= 0:
                break
            time.sleep(min(wait, 5.0))
        # 2) steady-state token bucket: reserve ONE slot, then wait for it
        if self._rps <= 0:
            return
        with self._lock:
            slot = max(self._next_slot, time.monotonic())
            self._next_slot = slot + 1.0 / self._rps
        wait = slot - time.monotonic()
        if wait > 0:
            time.sleep(wait)

    # -- called by workers after every response ---------------------------
    def observe(self, status_code: int, headers: Any) -> None:
        """Feed response metadata back into the limiter."""
        backoff = 0.0
        if status_code == 429:
            try:
                backoff = float(headers.get("Retry-After", 5) or 5)
            except (TypeError, ValueError):
                backoff = 5.0
        else:
            remaining = headers.get("RateLimit-Remaining") \
                or headers.get("ratelimit-remaining")
            try:
                if remaining is not None and int(remaining) < 10:
                    backoff = float(headers.get("Retry-After", 2) or 2)
            except (TypeError, ValueError):
                backoff = 0.0
        if backoff > 0:
            resume = time.monotonic() + min(backoff, 60.0)
            with self._lock:
                if resume > self._resume_at:
                    self._resume_at = resume