"""Dashboard dataset builder.

Rebuilds the FULL analytics dataset from the merged pipeline records on
every run (exactly like the migration dashboard rebuilds its dataset from
the merged job records), so every aggregate - success rates, durations,
error groups, daily buckets - stays correct across incremental runs.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone

from .constants import MAX_ERROR_GROUPS, SAMPLES_PER_ERROR
from .gitlab_client import parse_ts

FINAL_BAD = ("failed",)
FINAL_OK = ("success",)


def _pct(part: float, whole: float) -> float:
    return round(100.0 * part / whole, 2) if whole else 0.0


def _percentile(sorted_vals: list[float], q: float) -> float | None:
    if not sorted_vals:
        return None
    if len(sorted_vals) == 1:
        return round(sorted_vals[0], 1)
    pos = q * (len(sorted_vals) - 1)
    lo = int(pos)
    hi = min(lo + 1, len(sorted_vals) - 1)
    frac = pos - lo
    return round(sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac, 1)


def _dur_stats(values: list[float]) -> dict:
    vals = sorted(v for v in values if isinstance(v, (int, float)) and v >= 0)
    if not vals:
        return {"count": 0, "avg": None, "p50": None, "p95": None,
                "min": None, "max": None}
    return {"count": len(vals),
            "avg": round(sum(vals) / len(vals), 1),
            "p50": _percentile(vals, 0.50),
            "p95": _percentile(vals, 0.95),
            "min": round(vals[0], 1),
            "max": round(vals[-1], 1)}


def _day(ts: str | None) -> str | None:
    dt = parse_ts(ts)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%d") if dt else None


def _iter_downstream(rec: dict):
    """Every downstream entry of a record, recursively (detail included)."""
    for entry in rec.get("downstream") or []:
        yield entry
        detail = entry.get("detail")
        if detail:
            yield from _iter_downstream(detail)


def build_dataset(state: dict, project: dict | None,
                  gitlab_url: str, window: dict) -> dict:
    """The complete dashboard payload out of ``state['pipelines']``."""
    now = datetime.now(timezone.utc)
    records = sorted(state.get("pipelines", {}).values(),
                     key=lambda r: r.get("created_at") or "", reverse=True)

    # ------------------------------------------------------------------ #
    # per-pipeline rows + running aggregations                           #
    # ------------------------------------------------------------------ #
    status_counts: dict[str, int] = defaultdict(int)
    source_counts: dict[str, int] = defaultdict(int)
    trigger_counts: dict[str, int] = defaultdict(int)
    env_counts: dict[str, int] = defaultdict(int)
    ref_counts: dict[str, int] = defaultdict(int)
    asset_stats: dict[str, dict] = defaultdict(
        lambda: {"total": 0, "success": 0, "failed": 0, "last_at": None,
                 "last_status": None, "durations": []})
    daily: dict[str, dict] = defaultdict(
        lambda: {"total": 0, "success": 0, "failed": 0, "canceled": 0,
                 "other": 0, "durations": [], "job_failures": 0,
                 "retries": 0, "downstream": 0})
    job_stats: dict[str, dict] = defaultdict(
        lambda: {"stage": None, "runs": 0, "success": 0, "failed": 0,
                 "retries": 0, "durations": [], "queued": [],
                 "last_status": None, "last_at": None,
                 "failure_reasons": defaultdict(int), "web_url": None})
    stage_stats: dict[str, dict] = defaultdict(
        lambda: {"runs": 0, "failed": 0, "durations": [], "retries": 0})
    error_groups: dict[str, dict] = {}
    ds_by_project: dict[int, dict] = defaultdict(
        lambda: {"total": 0, "success": 0, "failed": 0, "other": 0,
                 "durations": [], "name": None, "path": None,
                 "kinds": defaultdict(int)})
    ds_status: dict[str, int] = defaultdict(int)
    fail_reason_counts: dict[str, int] = defaultdict(int)

    pipe_durations: list[float] = []
    queue_durations: list[float] = []
    total_jobs = total_job_failures = total_retries = 0
    total_downstream = 0

    rows: list[dict] = []
    for rec in records:
        status = rec.get("status") or "unknown"
        status_counts[status] += 1
        source_counts[rec.get("source") or "unknown"] += 1
        if rec.get("trigger_source"):
            trigger_counts[rec["trigger_source"]] += 1
        if rec.get("env"):
            env_counts[rec["env"]] += 1
        if rec.get("ref"):
            ref_counts[rec["ref"]] += 1
        if isinstance(rec.get("duration"), (int, float)):
            pipe_durations.append(rec["duration"])
        if isinstance(rec.get("queued_duration"), (int, float)):
            queue_durations.append(rec["queued_duration"])

        asset = rec.get("asset_id")
        if asset:
            a = asset_stats[asset]
            a["total"] += 1
            if status in FINAL_OK:
                a["success"] += 1
            elif status in FINAL_BAD:
                a["failed"] += 1
            if isinstance(rec.get("duration"), (int, float)):
                a["durations"].append(rec["duration"])
            created = rec.get("created_at") or ""
            if a["last_at"] is None or created > a["last_at"]:
                a["last_at"], a["last_status"] = created, status

        day = _day(rec.get("created_at"))
        dbucket = daily[day] if day else None
        if dbucket is not None:
            dbucket["total"] += 1
            if status in FINAL_OK:
                dbucket["success"] += 1
            elif status in FINAL_BAD:
                dbucket["failed"] += 1
            elif status == "canceled":
                dbucket["canceled"] += 1
            else:
                dbucket["other"] += 1
            if isinstance(rec.get("duration"), (int, float)):
                dbucket["durations"].append(rec["duration"])

        # ---- jobs -------------------------------------------------------
        jobs = rec.get("jobs") or []
        pipe_job_failed = pipe_retries = 0
        failed_job_names: list[str] = []
        for job in jobs:
            total_jobs += 1
            name = job.get("name") or "?"
            js = job_stats[name]
            js["runs"] += 1
            js["stage"] = job.get("stage") or js["stage"]
            if job.get("web_url"):
                js["web_url"] = job["web_url"]
            jstat = job.get("status")
            if jstat == "success":
                js["success"] += 1
            elif jstat == "failed":
                js["failed"] += 1
                if not job.get("retried"):
                    pipe_job_failed += 1
                    total_job_failures += 1
                    failed_job_names.append(name)
                if job.get("failure_reason"):
                    js["failure_reasons"][job["failure_reason"]] += 1
                    fail_reason_counts[job["failure_reason"]] += 1
            if job.get("retried"):
                js["retries"] += 1
                pipe_retries += 1
                total_retries += 1
            if isinstance(job.get("duration"), (int, float)):
                js["durations"].append(job["duration"])
            if isinstance(job.get("queued_duration"), (int, float)):
                js["queued"].append(job["queued_duration"])
            fin = job.get("finished_at") or job.get("created_at") or ""
            if js["last_at"] is None or fin > js["last_at"]:
                js["last_at"], js["last_status"] = fin, jstat
            stage = job.get("stage") or "?"
            ss = stage_stats[stage]
            ss["runs"] += 1
            if jstat == "failed" and not job.get("retried"):
                ss["failed"] += 1
            if job.get("retried"):
                ss["retries"] += 1
            if isinstance(job.get("duration"), (int, float)):
                ss["durations"].append(job["duration"])
        if dbucket is not None:
            dbucket["job_failures"] += pipe_job_failed
            dbucket["retries"] += pipe_retries

        # ---- errors -----------------------------------------------------
        for err in rec.get("errors") or []:
            sig = err.get("signature") or "(no message)"
            grp = error_groups.get(sig)
            if grp is None:
                grp = error_groups[sig] = {
                    "signature": sig, "count": 0, "pipelines": set(),
                    "jobs": defaultdict(int),
                    "failure_reasons": defaultdict(int),
                    "first_seen": None, "last_seen": None, "samples": []}
            grp["count"] += 1
            grp["pipelines"].add(rec["id"])
            if err.get("job_name"):
                grp["jobs"][err["job_name"]] += 1
            if err.get("failure_reason"):
                grp["failure_reasons"][err["failure_reason"]] += 1
            when = rec.get("created_at")
            if when:
                if grp["first_seen"] is None or when < grp["first_seen"]:
                    grp["first_seen"] = when
                if grp["last_seen"] is None or when > grp["last_seen"]:
                    grp["last_seen"] = when
            if len(grp["samples"]) < SAMPLES_PER_ERROR:
                grp["samples"].append({
                    "message": err.get("message"),
                    "job_name": err.get("job_name"),
                    "job_url": err.get("job_url"),
                    "pipeline_id": rec["id"]})

        # ---- downstream -------------------------------------------------
        ds_rows = []
        for entry in _iter_downstream(rec):
            total_downstream += 1
            if dbucket is not None:
                dbucket["downstream"] += 1
            ds_status[entry.get("status") or "unknown"] += 1
            proj = entry.get("project_id")
            if proj is not None:
                b = ds_by_project[proj]
                b["total"] += 1
                st = entry.get("status")
                if st == "success":
                    b["success"] += 1
                elif st == "failed":
                    b["failed"] += 1
                else:
                    b["other"] += 1
                if entry.get("project_name") and not b["name"]:
                    b["name"] = entry["project_name"]
                if entry.get("project_path") and not b["path"]:
                    b["path"] = entry["project_path"]
                b["kinds"][entry.get("kind") or "unknown"] += 1
                detail = entry.get("detail") or {}
                dur = detail.get("duration")
                if not isinstance(dur, (int, float)):
                    dur = entry.get("duration")
                if isinstance(dur, (int, float)):
                    b["durations"].append(dur)
            ds_rows.append({
                "bridge": entry.get("bridge_name"),
                "pipeline_id": entry.get("pipeline_id"),
                "project_id": entry.get("project_id"),
                "project_name": entry.get("project_name"),
                "project_path": entry.get("project_path"),
                "status": entry.get("status"),
                "kind": entry.get("kind"),
                "web_url": entry.get("web_url"),
                "duration": ((entry.get("detail") or {}).get("duration")
                             if isinstance((entry.get("detail") or {})
                                           .get("duration"), (int, float))
                             else entry.get("duration")),
            })

        rows.append({
            "id": rec["id"], "iid": rec.get("iid"),
            "status": status, "source": rec.get("source"),
            "trigger_source": rec.get("trigger_source"),
            "env": rec.get("env"), "asset_id": rec.get("asset_id"),
            "ref": rec.get("ref"), "sha": rec.get("sha"),
            "name": rec.get("name"),
            "user": (rec.get("user") or {}).get("username"),
            "created_at": rec.get("created_at"),
            "finished_at": rec.get("finished_at"),
            "duration": rec.get("duration"),
            "queued_duration": rec.get("queued_duration"),
            "web_url": rec.get("web_url"),
            "jobs_total": len(jobs),
            "jobs_failed": pipe_job_failed,
            "retries": pipe_retries,
            "failed_jobs": failed_job_names[:15],
            "errors": [{"job_name": e.get("job_name"),
                        "message": e.get("message"),
                        "signature": e.get("signature"),
                        "failure_reason": e.get("failure_reason"),
                        "job_url": e.get("job_url")}
                       for e in (rec.get("errors") or [])],
            "downstream": ds_rows,
            "downstream_total": len(ds_rows),
            "downstream_failed": sum(1 for d in ds_rows
                                     if d["status"] == "failed"),
        })

    # ------------------------------------------------------------------ #
    # final aggregates                                                   #
    # ------------------------------------------------------------------ #
    finished = status_counts.get("success", 0) + status_counts.get("failed", 0)
    summary = {
        "pipelines": len(rows),
        "success": status_counts.get("success", 0),
        "failed": status_counts.get("failed", 0),
        "canceled": status_counts.get("canceled", 0),
        "running": sum(status_counts.get(s, 0)
                       for s in ("running", "pending", "created",
                                 "waiting_for_resource", "preparing")),
        "skipped": status_counts.get("skipped", 0),
        "manual": status_counts.get("manual", 0),
        "success_rate": _pct(status_counts.get("success", 0), finished),
        "failure_rate": _pct(status_counts.get("failed", 0), finished),
        "jobs": total_jobs,
        "job_failures": total_job_failures,
        "retries": total_retries,
        "downstream_pipelines": total_downstream,
        "downstream_failed": ds_status.get("failed", 0),
        "error_groups": len(error_groups),
        "assets": len(asset_stats),
        "duration": _dur_stats(pipe_durations),
        "queued": _dur_stats(queue_durations),
    }

    jobs_out = []
    for name, js in job_stats.items():
        attempts = js["success"] + js["failed"]
        jobs_out.append({
            "name": name, "stage": js["stage"], "runs": js["runs"],
            "success": js["success"], "failed": js["failed"],
            "retries": js["retries"],
            "fail_rate": _pct(js["failed"], attempts),
            "duration": _dur_stats(js["durations"]),
            "queued": _dur_stats(js["queued"]),
            "last_status": js["last_status"], "last_at": js["last_at"],
            "failure_reasons": dict(sorted(js["failure_reasons"].items(),
                                           key=lambda kv: -kv[1])),
        })
    jobs_out.sort(key=lambda j: (-j["failed"], -j["runs"]))

    stages_out = [{
        "name": name, "runs": ss["runs"], "failed": ss["failed"],
        "retries": ss["retries"],
        "fail_rate": _pct(ss["failed"], ss["runs"]),
        "duration": _dur_stats(ss["durations"]),
    } for name, ss in stage_stats.items()]
    stages_out.sort(key=lambda s: -s["runs"])

    errors_out = []
    for grp in sorted(error_groups.values(), key=lambda g: -g["count"]) \
            [:MAX_ERROR_GROUPS]:
        errors_out.append({
            "signature": grp["signature"], "count": grp["count"],
            "pipelines": len(grp["pipelines"]),
            "jobs": dict(sorted(grp["jobs"].items(),
                                key=lambda kv: -kv[1])[:8]),
            "failure_reasons": dict(sorted(grp["failure_reasons"].items(),
                                           key=lambda kv: -kv[1])),
            "first_seen": grp["first_seen"], "last_seen": grp["last_seen"],
            "samples": grp["samples"],
        })

    daily_out = [{
        "date": day, "total": d["total"], "success": d["success"],
        "failed": d["failed"], "canceled": d["canceled"], "other": d["other"],
        "success_rate": _pct(d["success"], d["success"] + d["failed"]),
        "avg_duration": (round(sum(d["durations"]) / len(d["durations"]), 1)
                         if d["durations"] else None),
        "p95_duration": _percentile(sorted(d["durations"]), 0.95),
        "job_failures": d["job_failures"], "retries": d["retries"],
        "downstream": d["downstream"],
    } for day, d in sorted(daily.items())]

    assets_out = [{
        "asset_id": asset, "total": a["total"], "success": a["success"],
        "failed": a["failed"],
        "success_rate": _pct(a["success"], a["success"] + a["failed"]),
        "avg_duration": (round(sum(a["durations"]) / len(a["durations"]), 1)
                         if a["durations"] else None),
        "last_at": a["last_at"], "last_status": a["last_status"],
    } for asset, a in asset_stats.items()]
    assets_out.sort(key=lambda a: -a["total"])

    proj_cache = state.get("projects") or {}

    def _ds_name(pid, b):
        if b["name"]:
            return b["name"], b["path"]
        info = proj_cache.get(str(pid)) or {}
        return info.get("name"), info.get("path")

    ds_projects_out = []
    for pid, b in sorted(ds_by_project.items(),
                         key=lambda kv: -kv[1]["total"]):
        name, path = _ds_name(pid, b)
        ds_projects_out.append({
            "project_id": pid, "name": name, "path": path,
            "total": b["total"], "success": b["success"],
            "failed": b["failed"], "other": b["other"],
            "success_rate": _pct(b["success"], b["success"] + b["failed"]),
            "duration": _dur_stats(b["durations"]),
            "kinds": dict(b["kinds"]),
        })

    return {
        "schema_version": 1,
        "generated_at": now.isoformat(timespec="seconds"),
        "gitlab_url": gitlab_url,
        "project": {
            "id": (project or {}).get("id", state.get("project_id")),
            "path": (project or {}).get("path_with_namespace"),
            "name": (project or {}).get("name"),
            "web_url": (project or {}).get("web_url"),
            "default_branch": (project or {}).get("default_branch"),
        },
        "window": window,
        "summary": summary,
        "status_counts": dict(status_counts),
        "sources": dict(sorted(source_counts.items(),
                               key=lambda kv: -kv[1])),
        "trigger_sources": dict(sorted(trigger_counts.items(),
                                       key=lambda kv: -kv[1])),
        "environments": dict(sorted(env_counts.items(),
                                    key=lambda kv: -kv[1])),
        "refs": dict(sorted(ref_counts.items(), key=lambda kv: -kv[1])[:40]),
        "failure_reasons": dict(sorted(fail_reason_counts.items(),
                                       key=lambda kv: -kv[1])),
        "daily": daily_out,
        "pipelines": rows,
        "jobs": jobs_out,
        "stages": stages_out,
        "errors": errors_out,
        "assets": assets_out,
        "downstream": {
            "total": total_downstream,
            "status_counts": dict(ds_status),
            "by_project": ds_projects_out,
        },
        "runs": list(state.get("runs", []))[-200:],
    }
