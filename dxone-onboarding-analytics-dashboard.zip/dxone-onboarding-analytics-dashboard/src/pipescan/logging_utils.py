"""Timestamped, CI-friendly logging (collapsible GitLab sections).

Extracted from the original single-file implementation
(scripts/gitlab_job_url_access.py); behaviour is unchanged.
"""
from __future__ import annotations

import os
import re
import sys
import time
from datetime import datetime, timezone
from typing import Any


def log(msg: str = "", err: bool = False) -> None:
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    print(f"[{ts}] {msg}" if msg else "",
          file=sys.stderr if err else sys.stdout, flush=True)


def rss_mb() -> tuple[float, float]:
    """(current RSS, peak RSS) of this process in MB; (0, 0) off-Linux."""
    cur = peak = 0.0
    try:
        with open("/proc/self/status", encoding="ascii") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    cur = int(line.split()[1]) / 1024
                elif line.startswith("VmHWM:"):
                    peak = int(line.split()[1]) / 1024
    except OSError:
        try:
            import resource
            peak = resource.getrusage(
                resource.RUSAGE_SELF).ru_maxrss / 1024
        except (ImportError, ValueError):
            pass
    return cur, peak


def log_mem(checkpoint: str) -> None:
    """Memory checkpoint line in the job log.

    Deliberately chatty: when a run is trending toward the pod's memory
    limit, these lines show WHERE the memory goes long before the
    OOM-killer produces an unexplained 'exit code 137'.
    """
    cur, peak = rss_mb()
    if cur or peak:
        log(f"  [mem] {checkpoint}: rss={cur:,.0f} MB (peak {peak:,.0f} MB)")


def trim_memory(checkpoint: str = "") -> None:
    """Give freed memory BACK to the kernel and log the effect.

    The pod's OOM-killer acts on RSS, not on live Python objects: after a
    big structure is dropped, glibc keeps the freed arenas mapped to the
    process, so RSS (and the cgroup accounting) stays high. gc.collect()
    breaks reference cycles, malloc_trim(0) releases the freed arenas.
    A few of these calls at the phase boundaries of the run are the
    difference between a 4 GB pod surviving and 'exit code 137'.
    """
    import ctypes
    import gc
    gc.collect()
    try:
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except (OSError, AttributeError):
        pass                                   # non-glibc platform: no-op
    if checkpoint:
        log_mem(f"{checkpoint} (after trim)")


class log_section:
    """Collapsible section in the GitLab CI job log (no-op outside CI)."""
    def __init__(self, name: str, header: str) -> None:
        self.name = re.sub(r"[^a-z0-9_]+", "_", name.lower())
        self.header = header
        self.in_ci = bool(os.getenv("GITLAB_CI") or os.getenv("CI"))
        self.t0 = 0.0

    def __enter__(self) -> "log_section":
        self.t0 = time.time()
        if self.in_ci:
            print(f"\x1b[0Ksection_start:{int(time.time())}:{self.name}"
                  f"[collapsed=true]\r\x1b[0K{self.header}", flush=True)
        else:
            log(f"--- {self.header} ---")
        return self

    def __exit__(self, *exc: Any) -> None:
        if self.in_ci:
            print(f"\x1b[0Ksection_end:{int(time.time())}:{self.name}"
                  f"\r\x1b[0K", flush=True)
        log(f"--- {self.header}: done in {time.time() - self.t0:.0f}s ---")