# Onboarding Pipeline Analytics Dashboard

Continuous analytics for the **dxone-onboarding-master** production pipeline
(GitLab project **12811**) — the ServiceNow / LMP-triggered pipeline that
onboards new projects across GitLab, LDAP/AD, Vault, SonarQube, Artifactory,
Azure AD, firewall and Datadog. A standalone sibling of
`dxone-migration-dashboard`, built on the same implementation pattern
(Vault-backed pipeline, incremental state, Phoenix-theme dashboard on GitLab
Pages) with the same table UX: multi-select checkbox filters with search,
add/remove columns, filter chips, shareable links and Export CSV.

## What it does

Every scheduled pipeline run:

```
0-runner-auth ──▶ fetch-pipeline-analytics ──▶ build-history ──▶ pages
                    output/pipeline_analytics.json   output/history.json     public/data/*.json(.gz)
                    output/pipelines.csv             output/history_full.json
                    output/state.json
```

The collector (`scripts/gitlab_pipeline_analytics.py`, package
`src/pipescan/`):

1. lists every pipeline of project **12811** updated inside the fetch window
   (see **Incremental fetching** below), newest first, all statuses;
2. fetches each pipeline's detail (duration, queued duration, user, source)
   and parses the workflow name —
   `Onboarding asset [$ASSET_ID] Triggered from [SNOW $ENV]` /
   `[LMP $ENV], Orchestrator ID: …` — into **asset id**, **trigger source**
   (SNOW / LMP) and **environment**;
3. lists every job **including retried runs** (`include_retried=true`) so
   retry counts are exact, keeping status, stage, duration, queued time and
   GitLab `failure_reason`;
4. follows every **bridge** (trigger job) to downstream / child /
   multi-project pipelines, recursively up to 3 levels, and records their
   project, status and duration;
5. downloads the **log tail of every failed job** (last 64 KB via HTTP
   `Range`) and extracts the error lines, normalising each into a stable
   **error signature** (URLs, timestamps, hex ids, UUIDs, ticket numbers,
   APP-ids, IPs, paths and bare numbers are masked) so the same failure
   groups together across pipelines — with real sample messages and job
   links kept per group;
6. re-fetches pipelines that were still `running` / `pending` on the
   previous run until they settle, so no terminal status is ever missed;
7. merges everything into the accumulated state, prunes records older than
   `DATA_KEEP_DAYS` (default **190**) and **rebuilds the full dataset from
   the merged records** — KPIs, daily time-series, per-job / per-stage /
   per-asset aggregates, error groups, trigger-source and downstream
   analytics are therefore always consistent, never incrementally patched.

`scripts/build_history.py` then appends one **run record** to the history —
dataset KPIs snapshot, **deltas vs the previous run**, collection counters
(new / refreshed / pruned pipelines, jobs seen, traces fetched, downstream
collected, elapsed) and the top errors / failing jobs — powering the
**Run history** section with run-over-run trend charts and change tables.

The dashboard (`dashboard/index.html`, served on GitLab Pages) shows KPI
cards, clickable filter-aware charts (status split, executions over time
with day/week/month granularity, duration trends avg/p95, failing jobs,
slowest jobs, stages, error groups, trigger sources, downstream projects),
the **All pipelines** table (status, asset, trigger, env, durations, job
failures, retries, downstream, errors + 10 optional columns), per-job and
per-stage statistics, expandable **error analysis** with real log samples,
**downstream analytics**, and the **run history** with KPI trends and
run-over-run deltas. Click a row for the full pipeline drawer (jobs,
downstream tree, error lines, links). Everything exports to CSV.

## Incremental fetching

The pipeline keeps an accumulating **state file** (`output/state.json`,
published as artifact and to Pages) so scheduled runs stay fast and the
dataset keeps growing:

| Situation | Behaviour |
|---|---|
| First run / no restorable state / `FORCE_FULL=true` | full backfill of the last `BACKFILL_DAYS` (default **183** ≈ 6 months) |
| State restored | only pipelines **updated after the previous run** are fetched (2 h overlap, deduplicated by pipeline id) and merged into the accumulated records |
| Pipelines non-final last run | re-fetched regardless of window until they reach a terminal status |
| Records older than `DATA_KEEP_DAYS` | pruned at the end of each run |

Before each run the state is restored with the usual cascade: last
`fetch-pipeline-analytics` artifact on the default branch → live Pages
`data/state.json.gz` → none (full backfill). The run history is restored the
same way (artifact → Pages `data/history_full.json.gz`), so both survive
runner-cache loss. The dashboard header shows the actual coverage window
and fetch mode; a warning banner appears when the published dataset is
older than ~26 h.

## Pipeline flags

| Variable | Default | Effect |
|---|---|---|
| `TARGET_PROJECT_ID` | `12811` | project whose pipelines are analysed |
| `TARGET_GITLAB_URL` | `https://gitlab.dx1.lseg.com` | GitLab instance |
| `BACKFILL_DAYS` | `183` | initial full-backfill window (days) |
| `DATA_KEEP_DAYS` | `190` | prune records older than this |
| `FORCE_FULL` | `false` | ignore restored state, full backfill |
| `PIPE_DOWNSTREAM_DEPTH` | `3` | bridge recursion depth |
| `PIPE_TRACE_TAIL_KB` | `64` | log tail (KB) fetched per failed job |
| `PIPE_TRACE_WORKERS` | `12` | parallel failed-job log downloads |
| `DASHBOARD_ENV` | `production` | badge / favicon (`production` / `dev`) |
| `SKIP_FETCH` | `false` | publish bundled sample data (UI preview without API access) |
| `PAGES_MAX_ROWS` | `5000` | pipeline rows embedded in the Pages payload |
| `ALERT_TO` | maintainers | failure-notification recipients (comma separated) |
| `FAIL_NOTIFY` | `schedule` | notify policy: `schedule` / `always` / `never` |

Authentication mirrors the migration dashboard: `0-runner-auth` obtains the
GitLab token from Vault (`VS_SECRET_LIST`) and passes it as
`GITLAB_TOKEN`; no secret ever reaches Pages — the published payload
is data-only.

## Dashboard data contract

`pages` publishes to `public/dashboard/`:

| File | Content |
|---|---|
| `data/pipeline_analytics.json.gz` | full dataset (summary, daily, jobs, stages, assets, errors, downstream, pipelines ≤ `PAGES_MAX_ROWS`) |
| `data/pipelines.csv.gz` | flat pipeline export |
| `data/history.json.gz` | run history (trimmed for the UI) |
| `data/history_full.json.gz` | complete history incl. error tracking (state restore source) |
| `data/state.json.gz` | collector state (restore source, not read by the UI) |
| `data/meta.json` | build metadata (pipeline url, commit, time) |

The static page fetches `.json` first and transparently falls back to
`.json.gz` (browser `DecompressionStream`); when neither exists yet it
renders the bundled **sample dataset** with a clear banner, so the UI can be
reviewed before the first collector run.

## Local development

```bash
make install         # editable install + test deps
make test            # pytest (offline; mocked GitLab API)
make lint            # pyflakes
make sample          # regenerate static/*_sample.json through the real pipeline code
make collect-test    # tiny real 7-day collection (needs GITLAB_TOKEN)
```

To preview the UI locally, serve the repo root and open
`http://127.0.0.1:8000/dashboard/` — with no `data/` published the page
automatically renders the bundled sample dataset:

```bash
python3 -m http.server 8000
```

A real collection against GitLab only needs a token:

```bash
export GITLAB_TOKEN=glpat-…
python scripts/gitlab_pipeline_analytics.py --project-id 12811 \
    --state-file output/state.json.gz \
    -o output/pipeline_analytics.json output/pipelines.csv
python scripts/build_history.py --snapshot output/pipeline_analytics.json \
    --output output/history_full.json
python scripts/build_pages_payload.py --input output/pipeline_analytics.json \
    --output public/dashboard/data/pipeline_analytics.json.gz \
    --history-in output/history_full.json \
    --history-out public/dashboard/data/history.json.gz
```

## Repository layout

```
.gitlab-ci.yml                  auth ▸ fetch ▸ history ▸ pages (+ notify on failure)
src/pipescan/                   collector package (client, state, errors, dataset)
scripts/                        CLI entry points + payload/history/notify helpers
dashboard/                      static Phoenix UI (index.html + assets + config.json)
static/                         bundled sample dataset / history (UI preview, SKIP_FETCH)
tests/                          unit + mocked end-to-end integration tests
needs/requirements.txt          requests + pytest
```
