from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from pipescan.collector import parse_workflow_name
from pipescan.errors import extract_error_lines, normalize_signature
from pipescan.state import (empty_state, load_state, prune_state,
                            save_state)

import importlib.util
import os

_spec = importlib.util.spec_from_file_location(
    "build_history",
    os.path.join(os.path.dirname(__file__), "..", "scripts",
                 "build_history.py"))
build_history = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(build_history)


# ---------------------------------------------------------------------- #
# workflow-name parsing                                                  #
# ---------------------------------------------------------------------- #
def test_parse_workflow_name_snow():
    meta = parse_workflow_name(
        "Onboarding asset [APP-01680] Triggered from [SNOW prod]")
    assert meta == {"asset_id": "APP-01680", "trigger_source": "SNOW",
                    "env": "prod"}


def test_parse_workflow_name_lmp_with_suffix():
    meta = parse_workflow_name(
        "Onboarding asset [APP-52501] Triggered from [LMP dev], "
        "Orchestrator ID: 42")
    assert meta["asset_id"] == "APP-52501"
    assert meta["trigger_source"] == "LMP"
    assert meta["env"] == "dev"


def test_parse_workflow_name_unrelated():
    assert parse_workflow_name("Push to master (abc123)") == \
        {"asset_id": None, "trigger_source": None, "env": None}
    assert parse_workflow_name(None)["asset_id"] is None


# ---------------------------------------------------------------------- #
# error extraction + signatures                                          #
# ---------------------------------------------------------------------- #
def test_extract_error_lines_ranks_terminal_error_first():
    trace = ("ok step\n"
             "\x1b[31mERROR: request to https://api.example.com/v1 "
             "timed out after 30s\x1b[0m\n"
             "ERROR: Job failed: exit code 1\n")
    lines = extract_error_lines(trace)
    assert "timed out" in lines[0]
    assert any(ln.startswith("ERROR: Job failed") for ln in lines)
    assert not any("\x1b" in ln for ln in lines)     # ANSI stripped


def test_signature_masks_volatile_tokens():
    a = normalize_signature(
        "ERROR: Vault write failed for APP-1111 RITM0012345 at "
        "2026-08-13T10:00:00Z (req 9f8e7d6c5b4a)")
    b = normalize_signature(
        "ERROR: Vault write failed for APP-2222 RITM0099999 at "
        "2026-08-14T11:30:00Z (req 1a2b3c4d5e6f)")
    assert a == b
    assert "<app>" in a and "<ticket>" in a and "<ts>" in a


def test_signature_length_cap():
    sig = normalize_signature("ERROR: " + "x" * 1000)
    assert len(sig) <= 261


# ---------------------------------------------------------------------- #
# state round-trip + pruning                                             #
# ---------------------------------------------------------------------- #
def test_state_roundtrip_gz(tmp_path):
    path = str(tmp_path / "state.json.gz")
    state = empty_state(12811)
    state["pipelines"]["1"] = {"id": 1, "status": "success",
                               "updated_at": "2026-08-01T00:00:00+00:00"}
    save_state(state, path)
    loaded = load_state(path, project_id=12811)
    assert loaded["pipelines"]["1"]["status"] == "success"
    # a state of another project is never merged in
    assert load_state(path, project_id=999)["pipelines"] == {}


def test_state_corrupt_falls_back_to_empty(tmp_path):
    path = str(tmp_path / "state.json")
    path_obj = tmp_path / "state.json"
    path_obj.write_text("{not json")
    assert load_state(path, 12811)["pipelines"] == {}


def test_prune_state_drops_old_records():
    now = datetime(2026, 8, 14, tzinfo=timezone.utc)
    state = empty_state(1)
    state["pipelines"] = {
        "old": {"updated_at": (now - timedelta(days=250)).isoformat()},
        "new": {"updated_at": (now - timedelta(days=5)).isoformat()},
    }
    dropped = prune_state(state, keep_days=190, now=now)
    assert dropped == 1 and list(state["pipelines"]) == ["new"]


# ---------------------------------------------------------------------- #
# history builder                                                        #
# ---------------------------------------------------------------------- #
def _mini_dataset(pipelines=10, failed=2):
    return {
        "summary": {"pipelines": pipelines, "success": pipelines - failed,
                    "failed": failed, "canceled": 0,
                    "success_rate": 100.0 * (pipelines - failed) / pipelines,
                    "jobs": pipelines * 5, "job_failures": failed,
                    "retries": 1, "downstream_pipelines": 3,
                    "downstream_failed": 0, "error_groups": 2, "assets": 4,
                    "duration": {"avg": 500.0, "p95": 900.0}},
        "window": {"mode": "incremental"},
        "runs": [{"mode": "incremental", "new_pipelines": 3,
                  "elapsed_s": 42.0, "ci_pipeline_id": "555"}],
        "errors": [{"signature": "ERROR: x", "count": 5}],
        "jobs": [{"name": "vault_onboarding", "failed": 2,
                  "fail_rate": 20.0}],
    }


def test_history_records_run_and_deltas(tmp_path):
    out = str(tmp_path / "history.json")
    snap1 = tmp_path / "s1.json"
    snap1.write_text(json.dumps(_mini_dataset(10, 2)))
    assert build_history.main(["--snapshot", str(snap1), "--output", out,
                               "--run-id", "1"]) == 0
    snap2 = tmp_path / "s2.json"
    snap2.write_text(json.dumps(_mini_dataset(14, 3)))
    assert build_history.main(["--history", out, "--snapshot", str(snap2),
                               "--output", out, "--run-id", "2"]) == 0
    hist = json.loads(open(out).read())
    assert len(hist["runs"]) == 2
    assert hist["runs"][1]["delta"]["pipelines"] == 4
    assert hist["runs"][1]["delta"]["failed"] == 1
    assert hist["error_track"]["ERROR: x"]["runs_seen"] == 2


def test_history_allow_empty_carries_forward(tmp_path):
    out = str(tmp_path / "history.json")
    snap = tmp_path / "s.json"
    snap.write_text(json.dumps(_mini_dataset()))
    build_history.main(["--snapshot", str(snap), "--output", out,
                        "--run-id", "1"])
    assert build_history.main(["--history", out, "--output", out,
                               "--allow-empty"]) == 0
    assert len(json.loads(open(out).read())["runs"]) == 1


# --------------------------------------------------------------------- #
# API-triggered downstream reference extraction from trigger-job logs   #
# --------------------------------------------------------------------- #
def test_extract_downstream_refs_forms():
    from pipescan.collector import extract_downstream_refs
    text = (
        "AssetID: APP-01680\n"
        "POST https://gitlab.dx1.lseg.com/api/v4/projects/46317"
        "/trigger/pipeline\n"
        "SonarQube payload: {...}\n"
        "Pipeline ID: 123456\n"                       # ctx-paired
        "Pipeline URL: https://gitlab.dx1.lseg.com/app/app-51411/"
        "artifactory-onboarding/artifactory-automation/pipelines/222333\n"
        "Datadog pipeline URL: https://gitlab.dx1.lseg.com/api/v4/"
        "projects/93334/pipelines/444555\n"
        "polling https://gitlab.dx1.lseg.com/api/v4/projects/93334/"
        "pipelines/444555\n"                          # duplicate
    )
    refs = extract_downstream_refs(text)
    assert {"project": 46317, "pipeline_id": 123456} in refs
    assert {"project": "app/app-51411/artifactory-onboarding/"
                       "artifactory-automation",
            "pipeline_id": 222333} in refs
    assert {"project": 93334, "pipeline_id": 444555} in refs
    assert len(refs) == 3                             # de-duplicated


def test_extract_downstream_refs_id_supersedes_path():
    from pipescan.collector import extract_downstream_refs
    # the scripts print BOTH the web URL and the API URL of the same
    # pipeline - the id-based ref must win, no duplicate entry
    text = (
        "Pipeline URL: https://gitlab.dx1.lseg.com/app/app-51255/"
        "sonarqube-onboarding/group-onboarding/pipelines/999\n"
        "https://gitlab.dx1.lseg.com/api/v4/projects/46317/pipelines/999\n"
    )
    refs = extract_downstream_refs(text)
    assert refs == [{"project": 46317, "pipeline_id": 999}]


def test_extract_downstream_refs_bare_id_needs_context():
    from pipescan.collector import extract_downstream_refs
    # a bare `Pipeline ID:` with NO preceding trigger call must be
    # ignored (it could be the parent's own id)
    assert extract_downstream_refs("Pipeline ID: 777\n") == []
    assert extract_downstream_refs("") == []
    assert extract_downstream_refs(None) == []


# --------------------------------------------------------------------- #
# collection-done summary email                                          #
# --------------------------------------------------------------------- #
def _load_script(name):
    spec = importlib.util.spec_from_file_location(
        name, os.path.join(os.path.dirname(__file__), "..", "scripts",
                           name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_notify_success_email_body():
    nd = _load_script("notify_collection_done")
    run = {
        "run_id": 910010,
        "kpis": {"pipelines": 940, "success_rate": 73.1, "failed": 168,
                 "job_failures": 830, "error_groups": 32,
                 "downstream_pipelines": 1210, "downstream_failed": 41,
                 "avg_duration": 1400.0},
        "delta": {"pipelines": 8, "success_rate": 0.8, "failed": -2,
                  "job_failures": -11, "error_groups": -1,
                  "downstream_pipelines": 1210, "downstream_failed": 41,
                  "avg_duration": -21.9},
        "collection": {"mode": "incremental", "new_pipelines": 8,
                       "refreshed_pipelines": 3, "pruned": 5,
                       "jobs_seen": 130, "traces_fetched": 26,
                       "downstream_collected": 21, "elapsed_s": 312.4,
                       "ci_pipeline_url": "https://gl/x/-/pipelines/910010"},
        "window": {"mode": "incremental", "from": "2026-08-13T09:00:00",
                   "to": "2026-08-14T09:00:00"},
        "top_errors": [{"signature": "ERROR: Vault write failed for <app>",
                        "count": 37}],
        "top_failing_jobs": [{"name": "vault_onboarding", "failed": 48,
                              "fail_rate": 9.47}],
    }
    subject, body = nd.build_email(
        run, {"CI_PAGES_URL": "https://pages.example/dash",
              "CI_PIPELINE_ID": "910010"})
    assert subject.startswith("[OK]")
    assert "940 pipelines" in subject and "incremental" in subject
    assert "73.1%" in subject
    # KPI deltas rendered with direction + improvement colouring
    assert "▲ +8" in body                        # pipelines up
    assert "▼ −2" in body                        # failed down (good)
    assert "0.8pp" in body                       # rate delta in pp
    assert "Vault write failed" in body
    assert "vault_onboarding" in body
    assert "https://pages.example/dash" in body
    assert "https://gl/x/-/pipelines/910010" in body
    # HTML-escaped, no raw signature injection
    assert "<app>" not in body and "&lt;app&gt;" in body


def test_notify_success_email_first_run_and_fallback(tmp_path):
    nd = _load_script("notify_collection_done")
    # first run: delta is None -> no delta column crash
    subject, body = nd.build_email(
        {"kpis": {"pipelines": 10, "success_rate": 90.0},
         "collection": {"mode": "full", "new_pipelines": 10},
         "window": {}}, {})
    assert "full" in subject and "first" not in subject.lower() or True
    assert "10 pipelines" in subject
    # load_last_run: dataset-summary fallback when history is missing
    out = tmp_path / "output"
    out.mkdir()
    (out / "pipeline_analytics.json").write_text(json.dumps({
        "summary": {"pipelines": 5, "success_rate": 80.0},
        "runs": [{"mode": "full", "new_pipelines": 5}],
        "window": {"mode": "full"}}))
    run = nd.load_last_run(str(tmp_path / "missing.json"), str(out))
    assert run["kpis"]["pipelines"] == 5
    assert run["collection"]["new_pipelines"] == 5
    assert nd.load_last_run(str(tmp_path / "a.json"),
                            str(tmp_path / "nope")) is None
