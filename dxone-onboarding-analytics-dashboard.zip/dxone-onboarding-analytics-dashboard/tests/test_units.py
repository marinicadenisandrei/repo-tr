from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from pipescan.collector import parse_workflow_name
from pipescan.errors import extract_error_lines, normalize_signature
from pipescan.state import (empty_state, load_state, prune_state,
                            save_state)

import importlib.util
import os

_spec = importlib.util.spec_from_file_location(
    "build_history",
    os.path.join(os.path.dirname(__file__), "..", "scripts",
                 "build_history.py"))
build_history = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(build_history)


# ---------------------------------------------------------------------- #
# workflow-name parsing                                                  #
# ---------------------------------------------------------------------- #
def test_parse_workflow_name_snow():
    meta = parse_workflow_name(
        "Onboarding asset [APP-01680] Triggered from [SNOW prod]")
    assert meta == {"asset_id": "APP-01680", "trigger_source": "SNOW",
                    "env": "prod"}


def test_parse_workflow_name_lmp_with_suffix():
    meta = parse_workflow_name(
        "Onboarding asset [APP-52501] Triggered from [LMP dev], "
        "Orchestrator ID: 42")
    assert meta["asset_id"] == "APP-52501"
    assert meta["trigger_source"] == "LMP"
    assert meta["env"] == "dev"


def test_parse_workflow_name_unrelated():
    assert parse_workflow_name("Push to master (abc123)") == \
        {"asset_id": None, "trigger_source": None, "env": None}
    assert parse_workflow_name(None)["asset_id"] is None


# ---------------------------------------------------------------------- #
# error extraction + signatures                                          #
# ---------------------------------------------------------------------- #
def test_extract_error_lines_ranks_terminal_error_first():
    trace = ("ok step\n"
             "\x1b[31mERROR: request to https://api.example.com/v1 "
             "timed out after 30s\x1b[0m\n"
             "ERROR: Job failed: exit code 1\n")
    lines = extract_error_lines(trace)
    assert "timed out" in lines[0]
    assert any(ln.startswith("ERROR: Job failed") for ln in lines)
    assert not any("\x1b" in ln for ln in lines)     # ANSI stripped


def test_signature_masks_volatile_tokens():
    a = normalize_signature(
        "ERROR: Vault write failed for APP-1111 RITM0012345 at "
        "2026-08-13T10:00:00Z (req 9f8e7d6c5b4a)")
    b = normalize_signature(
        "ERROR: Vault write failed for APP-2222 RITM0099999 at "
        "2026-08-14T11:30:00Z (req 1a2b3c4d5e6f)")
    assert a == b
    assert "<app>" in a and "<ticket>" in a and "<ts>" in a


def test_signature_length_cap():
    sig = normalize_signature("ERROR: " + "x" * 1000)
    assert len(sig) <= 261


# ---------------------------------------------------------------------- #
# state round-trip + pruning                                             #
# ---------------------------------------------------------------------- #
def test_state_roundtrip_gz(tmp_path):
    path = str(tmp_path / "state.json.gz")
    state = empty_state(12811)
    state["pipelines"]["1"] = {"id": 1, "status": "success",
                               "updated_at": "2026-08-01T00:00:00+00:00"}
    save_state(state, path)
    loaded = load_state(path, project_id=12811)
    assert loaded["pipelines"]["1"]["status"] == "success"
    # a state of another project is never merged in
    assert load_state(path, project_id=999)["pipelines"] == {}


def test_state_corrupt_falls_back_to_empty(tmp_path):
    path = str(tmp_path / "state.json")
    path_obj = tmp_path / "state.json"
    path_obj.write_text("{not json")
    assert load_state(path, 12811)["pipelines"] == {}


def test_prune_state_drops_old_records():
    now = datetime(2026, 8, 14, tzinfo=timezone.utc)
    state = empty_state(1)
    state["pipelines"] = {
        "old": {"updated_at": (now - timedelta(days=250)).isoformat()},
        "new": {"updated_at": (now - timedelta(days=5)).isoformat()},
    }
    dropped = prune_state(state, keep_days=190, now=now)
    assert dropped == 1 and list(state["pipelines"]) == ["new"]


# ---------------------------------------------------------------------- #
# history builder                                                        #
# ---------------------------------------------------------------------- #
def _mini_dataset(pipelines=10, failed=2):
    return {
        "summary": {"pipelines": pipelines, "success": pipelines - failed,
                    "failed": failed, "canceled": 0,
                    "success_rate": 100.0 * (pipelines - failed) / pipelines,
                    "jobs": pipelines * 5, "job_failures": failed,
                    "retries": 1, "downstream_pipelines": 3,
                    "downstream_failed": 0, "error_groups": 2, "assets": 4,
                    "duration": {"avg": 500.0, "p95": 900.0}},
        "window": {"mode": "incremental"},
        "runs": [{"mode": "incremental", "new_pipelines": 3,
                  "elapsed_s": 42.0, "ci_pipeline_id": "555"}],
        "errors": [{"signature": "ERROR: x", "count": 5}],
        "jobs": [{"name": "vault_onboarding", "failed": 2,
                  "fail_rate": 20.0}],
    }


def test_history_records_run_and_deltas(tmp_path):
    out = str(tmp_path / "history.json")
    snap1 = tmp_path / "s1.json"
    snap1.write_text(json.dumps(_mini_dataset(10, 2)))
    assert build_history.main(["--snapshot", str(snap1), "--output", out,
                               "--run-id", "1"]) == 0
    snap2 = tmp_path / "s2.json"
    snap2.write_text(json.dumps(_mini_dataset(14, 3)))
    assert build_history.main(["--history", out, "--snapshot", str(snap2),
                               "--output", out, "--run-id", "2"]) == 0
    hist = json.loads(open(out).read())
    assert len(hist["runs"]) == 2
    assert hist["runs"][1]["delta"]["pipelines"] == 4
    assert hist["runs"][1]["delta"]["failed"] == 1
    assert hist["error_track"]["ERROR: x"]["runs_seen"] == 2


def test_history_allow_empty_carries_forward(tmp_path):
    out = str(tmp_path / "history.json")
    snap = tmp_path / "s.json"
    snap.write_text(json.dumps(_mini_dataset()))
    build_history.main(["--snapshot", str(snap), "--output", out,
                        "--run-id", "1"])
    assert build_history.main(["--history", out, "--output", out,
                               "--allow-empty"]) == 0
    assert len(json.loads(open(out).read())["runs"]) == 1
