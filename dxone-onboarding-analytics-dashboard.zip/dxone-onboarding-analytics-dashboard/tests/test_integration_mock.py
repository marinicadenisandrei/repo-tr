"""End-to-end collection against an in-process mock GitLab server.

Exercises: 6-month backfill -> incremental second run (only new pipelines
collected, records appended), downstream pipeline recursion, retry
counting, error extraction from failed-job traces.
"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import pytest

from pipescan.collector import Collector
from pipescan.dataset import build_dataset
from pipescan.gitlab_client import GitLabClient
from pipescan.state import empty_state

NOW = datetime(2026, 8, 14, 12, 0, tzinfo=timezone.utc)


def iso(dt: datetime) -> str:
    return dt.isoformat().replace("+00:00", "Z")


def make_fixture() -> dict:
    """3 parent pipelines in project 12811, one with a downstream child in
    project 777 and a failed job with a retried attempt."""
    p = {}
    p["pipelines"] = {
        12811: [
            {"id": 101, "iid": 1, "status": "success", "source": "trigger",
             "ref": "master", "sha": "a" * 40,
             "name": "Onboarding asset [APP-01680] Triggered from [SNOW prod]",
             "created_at": iso(NOW - timedelta(days=2)),
             "updated_at": iso(NOW - timedelta(days=2)),
             "finished_at": iso(NOW - timedelta(days=2, hours=-1)),
             "duration": 900, "queued_duration": 12,
             "user": {"username": "svc"}, "web_url": "u/101"},
            {"id": 102, "iid": 2, "status": "failed", "source": "trigger",
             "ref": "master", "sha": "b" * 40,
             "name": "Onboarding asset [APP-99999] Triggered from [LMP dev]",
             "created_at": iso(NOW - timedelta(days=1)),
             "updated_at": iso(NOW - timedelta(days=1)),
             "finished_at": iso(NOW - timedelta(hours=20)),
             "duration": 300, "queued_duration": 5,
             "user": {"username": "svc"}, "web_url": "u/102"},
        ],
        777: [
            {"id": 501, "iid": 9, "status": "success", "source": "pipeline",
             "ref": "main", "sha": "c" * 40, "name": None,
             "created_at": iso(NOW - timedelta(days=2)),
             "updated_at": iso(NOW - timedelta(days=2)),
             "duration": 120, "queued_duration": 3,
             "user": None, "web_url": "u/501"},
        ],
    }
    p["jobs"] = {
        (12811, 101): [
            {"id": 1001, "name": "check_assetid", "stage": "check",
             "status": "success", "duration": 30, "queued_duration": 2,
             "retried": False, "created_at": iso(NOW - timedelta(days=2)),
             "finished_at": iso(NOW - timedelta(days=2)),
             "web_url": "j/1001"},
        ],
        (12811, 102): [
            {"id": 1002, "name": "vault_onboarding", "stage": "vault",
             "status": "failed", "duration": 60, "queued_duration": 1,
             "retried": True, "failure_reason": "script_failure",
             "created_at": iso(NOW - timedelta(days=1)),
             "finished_at": iso(NOW - timedelta(days=1)),
             "web_url": "j/1002"},
            {"id": 1003, "name": "vault_onboarding", "stage": "vault",
             "status": "failed", "duration": 65, "queued_duration": 1,
             "retried": False, "failure_reason": "script_failure",
             "created_at": iso(NOW - timedelta(days=1)),
             "finished_at": iso(NOW - timedelta(days=1)),
             "web_url": "j/1003"},
        ],
        (777, 501): [
            {"id": 5001, "name": "child_job", "stage": "deploy",
             "status": "success", "duration": 50, "queued_duration": 1,
             "retried": False, "created_at": iso(NOW - timedelta(days=2)),
             "finished_at": iso(NOW - timedelta(days=2)),
             "web_url": "j/5001"},
        ],
    }
    p["bridges"] = {
        (12811, 101): [
            {"id": 9001, "name": "trigger_child", "status": "success",
             "downstream_pipeline": {"id": 501, "project_id": 777,
                                     "status": "success", "ref": "main",
                                     "web_url": "u/501"}},
        ],
    }
    p["traces"] = {
        (12811, 1003): "step 1 ok\nstep 2 ok\n"
                       "ERROR: Vault write failed for APP-99999: "
                       "HTTP 403 Forbidden at 2026-08-13T10:00:00Z\n"
                       "ERROR: Job failed: exit code 1\n",
    }
    return p


class Handler(BaseHTTPRequestHandler):
    fixture: dict = {}

    def log_message(self, *a):  # noqa: D102
        pass

    def _json(self, payload, status=200):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        u = urlparse(self.path)
        q = parse_qs(u.query)
        fx = self.fixture
        path = u.path
        if path == "/api/v4/version":
            return self._json({"version": "17.0-mock"})
        m = re.fullmatch(r"/api/v4/projects/(\d+)", path)
        if m:
            pid = int(m.group(1))
            return self._json({"id": pid, "path_with_namespace": f"g/p{pid}",
                               "name": f"p{pid}", "web_url": f"u/p{pid}",
                               "default_branch": "master"})
        m = re.fullmatch(r"/api/v4/projects/(\d+)/pipelines", path)
        if m:
            pid = int(m.group(1))
            after = q.get("updated_after", [None])[0]
            items = fx["pipelines"].get(pid, [])
            if after:
                items = [p for p in items if p["updated_at"] > after]
            return self._json([{k: p[k] for k in
                                ("id", "iid", "status", "source", "ref",
                                 "sha", "created_at", "updated_at",
                                 "web_url", "name")} for p in items])
        m = re.fullmatch(r"/api/v4/projects/(\d+)/pipelines/(\d+)", path)
        if m:
            pid, plid = int(m.group(1)), int(m.group(2))
            for p in fx["pipelines"].get(pid, []):
                if p["id"] == plid:
                    return self._json(p)
            return self._json({"message": "404"}, 404)
        m = re.fullmatch(r"/api/v4/projects/(\d+)/pipelines/(\d+)/jobs", path)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            return self._json(fx["jobs"].get(key, []))
        m = re.fullmatch(r"/api/v4/projects/(\d+)/pipelines/(\d+)/bridges",
                         path)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            return self._json(fx["bridges"].get(key, []))
        m = re.fullmatch(r"/api/v4/projects/(\d+)/jobs/(\d+)/trace", path)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            body = fx["traces"].get(key, "").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self._json({"message": "not found"}, 404)


@pytest.fixture()
def mock_server():
    Handler.fixture = make_fixture()
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()


def test_backfill_then_incremental(mock_server):
    client = GitLabClient(mock_server, "token", pool_size=4)
    collector = Collector(client, 12811, workers=2, trace_workers=2)
    state = empty_state(12811)

    # ---- run 1: full backfill ---------------------------------------
    after, mode = collector.plan_window(state, backfill_days=183)
    assert mode == "full"
    result = collector.collect(state, after, mode)
    assert result["collected"] == 2 and result["new"] == 2
    assert set(state["pipelines"]) == {"101", "102"}

    # downstream recursion: pipeline 101 carries the child detail
    ds = state["pipelines"]["101"]["downstream"]
    assert len(ds) == 1 and ds[0]["kind"] == "multi-project"
    assert ds[0]["detail"]["id"] == 501
    assert ds[0]["detail"]["jobs"][0]["name"] == "child_job"

    # error extraction on the failed (non-retried) job of pipeline 102
    errs = state["pipelines"]["102"]["errors"]
    assert len(errs) == 1
    assert "Vault write failed" in errs[0]["message"]
    assert "<app>" in errs[0]["signature"]      # asset id masked
    assert "<ts>" not in errs[0]["message"]     # raw message untouched

    # ---- dataset ------------------------------------------------------
    dataset = build_dataset(state, {"id": 12811}, mock_server,
                            {"mode": mode, "from": "x", "to": "y"})
    s = dataset["summary"]
    assert s["pipelines"] == 2 and s["success"] == 1 and s["failed"] == 1
    assert s["success_rate"] == 50.0
    assert s["retries"] == 1
    assert s["downstream_pipelines"] == 1
    vault = next(j for j in dataset["jobs"] if j["name"] == "vault_onboarding")
    assert vault["failed"] == 2 and vault["retries"] == 1
    assert dataset["errors"][0]["count"] == 1
    assert dataset["assets"][0]["asset_id"] in ("APP-01680", "APP-99999")
    assert dataset["trigger_sources"] == {"SNOW": 1, "LMP": 1}

    # ---- run 2: incremental with one NEW pipeline ---------------------
    state["last_run_at"] = iso(NOW - timedelta(hours=12))
    Handler.fixture["pipelines"][12811].append(
        {"id": 103, "iid": 3, "status": "success", "source": "web",
         "ref": "master", "sha": "d" * 40, "name": None,
         "created_at": iso(NOW - timedelta(hours=1)),
         "updated_at": iso(NOW - timedelta(hours=1)),
         "duration": 100, "queued_duration": 2, "user": None,
         "web_url": "u/103"})
    Handler.fixture["jobs"][(12811, 103)] = []
    after, mode = collector.plan_window(state, backfill_days=183)
    assert mode == "incremental"
    result = collector.collect(state, after, mode)
    assert result["new"] == 1                      # only 103 is new
    assert set(state["pipelines"]) == {"101", "102", "103"}
