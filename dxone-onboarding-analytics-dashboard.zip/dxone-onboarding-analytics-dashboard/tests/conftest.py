"""Shared test fixtures.

CI runners in corporate networks export HTTP(S)_PROXY, and `requests`
honours those variables by default - which would route the integration
test's calls to its 127.0.0.1 mock server through the egress proxy
(observed as an HTTP 403 from the proxy instead of the mock response).

Strip every proxy variable for the duration of each test so the suite
behaves identically on laptops and on proxied CI runners. Production
code is deliberately untouched: the real collector keeps honouring the
runner's proxy configuration.
"""
from __future__ import annotations

import pytest

_PROXY_VARS = (
    "HTTP_PROXY", "http_proxy",
    "HTTPS_PROXY", "https_proxy",
    "ALL_PROXY", "all_proxy",
    "FTP_PROXY", "ftp_proxy",
)


@pytest.fixture(autouse=True)
def _no_proxy_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in _PROXY_VARS:
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("NO_PROXY", "*")
    monkeypatch.setenv("no_proxy", "*")
