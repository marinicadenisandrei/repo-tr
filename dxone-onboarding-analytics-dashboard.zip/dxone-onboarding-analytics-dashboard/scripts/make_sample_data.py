#!/usr/bin/env python3
"""Regenerate the committed demo dataset + history sample.

Synthesizes ~6 months of realistic onboarding-pipeline records and runs
them through the REAL dataset builder (``pipescan.dataset.build_dataset``)
and the REAL history builder (``scripts/build_history.py``), so the samples
always match the production schema exactly.  Used by the dashboard as a
preview when ``data/pipeline_analytics.json`` is not published yet, and by
``SKIP_FETCH=true`` deploys.

    python3 scripts/make_sample_data.py
"""
from __future__ import annotations

import json
import os
import random
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from pipescan.dataset import build_dataset            # noqa: E402
from pipescan.errors import normalize_signature       # noqa: E402
from pipescan.state import empty_state                # noqa: E402

random.seed(12811)
NOW = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
PROJECT_ID = 12811
GITLAB_URL = "https://gitlab.dx1.lseg.com"
PROJ_URL = f"{GITLAB_URL}/dxone/dxone-onboarding-master"

STAGES_JOBS = [
    (".pre", ["0-runner-auth", "pipeline_validator"]),
    ("check_assetid", ["check_assetid"]),
    ("ldap_email_validation", ["ldap_email_validation"]),
    ("gitlab_onboarding", ["gitlab_onboarding"]),
    ("vault_onboarding", ["vault_onboarding"]),
    ("sonarqube", ["trigger_sonarqube_onboarding"]),
    ("artifactory", ["prepare_trigger_artifactory_onboarding",
                     "artifactory_onboarding"]),
    ("azure_ad", ["azure_ad_group_setup"]),
    ("firewall", ["firewall_whitelisting"]),
    ("datadog", ["trigger_datadog_onboarding"]),
    ("notify", ["update_snow_ticket"]),
]

ERRORS = [
    ("vault_onboarding",
     "ERROR: Vault write failed for {app}: HTTP 403 Forbidden "
     "(namespace /global/internet, req {hexid})", "script_failure", 0.30),
    ("ldap_email_validation",
     "ERROR: LDAP lookup timed out after 30s for user group {app} "
     "(dc03.prod.stockex.local)", "script_failure", 0.18),
    ("gitlab_onboarding",
     "ERROR: group creation failed: HTTP 409 Conflict - path app/{app} "
     "already exists", "script_failure", 0.14),
    ("artifactory_onboarding",
     "requests.exceptions.HTTPError: 502 Server Error: Bad Gateway for "
     "url: https://artifactory.lseg.com/api/repositories/{app}",
     "script_failure", 0.12),
    ("update_snow_ticket",
     "ERROR: ServiceNow API rejected update of {ticket}: HTTP 401 "
     "Unauthorized (token expired {ts})", "script_failure", 0.10),
    ("trigger_datadog_onboarding",
     "FATAL: Datadog org provisioning failed: quota exceeded for "
     "{app} (monitors 500/500)", "script_failure", 0.06),
    ("firewall_whitelisting",
     "ERROR: firewall request {ticket} stuck in state PENDING_APPROVAL "
     "after 3600s", "stuck_or_timeout_failure", 0.06),
    ("check_assetid",
     "ERROR: asset {app} not found in LeanIX workspace (query returned "
     "0 fact sheets)", "script_failure", 0.04),
]

# (project_id, project name, path, trigger job, probability) - the REAL
# projects the onboarding trigger scripts start through the GitLab
# trigger API (trigger_sonarqube_onboarding.py /
# prepare_trigger_artifactory_onboarding.py / trigger_datadog_onboarding.py)
DOWNSTREAM_PROJECTS = [
    (46317, "group-onboarding",
     "app/app-51255/sonarqube-onboarding/group-onboarding",
     "trigger_sonarqube_onboarding", 0.85),
    (146326, "artifactory-automation",
     "app/app-51411/artifactory-onboarding/artifactory-automation",
     "prepare_trigger_artifactory_onboarding", 0.80),
    (93334, "dd-onprem-ad-group-manage",
     "206155/strategic-datadog-onboarding/dd-onprem-ad-group-manage",
     "trigger_datadog_onboarding", 0.55),
]


def iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def pick_error(rnd: random.Random):
    r, acc = rnd.random(), 0.0
    for job, tmpl, reason, w in ERRORS:
        acc += w
        if r <= acc:
            return job, tmpl, reason
    return ERRORS[0][:3]


def render_error(tmpl: str, rnd: random.Random, app: str,
                 when: datetime) -> str:
    return tmpl.format(
        app=app,
        ticket=f"RITM{rnd.randint(1000000, 9999999)}",
        hexid="".join(rnd.choice("0123456789abcdef") for _ in range(12)),
        ts=iso(when))


def make_jobs(rnd: random.Random, created: datetime, ok: bool,
              fail_job: str | None, jid_start: int,
              pipe_slow: float) -> tuple[list[dict], datetime]:
    jobs, t, jid = [], created, jid_start
    reached_fail = False
    for stage, names in STAGES_JOBS:
        if reached_fail:
            break
        for name in names:
            base = {"0-runner-auth": 25, "pipeline_validator": 15,
                    "check_assetid": 45, "ldap_email_validation": 60,
                    "gitlab_onboarding": 180, "vault_onboarding": 120,
                    "trigger_sonarqube_onboarding": 90,
                    "prepare_trigger_artifactory_onboarding": 40,
                    "artifactory_onboarding": 240,
                    "azure_ad_group_setup": 150,
                    "firewall_whitelisting": 300,
                    "trigger_datadog_onboarding": 110,
                    "update_snow_ticket": 30}.get(name, 60)
            dur = round(base * pipe_slow * rnd.uniform(0.7, 1.5), 1)
            queued = round(rnd.uniform(1, 25), 1)
            failed_here = (not ok) and name == fail_job
            retried_attempt = failed_here and rnd.random() < 0.45
            start = t + timedelta(seconds=queued)
            fin = start + timedelta(seconds=dur)
            if retried_attempt:      # first failed attempt, then retried
                jobs.append({
                    "id": jid, "name": name, "stage": stage,
                    "status": "failed", "created_at": iso(t),
                    "started_at": iso(start), "finished_at": iso(fin),
                    "duration": dur, "queued_duration": queued,
                    "failure_reason": "script_failure",
                    "allow_failure": False, "retried": True,
                    "web_url": f"{PROJ_URL}/-/jobs/{jid}",
                    "runner": {"id": 4200 + rnd.randint(0, 5),
                               "description": "lseg-k8s-runner",
                               "runner_type": "group_type"}})
                jid += 1
                t = fin + timedelta(seconds=rnd.uniform(5, 30))
                start = t + timedelta(seconds=queued)
                fin = start + timedelta(seconds=dur * rnd.uniform(0.8, 1.2))
            jobs.append({
                "id": jid, "name": name, "stage": stage,
                "status": "failed" if failed_here else "success",
                "created_at": iso(t), "started_at": iso(start),
                "finished_at": iso(fin),
                "duration": round((fin - start).total_seconds(), 1),
                "queued_duration": queued,
                "failure_reason": "script_failure" if failed_here else None,
                "allow_failure": False, "retried": False,
                "web_url": f"{PROJ_URL}/-/jobs/{jid}",
                "runner": {"id": 4200 + rnd.randint(0, 5),
                           "description": "lseg-k8s-runner",
                           "runner_type": "group_type"}})
            jid += 1
            t = fin
            if failed_here:
                reached_fail = True
                break
    return jobs, t


def make_downstream(rnd: random.Random, created: datetime, parent_ok: bool,
                    ds_id_start: int) -> list[dict]:
    out, dsid = [], ds_id_start
    for proj_id, name, path, trig_job, prob in DOWNSTREAM_PROJECTS:
        if not parent_ok and rnd.random() < 0.6:
            continue                      # parent failed before triggering
        if rnd.random() > prob:
            continue
        ds_ok = rnd.random() > (0.06 if parent_ok else 0.35)
        dur = round(rnd.uniform(60, 420), 1)
        st = created + timedelta(seconds=rnd.uniform(120, 600))
        detail = {
            "id": dsid, "iid": None, "project_id": proj_id,
            "is_downstream": True,
            "status": "success" if ds_ok else "failed",
            "source": "pipeline", "ref": "main", "sha": "",
            "name": None, "asset_id": None, "trigger_source": None,
            "env": None, "user": None,
            "created_at": iso(st), "started_at": iso(st),
            "finished_at": iso(st + timedelta(seconds=dur)),
            "updated_at": iso(st + timedelta(seconds=dur)),
            "duration": dur, "queued_duration": round(rnd.uniform(2, 20), 1),
            "web_url": f"{GITLAB_URL}/{path}/-/pipelines/{dsid}",
            "jobs": [], "errors": [], "downstream": [],
        }
        out.append({
            "bridge_name": trig_job,
            "bridge_status": detail["status"],
            "pipeline_id": dsid, "project_id": proj_id,
            "project_name": name, "project_path": path,
            "status": detail["status"], "web_url": detail["web_url"],
            "ref": "main", "created_at": detail["created_at"],
            "duration": detail["duration"],
            "kind": "api-triggered", "detail": detail})
        dsid += 1
    return out


def main() -> int:
    rnd = random.Random(20260814)
    state = empty_state(PROJECT_ID)
    state["projects"] = {
        str(pid): {"id": pid, "name": name, "path": path,
                   "web_url": f"{GITLAB_URL}/{path}"}
        for pid, name, path, _job, _prob in DOWNSTREAM_PROJECTS}
    pid, jid, dsid = 480000, 9100000, 700000
    day0 = NOW - timedelta(days=182)

    apps = [f"APP-{n}" for n in
            (52501, 51696, 205819, 250646, 53107, 51987, 206072, 52863,
             250230, 51404, 205443, 52218, 53244, 250571, 206160, 51883)]

    for d in range(183):
        day = day0 + timedelta(days=d)
        weekday = day.weekday() < 5
        # gentle growth + weekday load + mid-window incident spike
        n = max(0, int(rnd.gauss((3.2 if weekday else 0.9) + d / 90, 1.6)))
        if 88 <= d <= 95:                      # a bad week
            n += rnd.randint(1, 3)
        for _ in range(n):
            created = day.replace(hour=rnd.randint(6, 19),
                                  minute=rnd.randint(0, 59))
            src = rnd.choices(["SNOW", "LMP", "WEB"],
                              weights=[62, 30, 8])[0]
            env = rnd.choices(["prod", "dev", "ppe"],
                              weights=[70, 20, 10])[0]
            app = rnd.choice(apps)
            fail_p = 0.14 if not (88 <= d <= 95) else 0.42
            status = rnd.choices(["success", "failed", "canceled"],
                                 weights=[1 - fail_p - 0.02, fail_p, 0.02])[0]
            ok = status == "success"
            fail_job = tmpl = reason = None
            if status == "failed":
                fail_job, tmpl, reason = pick_error(rnd)
                if 88 <= d <= 95 and rnd.random() < 0.6:
                    fail_job, tmpl, reason = ERRORS[0][:3]   # vault incident
            slow = rnd.uniform(0.8, 1.3) * (1 + d / 600)     # slow drift up
            jobs, end = make_jobs(rnd, created, ok, fail_job, jid, slow)
            jid += len(jobs) + 2
            errors = []
            if status == "failed" and tmpl:
                msg = render_error(tmpl, rnd, app, created)
                failed_rec = next(j for j in jobs
                                  if j["status"] == "failed"
                                  and not j["retried"])
                errors.append({
                    "job_id": failed_rec["id"],
                    "job_name": failed_rec["name"],
                    "stage": failed_rec["stage"],
                    "failure_reason": reason,
                    "job_url": failed_rec["web_url"],
                    "message": msg,
                    "signature": normalize_signature(msg),
                    "context": ["ERROR: Job failed: exit code 1"]})
            if status == "canceled":
                jobs = jobs[: rnd.randint(1, max(2, len(jobs) // 3))]
                end = created + timedelta(seconds=rnd.uniform(60, 400))
            downstream = make_downstream(rnd, created, ok, dsid)
            dsid += len(downstream)
            dur = round((end - created).total_seconds(), 1)
            name = (f"Onboarding asset [{app}] Triggered from "
                    f"[{src} {env}]" if src != "WEB" else
                    "Write CI/CD variables to Vault Secrets")
            state["pipelines"][str(pid)] = {
                "id": pid, "iid": pid - 479000, "project_id": PROJECT_ID,
                "is_downstream": False, "status": status,
                "source": ("trigger" if src in ("SNOW", "LMP") else "web"),
                "ref": "master", "sha": "%012x" % rnd.getrandbits(48),
                "name": name,
                "asset_id": app if src != "WEB" else None,
                "trigger_source": src if src != "WEB" else None,
                "env": env if src != "WEB" else None,
                "user": {"username": "svc_dxone", "name": "DXOne Service"},
                "created_at": iso(created), "started_at": iso(created),
                "finished_at": iso(end), "updated_at": iso(end),
                "duration": dur,
                "queued_duration": round(rnd.uniform(2, 40), 1),
                "web_url": f"{PROJ_URL}/-/pipelines/{pid}",
                "jobs": jobs, "errors": errors, "downstream": downstream,
            }
            pid += 1

    # collection-run bookkeeping (as the collector would have written it)
    run_days = [150, 120, 90, 60, 30, 14, 7, 3, 1, 0]
    for i, back in enumerate(run_days):
        at = NOW - timedelta(days=back, hours=rnd.randint(0, 3))
        state["runs"].append({
            "run_at": iso(at - timedelta(minutes=rnd.randint(6, 25))),
            "finished_at": iso(at),
            "elapsed_s": round(rnd.uniform(180, 900), 1),
            "mode": "full" if i == 0 else "incremental",
            "updated_after": iso(at - timedelta(days=183 if i == 0
                                                else (run_days[i - 1] - back
                                                      or 1))),
            "collected": rnd.randint(30, 400) if i else 460,
            "new_pipelines": rnd.randint(20, 120) if i else 460,
            "refreshed_pipelines": rnd.randint(0, 8),
            "pruned": rnd.randint(0, 12) if i > 4 else 0,
            "jobs_seen": rnd.randint(300, 4000),
            "traces_fetched": rnd.randint(5, 90),
            "downstream_collected": rnd.randint(40, 700),
            "pipeline_total_after": 0,
            "ci_pipeline_id": str(910000 + i),
            "ci_pipeline_url": f"{GITLAB_URL}/dxone/"
                               f"dxone-onboarding-dashboard/-/pipelines/"
                               f"{910000 + i}",
        })
    state["last_run_at"] = iso(NOW)

    project = {"id": PROJECT_ID,
               "path_with_namespace": "dxone/dxone-onboarding-master",
               "name": "dxone-onboarding-master",
               "web_url": PROJ_URL, "default_branch": "master"}
    window = {"mode": "incremental",
              "from": iso(day0), "to": iso(NOW), "backfill_days": 183}
    dataset = build_dataset(state, project, GITLAB_URL, window)

    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir)
    static = os.path.join(here, "static")
    os.makedirs(static, exist_ok=True)
    out = os.path.join(static, "pipeline_analytics_sample.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(dataset, f, separators=(",", ":"))
    print(f"Sample dataset: {out} ({os.path.getsize(out) // 1024} KB, "
          f"{dataset['summary']['pipelines']} pipelines, "
          f"{dataset['summary']['jobs']} jobs, "
          f"{len(dataset['errors'])} error groups)")

    # ---- history sample: replay the collection runs through the REAL
    #      history builder so schema + deltas are authentic ---------------
    hist_out = os.path.join(static, "history_sample.json")
    if os.path.exists(hist_out):
        os.unlink(hist_out)
    builder = os.path.join(here, "scripts", "build_history.py")
    for i, back in enumerate(run_days):
        # KPI snapshot AT that run: dataset rebuilt from records existing then
        cutoff = iso(NOW - timedelta(days=back))
        sub = empty_state(PROJECT_ID)
        sub["pipelines"] = {k: v for k, v in state["pipelines"].items()
                            if (v.get("created_at") or "") <= cutoff}
        sub["runs"] = state["runs"][: i + 1]
        snap = build_dataset(sub, project, GITLAB_URL, window)
        with tempfile.NamedTemporaryFile("w", suffix=".json",
                                         delete=False) as tf:
            json.dump(snap, tf, separators=(",", ":"))
            tmp = tf.name
        cmd = [sys.executable, builder, "--snapshot", tmp,
               "--output", hist_out, "--run-id", str(910000 + i)]
        if os.path.exists(hist_out):
            cmd += ["--history", hist_out]
        subprocess.run(cmd, check=True, capture_output=True)
        os.unlink(tmp)
    # dashboard copy has no error_track (same as the published slim history)
    hist = json.load(open(hist_out))
    hist.pop("error_track", None)
    with open(hist_out, "w", encoding="utf-8") as f:
        json.dump(hist, f, separators=(",", ":"))
    print(f"Sample history: {hist_out} ({os.path.getsize(hist_out) // 1024} "
          f"KB, {len(hist['runs'])} runs)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
