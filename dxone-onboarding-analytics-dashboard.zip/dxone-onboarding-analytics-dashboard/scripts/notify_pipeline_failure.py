#!/usr/bin/env python3
"""URGENT email when a scheduled dashboard pipeline fails.

Run by the ``notify-failure`` CI job (last stage, ``when: on_failure``).
Queries the GitLab API for this pipeline's failed jobs and emails the
configured recipients with the message marked high-importance
(X-Priority / X-MSMail-Priority / Importance headers -> red exclamation
mark in Outlook).

Design constraints (a failure notifier must be more reliable than the
pipeline it reports on):
  * STDLIB ONLY - no ``pip install`` in the notify job: a broken package
    mirror may be exactly why the pipeline failed.
  * Every step degrades, none aborts: if the failed-job lookup fails, the
    email still goes out with the pipeline link; only an SMTP delivery
    failure exits non-zero (the CI job is allow_failure, so the pipeline
    status is not further disturbed).

Environment:
  CI_API_V4_URL, CI_PROJECT_ID, CI_PIPELINE_ID, CI_PROJECT_URL,
  CI_JOB_TOKEN                                             (GitLab)
  GITLAB_TOKEN (optional; used over CI_JOB_TOKEN when present)
  NOTIFY_NO_VERIFY_SSL=true (optional; self-signed instance certs)
  SMTP_HOST / SMTP_PORT / ALERT_TO / ALERT_FROM
"""
from __future__ import annotations

import json
import os
import smtplib
import ssl

import urllib.error
import urllib.request
from datetime import datetime, timezone
from email.mime.text import MIMEText
from html import escape

TIMEOUT = 30
MAX_PAGES = 5

DEFAULT_ALERT_RECIPIENTS = [
    "Kanaganathan.Arulselvan@lseg.com",
    "Akash.Gupta2@lseg.com",
    "denis.marinica@lseg.com",
]


def log(msg: str = "") -> None:
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def smtp_settings() -> tuple[str, int, str, list[str]]:
    host = os.getenv("SMTP_HOST", "smtp.prod.stockex.local")
    port = int(os.getenv("SMTP_PORT", "25"))
    sender = os.getenv("ALERT_FROM",
                       "dxone_onboarding_dashboard@lseg.com")
    to_raw = os.getenv("ALERT_TO", "").strip()
    to = [a.strip() for a in to_raw.split(",") if a.strip()] \
        or list(DEFAULT_ALERT_RECIPIENTS)
    return host, port, sender, to


def api_get(url: str, headers: dict) -> list | dict:
    req = urllib.request.Request(url, headers=headers)
    ctx = None
    if os.getenv("NOTIFY_NO_VERIFY_SSL", "").lower() == "true":
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    with urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx) as r:
        return json.loads(r.read().decode("utf-8"))


def fetch_failed_jobs() -> list[dict]:
    """Failed jobs of THIS pipeline via the GitLab API; [] on any error."""
    api = os.getenv("CI_API_V4_URL", "")
    project = os.getenv("CI_PROJECT_ID", "")
    pipeline = os.getenv("CI_PIPELINE_ID", "")
    if not (api and project and pipeline):
        return []
    headers = {}
    if os.getenv("GITLAB_TOKEN"):
        headers["PRIVATE-TOKEN"] = os.environ["GITLAB_TOKEN"]
    elif os.getenv("CI_JOB_TOKEN"):
        headers["JOB-TOKEN"] = os.environ["CI_JOB_TOKEN"]
    failed: list[dict] = []
    try:
        for page in range(1, MAX_PAGES + 1):
            url = (f"{api}/projects/{project}/pipelines/{pipeline}/jobs"
                   f"?per_page=100&page={page}&scope[]=failed")
            data = api_get(url, headers)
            if not isinstance(data, list) or not data:
                break
            failed.extend(data)
            if len(data) < 100:
                break
    except (urllib.error.URLError, ValueError, OSError) as e:
        log(f"[!] failed-job lookup degraded: {e}")
    return failed


def build_email(failed: list[dict]) -> tuple[str, str]:
    project_url = os.getenv("CI_PROJECT_URL", "")
    pipeline_id = os.getenv("CI_PIPELINE_ID", "?")
    pipeline_url = f"{project_url}/-/pipelines/{pipeline_id}" \
        if project_url else "(no link)"
    subject = (f"[URGENT] Onboarding Analytics Dashboard pipeline "
               f"#{pipeline_id} FAILED")
    rows = "".join(
        f"<tr><td style='padding:4px 10px'>{escape(j.get('name') or '?')}"
        f"</td><td style='padding:4px 10px'>{escape(j.get('stage') or '')}"
        f"</td><td style='padding:4px 10px'>"
        f"{escape(j.get('failure_reason') or '')}</td>"
        f"<td style='padding:4px 10px'>"
        f"<a href='{escape(j.get('web_url') or '#')}'>job log</a></td></tr>"
        for j in failed) or ("<tr><td colspan='4' style='padding:4px 10px'>"
                             "Failed job list unavailable - open the "
                             "pipeline link.</td></tr>")
    body = f"""<html><body style="font-family:Segoe UI,Arial,sans-serif">
<p>The <b>scheduled data-collection pipeline</b> of the DXOne Onboarding
Analytics Dashboard <b style="color:#c0392b">FAILED</b>.</p>
<p>Pipeline: <a href="{escape(pipeline_url)}">#{escape(pipeline_id)}</a></p>
<table style="border-collapse:collapse;border:1px solid #ddd">
<tr style="background:#f5f5f5">
<th style="padding:4px 10px;text-align:left">Job</th>
<th style="padding:4px 10px;text-align:left">Stage</th>
<th style="padding:4px 10px;text-align:left">Failure reason</th>
<th style="padding:4px 10px;text-align:left">Link</th></tr>
{rows}
</table>
<p style="color:#888;font-size:12px">Sent automatically by the
notify-failure job of the onboarding analytics dashboard pipeline.</p>
</body></html>"""
    return subject, body


def main() -> int:
    failed = fetch_failed_jobs()
    log(f"Failed jobs found: {len(failed)}")
    subject, body = build_email(failed)
    host, port, sender, to = smtp_settings()
    msg = MIMEText(body, "html", "utf-8")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(to)
    msg["X-Priority"] = "1"
    msg["X-MSMail-Priority"] = "High"
    msg["Importance"] = "High"
    try:
        smtp = smtplib.SMTP(host, port, timeout=TIMEOUT)
        try:
            smtp.sendmail(sender, to, msg.as_string())
        finally:
            smtp.quit()
    except (smtplib.SMTPException, OSError) as e:
        log(f"[!] SMTP delivery failed: {e}")
        return 1
    log(f"Alert sent to {len(to)} recipient(s) via {host}:{port}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
