#!/usr/bin/env python3
"""Thin wrapper so the pipeline can run the collector without installing
the package: adds ``src/`` to ``sys.path`` and delegates to
``pipescan.cli.main``.  All logic lives in ``src/pipescan/``.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from pipescan.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
