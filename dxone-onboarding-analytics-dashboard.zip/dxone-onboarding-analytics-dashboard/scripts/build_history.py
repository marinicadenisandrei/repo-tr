#!/usr/bin/env python3
"""Append-only collection-run history.

Every dashboard pipeline run is folded into ``history.json``:

* a **run record** - when the collection ran, which window it covered, how
  much data it collected, plus a full KPI snapshot of the dataset at that
  moment (pipelines / success rate / failures / durations / retries /
  downstream / error groups);
* **run-over-run deltas** against the previous record - these power the
  "Run-over-run changes" page of the dashboard;
* the **error track** - per error signature, when it was first/last seen
  across runs, so new vs recurring failures can be told apart.

Restore cascade in CI (previous artifact -> live Pages -> committed seed ->
empty) mirrors the migration dashboard.

Usage:
    build_history.py [--history prev.json] --snapshot pipeline_analytics.json
                     --output history/history.json --run-id 123
    build_history.py [--history prev.json] --output ... --allow-empty
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone

SCHEMA_VERSION = 1


def load_json(path: str) -> dict | None:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def empty_history() -> dict:
    return {"schema_version": SCHEMA_VERSION, "generated_at": None,
            "runs": [], "error_track": {}}


def parse_ts(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except ValueError:
        return None


def snapshot_kpis(ds: dict) -> dict:
    s = ds.get("summary", {})
    dur = s.get("duration", {}) or {}
    return {
        "pipelines": s.get("pipelines", 0),
        "success": s.get("success", 0),
        "failed": s.get("failed", 0),
        "canceled": s.get("canceled", 0),
        "success_rate": s.get("success_rate", 0),
        "jobs": s.get("jobs", 0),
        "job_failures": s.get("job_failures", 0),
        "retries": s.get("retries", 0),
        "downstream_pipelines": s.get("downstream_pipelines", 0),
        "downstream_failed": s.get("downstream_failed", 0),
        "error_groups": s.get("error_groups", 0),
        "assets": s.get("assets", 0),
        "avg_duration": dur.get("avg"),
        "p95_duration": dur.get("p95"),
    }


def build_run_record(ds: dict, run_id: str | None, source: str,
                     prev: dict | None) -> dict:
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    kpis = snapshot_kpis(ds)
    # collection-run bookkeeping written by the collector itself
    coll = (ds.get("runs") or [{}])[-1]
    record = {
        "run_id": run_id or coll.get("ci_pipeline_id"),
        "recorded_at": now,
        "source": source,
        "window": ds.get("window", {}),
        "collection": {
            "mode": coll.get("mode"),
            "elapsed_s": coll.get("elapsed_s"),
            "new_pipelines": coll.get("new_pipelines"),
            "refreshed_pipelines": coll.get("refreshed_pipelines"),
            "jobs_seen": coll.get("jobs_seen"),
            "traces_fetched": coll.get("traces_fetched"),
            "downstream_collected": coll.get("downstream_collected"),
            "pruned": coll.get("pruned"),
            "ci_pipeline_url": coll.get("ci_pipeline_url"),
        },
        "kpis": kpis,
        "top_errors": [{"signature": e.get("signature"),
                        "count": e.get("count")}
                       for e in (ds.get("errors") or [])[:10]],
        "top_failing_jobs": [{"name": j.get("name"),
                              "failed": j.get("failed"),
                              "fail_rate": j.get("fail_rate")}
                             for j in (ds.get("jobs") or [])
                             if j.get("failed")][:10],
    }
    if prev:
        pk = prev.get("kpis", {})
        record["delta"] = {k: round((kpis.get(k) or 0) - (pk.get(k) or 0), 2)
                           for k in kpis
                           if isinstance(kpis.get(k), (int, float))
                           and isinstance(pk.get(k), (int, float))}
    return record


def update_error_track(history: dict, ds: dict, run_id: str | None) -> None:
    track = history.setdefault("error_track", {})
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for err in ds.get("errors") or []:
        sig = err.get("signature")
        if not sig:
            continue
        ent = track.get(sig)
        if ent is None:
            ent = track[sig] = {"first_run": run_id, "first_seen": now,
                                "runs_seen": 0, "max_count": 0}
        ent["last_seen"] = now
        ent["last_run"] = run_id
        ent["runs_seen"] = ent.get("runs_seen", 0) + 1
        ent["max_count"] = max(ent.get("max_count", 0),
                               err.get("count", 0))
        ent["last_count"] = err.get("count", 0)


def apply_retention(history: dict, keep_days: int, max_runs: int,
                    track_keep_days: int) -> None:
    now = datetime.now(timezone.utc)
    runs = history.get("runs", [])
    if keep_days:
        cutoff = now - timedelta(days=keep_days)
        runs = [r for r in runs
                if (parse_ts(r.get("recorded_at")) or now) >= cutoff]
    if max_runs and len(runs) > max_runs:
        runs = runs[-max_runs:]
    history["runs"] = runs
    if track_keep_days:
        cutoff = now - timedelta(days=track_keep_days)
        track = history.get("error_track", {})
        for sig in [s for s, e in track.items()
                    if (parse_ts(e.get("last_seen")) or now) < cutoff]:
            del track[sig]


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--history", help="previous history.json (optional)")
    p.add_argument("--snapshot", help="this run's pipeline_analytics.json")
    p.add_argument("--output", required=True)
    p.add_argument("--run-id")
    p.add_argument("--source", default="pipeline")
    p.add_argument("--keep-days", type=int, default=365)
    p.add_argument("--max-runs", type=int, default=500)
    p.add_argument("--track-keep-days", type=int, default=90)
    p.add_argument("--allow-empty", action="store_true",
                   help="carry the previous history forward unchanged")
    args = p.parse_args(argv)

    history = (load_json(args.history) if args.history else None) \
        or empty_history()
    if history.get("schema_version") != SCHEMA_VERSION:
        history = empty_history()

    if args.snapshot:
        ds = load_json(args.snapshot)
        if ds is None:
            print(f"Snapshot {args.snapshot} unreadable", file=sys.stderr)
            return 1
        prev = history["runs"][-1] if history["runs"] else None
        history["runs"].append(build_run_record(ds, args.run_id,
                                                args.source, prev))
        update_error_track(history, ds, args.run_id)
        print(f"Recorded run {args.run_id or '?'}: "
              f"{len(history['runs'])} run(s) in history")
    elif not args.allow_empty:
        print("No --snapshot given and --allow-empty not set",
              file=sys.stderr)
        return 1
    else:
        print("Carrying previous history forward "
              f"({len(history['runs'])} run(s))")

    apply_retention(history, args.keep_days, args.max_runs,
                    args.track_keep_days)
    history["generated_at"] = datetime.now(timezone.utc) \
        .isoformat(timespec="seconds")

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(history, f, separators=(",", ":"))
    print(f"History written: {args.output} "
          f"({os.path.getsize(args.output) // 1024} KB, "
          f"{len(history['runs'])} run(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
