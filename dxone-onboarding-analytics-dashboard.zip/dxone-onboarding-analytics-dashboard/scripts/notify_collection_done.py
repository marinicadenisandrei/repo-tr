#!/usr/bin/env python3
"""Email a collection-run SUMMARY once fetching the data is done.

Counterpart of ``notify_pipeline_failure.py`` for the happy path: sent
from the last stage of a SUCCESSFUL pipeline, after fetch +
build-history + pages, with the numbers of the run that just finished -
mode, window, new/refreshed pipelines, downstream collected, dataset
KPIs with run-over-run deltas, top errors and failing jobs, and links
to the dashboard and the CI pipeline.

STDLIB-ONLY on purpose (no pip install): everything it needs is already
inside the ``build-history`` artifact (``history/history.json``), so it
cannot be broken by a package-mirror outage.

Environment (all optional):
  HISTORY_FILE     history produced by build_history.py
                   (default history/history.json; falls back to the
                   dataset summary in $OUTPUT_DIR when missing)
  OUTPUT_DIR       collector output dir (default output)
  SMTP_HOST / SMTP_PORT          (default smtp.prod.stockex.local:25)
  ALERT_FROM                     sender address
  ALERT_TO         comma-separated recipients (default: maintainers)
  SUCCESS_NOTIFY   never -> exit without sending (defense in depth;
                   the CI rules are the primary policy switch)
  CI_PAGES_URL / CI_PIPELINE_URL / CI_PIPELINE_ID   links in the email
"""
from __future__ import annotations

import html
import json
import os
import smtplib
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

DEFAULT_ALERT_RECIPIENTS = [
    "Kanaganathan.Arulselvan@lseg.com",
    "Akash.Gupta2@lseg.com",
    "denis.marinica@lseg.com",
]


# --------------------------------------------------------------------- #
# formatting helpers                                                    #
# --------------------------------------------------------------------- #
def _fmt(n) -> str:
    if n is None:
        return "–"
    try:
        return f"{int(n):,}" if float(n) == int(n) else f"{float(n):,.1f}"
    except (TypeError, ValueError):
        return str(n)


def _dur(sec) -> str:
    if not isinstance(sec, (int, float)):
        return "–"
    sec = int(round(sec))
    if sec < 60:
        return f"{sec}s"
    m, s = divmod(sec, 60)
    if m < 60:
        return f"{m}m {s}s" if s else f"{m}m"
    h, m = divmod(m, 60)
    return f"{h}h {m}m" if m else f"{h}h"


def _delta(v, invert: bool = False, pct: bool = False, dur: bool = False):
    """(text, css-color) of a run-over-run delta - green when improving."""
    if v in (None, 0):
        return "±0", "#6e7891"
    good = (v < 0) if invert else (v > 0)
    arrow = "▲" if v > 0 else "▼"
    if dur:
        body = _dur(abs(v))
    elif pct:
        body = f"{abs(v):.1f}pp"
    else:
        body = _fmt(abs(v))
    sign = "+" if v > 0 else "−"
    return f"{arrow} {sign}{body}", ("#25b003" if good else "#ed2000")


def load_last_run(history_file: str, output_dir: str) -> dict | None:
    """Last run record from the history; dataset-summary fallback."""
    try:
        with open(history_file, encoding="utf-8") as f:
            runs = (json.load(f) or {}).get("runs") or []
        if runs:
            return runs[-1]
    except (OSError, ValueError):
        pass
    # fallback: synthesise a minimal record from the dataset summary
    try:
        ds_path = os.path.join(output_dir, "pipeline_analytics.json")
        with open(ds_path, encoding="utf-8") as f:
            ds = json.load(f)
        return {"kpis": ds.get("summary") or {}, "delta": None,
                "collection": (ds.get("runs") or [{}])[-1],
                "window": ds.get("window") or {},
                "top_errors": [], "top_failing_jobs": []}
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------- #
# email body                                                            #
# --------------------------------------------------------------------- #
def build_email(run: dict, env: dict) -> tuple[str, str]:
    """(subject, html body) for one collection-run record."""
    e = html.escape
    k = run.get("kpis") or {}
    d = run.get("delta")
    col = run.get("collection") or {}
    win = run.get("window") or {}
    mode = col.get("mode") or win.get("mode") or "?"
    pages = (env.get("CI_PAGES_URL") or "").rstrip("/")
    pipe_url = col.get("ci_pipeline_url") or env.get("CI_PIPELINE_URL") or ""
    pipe_id = env.get("CI_PIPELINE_ID") or run.get("run_id") or "?"

    rate_txt, rate_col = _delta((d or {}).get("success_rate"), pct=True) \
        if d else ("first run", "#6e7891")
    subject = (f"[OK] Onboarding pipeline analytics #{pipe_id} - "
               f"{mode}: {_fmt(k.get('pipelines'))} pipelines "
               f"(+{_fmt(col.get('new_pipelines'))} new), "
               f"success rate {_fmt(k.get('success_rate'))}%")

    def row(label, value, dv=None, **dk):
        if d is not None and dv is not None:
            txt, color = _delta(dv, **dk)
            dcell = (f'<td style="text-align:right;color:{color};'
                     f'font-weight:600">{e(txt)}</td>')
        else:
            dcell = '<td style="text-align:right;color:#6e7891">–</td>'
        return (f'<tr><td style="color:#525b75;padding:3px 14px 3px 0">'
                f'{e(label)}</td><td style="text-align:right;'
                f'font-weight:600;padding:3px 14px 3px 0">{e(value)}</td>'
                f'{dcell}</tr>')

    kpi_rows = "".join([
        row("Pipelines in dataset", _fmt(k.get("pipelines")),
            (d or {}).get("pipelines")),
        row("Success rate", f"{_fmt(k.get('success_rate'))}%",
            (d or {}).get("success_rate"), pct=True),
        row("Failed pipelines", _fmt(k.get("failed")),
            (d or {}).get("failed"), invert=True),
        row("Job failures", _fmt(k.get("job_failures")),
            (d or {}).get("job_failures"), invert=True),
        row("Error groups", _fmt(k.get("error_groups")),
            (d or {}).get("error_groups"), invert=True),
        row("Downstream pipelines", _fmt(k.get("downstream_pipelines")),
            (d or {}).get("downstream_pipelines")),
        row("Downstream failed", _fmt(k.get("downstream_failed")),
            (d or {}).get("downstream_failed"), invert=True),
        row("Avg duration", _dur(k.get("avg_duration")),
            (d or {}).get("avg_duration"), invert=True, dur=True),
    ])

    col_rows = "".join(
        f'<tr><td style="color:#525b75;padding:3px 14px 3px 0">{e(a)}</td>'
        f'<td style="font-weight:600">{e(b)}</td></tr>'
        for a, b in [
            ("Fetch mode", mode),
            ("Window", f"{(win.get('from') or '?')[:16]} → "
                       f"{(win.get('to') or '?')[:16]} UTC"),
            ("New pipelines", _fmt(col.get("new_pipelines"))),
            ("Refreshed (unsettled)", _fmt(col.get("refreshed_pipelines"))),
            ("Pruned (old)", _fmt(col.get("pruned"))),
            ("Jobs seen", _fmt(col.get("jobs_seen"))),
            ("Logs scanned", _fmt(col.get("traces_fetched"))),
            ("Downstream collected", _fmt(col.get("downstream_collected"))),
            ("Collection time", _dur(col.get("elapsed_s"))),
        ])

    def toplist(title, items, render):
        if not items:
            return ""
        lis = "".join(f'<li style="margin:2px 0">{render(i)}</li>'
                      for i in items[:3])
        return (f'<p style="margin:14px 0 4px;font-weight:700">{e(title)}'
                f'</p><ul style="margin:0;padding-left:18px;color:#31374a">'
                f'{lis}</ul>')

    errs = toplist(
        "Top errors in the dataset", run.get("top_errors") or [],
        lambda i: (f'<code style="font-size:12px">'
                   f'{e(str(i.get("signature"))[:160])}</code>'
                   f' <span style="color:#6e7891">×{_fmt(i.get("count"))}'
                   f'</span>'))
    jobs = toplist(
        "Top failing jobs", run.get("top_failing_jobs") or [],
        lambda i: (f'{e(str(i.get("name")))}'
                   f' <span style="color:#6e7891">'
                   f'{_fmt(i.get("failed"))} failed'
                   f' ({_fmt(i.get("fail_rate"))}%)</span>'))

    links = []
    if pages:
        links.append(f'<a href="{e(pages)}" '
                     f'style="color:#3874ff;font-weight:700">'
                     f'Open the dashboard →</a>')
    if pipe_url:
        links.append(f'<a href="{e(pipe_url)}" style="color:#3874ff">'
                     f'Collector pipeline #{e(str(pipe_id))}</a>')

    body = f"""\
<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#31374a">
<h2 style="color:#25b003;margin:0 0 2px">
  ✔ Pipeline analytics collection finished</h2>
<p style="margin:2px 0 14px;color:#525b75">
  dxone-onboarding-master · run <b>#{e(str(pipe_id))}</b> ·
  {e(mode)} fetch completed successfully.</p>
{'<p style="margin:0 0 14px">' + ' &nbsp;·&nbsp; '.join(links) + '</p>'
 if links else ''}
<table style="border-collapse:collapse;font-size:13px"><tr>
<td style="vertical-align:top;padding-right:36px">
  <p style="margin:0 0 4px;font-weight:700">This collection run</p>
  <table style="border-collapse:collapse;font-size:13px">{col_rows}</table>
</td>
<td style="vertical-align:top">
  <p style="margin:0 0 4px;font-weight:700">Dataset KPIs
    <span style="color:#6e7891;font-weight:400">(Δ vs previous run)</span>
  </p>
  <table style="border-collapse:collapse;font-size:13px">{kpi_rows}</table>
</td></tr></table>
{errs}{jobs}
<p style="margin-top:18px;font-size:11px;color:#8a94ad">
  Automated notification from the dxone-onboarding-analytics-dashboard
  pipeline. Recipients: ALERT_TO CI/CD variable · policy:
  SUCCESS_NOTIFY (schedule / always / never).</p>
</body></html>"""
    return subject, body


# --------------------------------------------------------------------- #
# sending                                                               #
# --------------------------------------------------------------------- #
def smtp_config() -> tuple[str, int, str, list[str]]:
    host = os.getenv("SMTP_HOST", "smtp.prod.stockex.local")
    port = int(os.getenv("SMTP_PORT", "25"))
    sender = os.getenv("ALERT_FROM",
                       "dxone_onboarding_dashboard@lseg.com")
    to_raw = os.getenv("ALERT_TO", "").strip()
    to = [a.strip() for a in to_raw.split(",") if a.strip()] \
        or list(DEFAULT_ALERT_RECIPIENTS)
    return host, port, sender, to


def main() -> int:
    if os.getenv("SUCCESS_NOTIFY", "").lower() == "never":
        print("SUCCESS_NOTIFY=never - not sending.")
        return 0
    run = load_last_run(os.getenv("HISTORY_FILE", "history/history.json"),
                        os.getenv("OUTPUT_DIR", "output"))
    if run is None:
        print("No history / dataset found - nothing to summarise.",
              file=sys.stderr)
        return 0                       # never fail a green pipeline
    subject, body = build_email(run, dict(os.environ))

    host, port, sender, recipients = smtp_config()
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(body, "html", "utf-8"))
    try:
        with smtplib.SMTP(host, port, timeout=30) as smtp:
            smtp.sendmail(sender, recipients, msg.as_string())
    except Exception as exc:           # noqa: BLE001
        print(f"SMTP send failed: {exc}", file=sys.stderr)
        return 0                       # never fail a green pipeline
    print(f"Summary sent to {len(recipients)} recipient(s): "
          f"{', '.join(recipients)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
