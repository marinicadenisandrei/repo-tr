#!/usr/bin/env python3
"""Slim the published dataset for the browser.

The aggregates (summary / daily / jobs / stages / errors / assets /
downstream) are ALWAYS published in full - they are small and they are what
the charts read.  Only the raw ``pipelines[]`` rows can grow without bound,
so the browser copy

* keeps the newest ``--max-rows`` pipeline rows (default 5000 - a 6-month
  history of the onboarding project fits comfortably; the cap is a browser
  seat belt, not a data limit),
* trims per-row embedded detail (errors / downstream / failed job names)
  to sane display sizes.

The FULL dataset stays in the fetch-pipeline-data artifact and the CSV.

Also slims ``history.json``: run records are kept in full (they are tiny);
the internal ``error_track`` is dropped from the browser copy.
"""
from __future__ import annotations

import argparse
import gzip
import json
import os
import sys


def load(path: str) -> dict:
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as f:
        return json.load(f)


def dump(obj: dict, path: str) -> None:
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "wt", encoding="utf-8") as f:
        json.dump(obj, f, separators=(",", ":"))


def slim_dataset(ds: dict, max_rows: int, max_errors_per_row: int,
                 max_downstream_per_row: int) -> dict:
    rows = ds.get("pipelines") or []
    truncated = 0
    if max_rows and len(rows) > max_rows:
        truncated = len(rows) - max_rows
        rows = rows[:max_rows]          # dataset rows are newest-first
    for row in rows:
        if max_errors_per_row and len(row.get("errors") or []) \
                > max_errors_per_row:
            row["errors"] = row["errors"][:max_errors_per_row]
        if max_downstream_per_row and len(row.get("downstream") or []) \
                > max_downstream_per_row:
            row["downstream"] = row["downstream"][:max_downstream_per_row]
        for err in row.get("errors") or []:
            if err.get("message") and len(err["message"]) > 300:
                err["message"] = err["message"][:300] + "…"
    ds["pipelines"] = rows
    if truncated:
        ds["truncated_rows"] = truncated
    return ds


def slim_history(hist: dict) -> dict:
    hist.pop("error_track", None)
    return hist


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--input", help="pipeline_analytics.json[.gz]")
    p.add_argument("--output")
    p.add_argument("--max-rows", type=int, default=5000)
    p.add_argument("--max-errors-per-row", type=int, default=10)
    p.add_argument("--max-downstream-per-row", type=int, default=20)
    p.add_argument("--history-in")
    p.add_argument("--history-out")
    args = p.parse_args(argv)

    if args.input and args.output:
        try:
            ds = load(args.input)
        except (OSError, ValueError) as e:
            print(f"Cannot read {args.input}: {e}", file=sys.stderr)
            return 1
        dump(slim_dataset(ds, args.max_rows, args.max_errors_per_row,
                          args.max_downstream_per_row), args.output)
        print(f"Slimmed dataset -> {args.output} "
              f"({len(ds.get('pipelines') or [])} rows"
              f"{', ' + str(ds.get('truncated_rows')) + ' truncated' if ds.get('truncated_rows') else ''})")

    if args.history_in and args.history_out:
        try:
            hist = load(args.history_in)
        except (OSError, ValueError) as e:
            print(f"Cannot read {args.history_in}: {e}", file=sys.stderr)
            return 1
        dump(slim_history(hist), args.history_out)
        print(f"Slimmed history -> {args.history_out} "
              f"({len(hist.get('runs') or [])} run(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
